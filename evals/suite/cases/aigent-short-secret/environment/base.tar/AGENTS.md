# AGENTS.md

This repo builds a small agent harness on top of an agent SDK.

## pstack is required

Every agent working in this repo works under [pstack](https://github.com/cursor/plugins/tree/main/pstack) (poteto-stack). This is not optional.

- Run every non-trivial task under `poteto-mode`. Most pstack skills are user-invoked only (`disable-model-invocation`), so you will not find them in your skill list. If the user did not type `/poteto-mode`, read `.agents/skills/poteto-mode/SKILL.md` in full yourself, including its Principles index and Harness section, before any work. Do the same for any other pstack skill a step routes to.
- Follow the playbook it picks. Copy the playbook steps into your task list and do not skip steps.
- Trivial tasks (a typo, a one-line config change) still follow the `principle-*` skills. Read the leaf principle whenever you apply it.
- Delegate through the `poteto-agent` subagent, never a generic one. In Claude Code it is in `.claude/agents/`. Elsewhere, follow the `poteto-agent` mapping in the Harness section of `poteto-mode`.
- Before you call work done, prove it against the real artifact (`principle-prove-it-works`).
- Model choices per role come from `~/.agents/pstack-models.md`. Run `/setup-pstack` to write it.

## Own your diff

The human author pushes only what they can explain. Before every push or PR, run the `own-your-diff` skill. That includes the push in pstack's Opening a PR playbook. It writes an HTML walkthrough of the change and quizzes the author on it. On unattended runs, fresh subagents quiz the authoring agent instead. The pre-push hook blocks commits that have no passed quiz.

- The skill, its `quizgate` gate, and the harness hooks ship as the `own-your-diff` plugin from the private repo [krimvp/own-your-diff](https://github.com/krimvp/own-your-diff), for Claude Code, Droid, and Codex. Its README covers install. The committed `.own-your-diff` file opts this repo in, and the plugin's session hook installs the pre-push hook in each clone.
- A blocked push routes back to `own-your-diff`. Pushing with `--no-verify`, and recording a pass nobody earned, are the human's calls, never an agent's.

## Other skills

These skills add to pstack. They do not replace it.

| Need | Skill |
|---|---|
| Writing, changing, or reviewing a test | `test-audit`. Every new or changed test must pass its authoring gate. |
| Stress-testing a plan or design | `grilling`, or `grill-with-docs` to record ADRs and a glossary as you go |
| Domain terms and decisions | `domain-modeling` |
| Module and interface design | `codebase-design` |
| Editing AGENTS.md, CLAUDE.md, or a skill | `writing-for-agents` |
| Handing work to a new session | `handoff` |

## Layout

- `.agents/skills/` holds every skill. `.claude/skills` is a symlink to it.
- Vendored skills are pinned in `.agents/skills.lock`. Do not edit them in place. Re-sync with `scripts/vendor-skills.sh`, or `--update` to move the pins. Licenses are in `third_party/`.
- `test-audit` is an adapted port, not a verbatim copy. Edit it directly. `.agents/skills/test-audit/PORT.md` records what changed from upstream.
- `own-your-diff` lives in krimvp/own-your-diff, not here. Change it there.
