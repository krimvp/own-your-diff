import assert from 'node:assert/strict'
import { readdir, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { test } from 'node:test'

const ROOT = join(import.meta.dirname, '..')
// The adapter's offline tests drive pi's faux provider, so its own test and the shared faux model may cross the line.
const PI_IMPORTERS = new Set(['src/pi.ts', 'test/pi.test.ts', 'test/fixtures/faux.ts'])
const ADAPTER_IMPORTERS = new Set(['src/index.ts', 'test/fixtures/faux.ts'])

test('only the adapter imports @earendil-works packages', async () => {
  const offenders: string[] = []
  for (const file of await sourceFiles()) {
    if (PI_IMPORTERS.has(file)) continue
    if ((await specifiers(file)).some((s) => s.startsWith('@earendil-works/'))) offenders.push(file)
  }
  assert.deepEqual(offenders, [], 'files outside the adapter import pi')
  assert.ok((await specifiers('src/pi.ts')).some((s) => s.startsWith('@earendil-works/')), 'src/pi.ts no longer imports pi; update PI_IMPORTERS so this test still guards the boundary')
})

test('nothing but the host entry imports the adapter', async () => {
  const offenders: string[] = []
  for (const file of await sourceFiles()) {
    if (ADAPTER_IMPORTERS.has(file)) continue
    if ((await specifiers(file)).some((s) => /(^|\/)pi(\.ts)?$/.test(s))) offenders.push(file)
  }
  assert.deepEqual(offenders, [], 'the engine core and plugin API must not reach pi through the adapter')
})

test('the eval code sees sessions only through the host vocabulary', async () => {
  const files = (await sourceFiles()).filter((f) => f.startsWith('src/eval/'))
  const offenders: string[] = []
  for (const file of files) {
    if ((await specifiers(file)).some((s) => /(^|\/)(engine|pi|index)(\.ts)?$/.test(s))) offenders.push(file)
  }
  assert.ok(files.includes('src/eval/run.ts'), 'src/eval/run.ts moved; update this test so it still guards the eval code')
  assert.deepEqual(offenders, [], 'the scenario runner and the checks must not reach the engine, the adapter or the host entry')
})

async function sourceFiles(): Promise<readonly string[]> {
  const files: string[] = []
  for (const dir of ['src', 'test']) {
    const names = await readdir(join(ROOT, dir), { recursive: true }).catch((error: NodeJS.ErrnoException) => {
      if (error.code === 'ENOENT') return []
      throw error
    })
    files.push(...names.filter((name) => name.endsWith('.ts')).map((name) => `${dir}/${name.split('\\').join('/')}`))
  }
  return files
}

/** Static `import`/`export … from`, side-effect `import '…'`, and dynamic `import('…')` specifiers. */
async function specifiers(file: string): Promise<readonly string[]> {
  const source = await readFile(join(ROOT, file), 'utf8')
  return [...source.matchAll(/(?:\bfrom\s*|\bimport\s*\(?\s*)['"]([^'"]+)['"]/g)].map((m) => m[1]!)
}
