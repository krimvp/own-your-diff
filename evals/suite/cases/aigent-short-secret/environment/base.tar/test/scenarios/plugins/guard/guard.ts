export { guard as default } from '../../../fixtures/plugins.ts'
