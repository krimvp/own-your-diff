import type { Plugin } from '../../../../src/plugin.ts'

// A plugin a scenario adds on resume, to measure whether the model picks up a plugin the catalog gained.
export default {
  name: 'clock',
  description: 'The current time in any city.',
  tools: [
    {
      name: 'now',
      description: 'Current local time in a city.',
      parameters: { type: 'object', properties: { city: { type: 'string' } }, required: ['city'], additionalProperties: false },
      execute: async (args) => ({ content: [{ type: 'text', text: `${String(args.city)}: 14:05` }] }),
    },
  ],
} satisfies Plugin
