import { makeWeather } from '../../../fixtures/plugins.ts'

// Echoes the scenario's declared secret, so every run proves redaction on a value that really flowed. Read at
// import, so a process sets WEATHER_API_KEY once, before its first run loads this directory.
export default makeWeather({ echo: process.env.WEATHER_API_KEY }).plugin
