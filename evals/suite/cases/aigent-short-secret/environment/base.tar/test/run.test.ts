// The scenario boundary, the runner and the result directory, on faux-provider runs: when a run refuses to start,
// what it records, and that the files hold exactly the run.

import assert from 'node:assert/strict'
import { mkdir, mkdtemp, readdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { readRun, runScenario, writeRun, type RunLog } from '../src/eval/run.ts'
import { parseScenario, ScenarioError, type Scenario } from '../src/eval/scenario.ts'
import { call, FAUX, fauxModel, reply, type Reply } from './fixtures/faux.ts'

// Before any run loads the weather plugin, which echoes it.
process.env.WEATHER_API_KEY = 'sk-canary-0123456789'
const root = join(import.meta.dirname, 'scenarios')

const scenario = (steps: readonly unknown[], extra: Readonly<Record<string, unknown>> = {}): Scenario =>
  parseScenario({ format: 'aigent-scenario/1', plugins: ['plugins/weather'], secrets: ['WEATHER_API_KEY'], systemPrompt: 'You are a test agent.', ...extra, steps })

async function run(s: Scenario, script: readonly Reply[]): Promise<RunLog> {
  const model = fauxModel(script)
  const log = await runScenario(s, { root, open: model.open, model: FAUX, toolMode: 'native', promptTimeoutMs: 5_000 })
  assert.equal(model.pending(), 0, 'the run used its whole script')
  return log
}

/** Where each problem is, without its wording. */
const places = (problems: readonly string[]): readonly string[] => problems.map((p) => p.slice(0, p.indexOf(':'))).sort()

const enableWeather = call('core__enable_plugin', { name: 'weather' })
const lisbon = [enableWeather, call('weather__get_weather', { city: 'Lisbon' }), reply('It is 17°C in Lisbon.')]

test('a scenario is rejected with every problem in it, each at its place', () => {
  const error = (() => {
    try {
      parseScenario({
        format: 'aigent-scenario/2',
        plugins: ['../elsewhere'],
        systemPrompt: 'Test.',
        expects: [],
        steps: [
          { kind: 'prompt', text: 'Hi', expect: [{ check: 'discover' }, { check: 'follow', matches: '(' }, { check: 'restraint' }, { check: 'restraint' }, { check: 'wins' }] },
          { kind: 'sleep' },
          { kind: 'prompt', text: 'Again', expect: [{ check: 'host-enable', tool: 'weather__get_weather' }, { check: 'resume', tool: 'weather__get_weather' }] },
        ],
      })
    } catch (error) {
      return error
    }
  })()

  assert.ok(error instanceof ScenarioError)
  assert.deepEqual(
    places(error.problems),
    ['expects', 'format', 'plugins[0]', 'steps[0].expect[0].plugin', 'steps[0].expect[1].matches', 'steps[0].expect[3]', 'steps[0].expect[4].check', 'steps[1].kind', 'steps[2].expect[0]', 'steps[2].expect[1]'],
  )
})

test('a run refuses a scenario its plugins or environment cannot satisfy, before any model call', async () => {
  const model = fauxModel([reply('never sent')])
  const bad = scenario(
    [
      { kind: 'enable', plugin: 'clock' },
      { kind: 'prompt', text: 'Hi', expect: [{ check: 'use', tool: 'weather__get_wether' }, { check: 'skill', skill: 'weather__forcasting', loaded: true }] },
      { kind: 'resume', plugins: ['plugins/missing'] },
    ],
    { secrets: ['AIGENT_TEST_UNSET'], enabled: ['wether'] },
  )

  const error = await runScenario(bad, {
    root,
    open: model.open,
    model: { kind: 'openai-compatible', baseUrl: 'http://127.0.0.1:9', id: 'm', apiKeyEnv: 'AIGENT_TEST_UNSET_KEY' },
    toolMode: 'native',
    promptTimeoutMs: 5_000,
  }).then(
    () => undefined,
    (e: unknown) => e,
  )

  assert.ok(error instanceof ScenarioError)
  assert.deepEqual(places(error.problems), ['AIGENT_TEST_UNSET', 'AIGENT_TEST_UNSET_KEY', 'enabled', 'steps[0].plugin', 'steps[1].expect[0]', 'steps[1].expect[1]', 'steps[2].plugins'])
  assert.equal(model.pending(), 1, 'no model call was made')
})

test('a step that throws ends the run there, and the log keeps what ran before it', async () => {
  // The clock set lacks weather, which the saved records enabled, so the resumed session cannot be built.
  const log = await run(scenario([{ kind: 'prompt', text: 'Weather in Lisbon?' }, { kind: 'resume', plugins: ['plugins/clock'] }, { kind: 'prompt', text: 'And Porto?' }]), lisbon)

  assert.deepEqual(
    log.steps.map((s) => s.kind),
    ['prompt'],
  )
  assert.equal(log.failure?.step, 2)
  assert.equal(log.transcript.messages.length, log.steps[0]?.end, 'the transcript is the one the first session left')
})

test('a reply streamed in many deltas is one text event in the log', async () => {
  const text = 'Lisbon is mild today, around seventeen degrees, with light rain later.'
  const log = await run(scenario([{ kind: 'prompt', text: 'Weather?' }]), [reply(text)])

  const step = log.steps[0]
  assert.equal(step?.kind, 'prompt')
  assert.deepEqual(
    step.events.filter((e) => e.type === 'text'),
    [{ type: 'text', delta: text }],
  )
})

test('a result directory reads back as exactly the run that was written, finished or not', async () => {
  const finished = await run(
    scenario([{ kind: 'prompt', text: 'Weather in Lisbon?' }, { kind: 'enable', plugin: 'clock' }, { kind: 'resume' }, { kind: 'prompt', text: 'Time in Porto?' }], { plugins: ['plugins/weather', 'plugins/clock'] }),
    [...lisbon, call('clock__now', { city: 'Porto' }), reply('14:05.')],
  )
  const failed = await run(scenario([{ kind: 'prompt', text: 'Weather in Lisbon?' }, { kind: 'resume', plugins: ['plugins/clock'] }]), lisbon)
  const parent = await mkdtemp(join(tmpdir(), 'aigent-run-'))

  for (const [name, log] of Object.entries({ finished, failed })) {
    await writeRun(join(parent, name), log)
    assert.deepEqual(await readRun(join(parent, name)), log, name)
  }
  assert.deepEqual((await readdir(join(parent, 'finished'))).sort(), ['events.jsonl', 'resume-3.json', 'run.json', 'transcript.json'])
})

test('writing refuses a directory that exists and leaves nothing beside it', async () => {
  const log = await run(scenario([{ kind: 'prompt', text: 'Hi' }]), [reply('Hello.')])
  const parent = await mkdtemp(join(tmpdir(), 'aigent-run-'))
  await mkdir(join(parent, 'run'))

  await assert.rejects(writeRun(join(parent, 'run'), log))

  assert.deepEqual(await readdir(parent), ['run'])
  assert.deepEqual(await readdir(join(parent, 'run')), [])
})
