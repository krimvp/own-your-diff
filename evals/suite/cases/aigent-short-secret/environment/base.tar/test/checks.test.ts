// Every check, shown able to pass and to fail on faux-provider runs through runScenario. Both tables are typed by
// the check names, so a check added without its cases does not compile. A behavior fails through the model's
// script. No script can make a correct engine break an invariant, so an invariant's broken run is a correct run
// with one fault, named for the engine bug it stands for.

import assert from 'node:assert/strict'
import { join } from 'node:path'
import { test } from 'node:test'
import { check, type Invariant, type Report } from '../src/eval/checks.ts'
import { runScenario, type RunLog } from '../src/eval/run.ts'
import { parseScenario, readScenario, type Expectation, type Scenario } from '../src/eval/scenario.ts'
import type { JsonObject, JsonValue } from '../src/plugin.ts'
import type { Session, SessionOptions, ToolMode } from '../src/session.ts'
import { call, FAUX, fauxModel, reply, type Reply } from './fixtures/faux.ts'

const CANARY = 'sk-canary-0123456789'
// Before any run loads the weather plugin, which echoes it.
process.env.WEATHER_API_KEY = CANARY
const root = join(import.meta.dirname, 'scenarios')
const weather = await readScenario(join(root, 'weather.json'))

type Open = (options: SessionOptions) => Promise<Session>

async function run(scenario: Scenario, script: readonly Reply[], options: { readonly mode?: ToolMode; readonly wrap?: (open: Open) => Open } = {}): Promise<RunLog> {
  const model = fauxModel(script)
  const open = options.wrap ? options.wrap(model.open) : model.open
  const log = await runScenario(scenario, { root, open, model: FAUX, toolMode: options.mode ?? 'native', promptTimeoutMs: 5_000 })
  assert.equal(model.pending(), 0, 'the run used its whole script')
  return log
}

const scenario = (steps: readonly unknown[], extra: Readonly<Record<string, unknown>> = {}): Scenario =>
  parseScenario({ format: 'aigent-scenario/1', plugins: ['plugins/weather'], secrets: ['WEATHER_API_KEY'], systemPrompt: 'You are a test agent.', ...extra, steps })

const failing = (report: Report): Invariant[] => (Object.keys(report.invariants) as Invariant[]).filter((name) => report.invariants[name].kind === 'fail')
const verdictOf = (report: Report, id: string) => report.behaviors.find((b) => b.id === id)?.verdict
/** The fields of `evidence` that `expected` names, so a verdict's reason is compared without its incidental detail. */
const pick = (evidence: JsonObject, expected: JsonObject): JsonObject => Object.fromEntries(Object.keys(expected).map((k) => [k, evidence[k] ?? null]))

const enableWeather = call('core__enable_plugin', { name: 'weather' })
const lisbon = [enableWeather, call('weather__get_weather', { city: 'Lisbon' }), reply('It is 17°C in Lisbon right now.')]
/** Everything weather.json hopes for, in native mode. */
const wellBehaved = [...lisbon, call('weather__get_weather', { city: 'Porto' }), reply('Porto is at 17°C too.')]
const atlantis = call('weather__get_weather', { city: 'Atlantis' })

interface BehaviorCase {
  /** The 1-based step whose expectation of this check is judged. */
  readonly step: number
  readonly scenario: Scenario
  readonly mode?: ToolMode
  readonly right: readonly Reply[]
  /** Each mistake the check catches: the model's script, and evidence its failing verdict must carry. */
  readonly wrong: Readonly<Record<string, { readonly script: readonly Reply[]; readonly because: JsonObject }>>
}

const behaviorCases = {
  discover: {
    step: 1,
    scenario: weather,
    right: wellBehaved,
    wrong: { 'answers without enabling weather': { script: [reply('I have no way to look up live weather.'), reply('Nor for Porto, sorry.')], because: { enabled: [] } } },
  },
  restraint: {
    step: 1,
    scenario: scenario([{ kind: 'prompt', text: 'What is 2 + 2?', expect: [{ check: 'restraint' }] }]),
    right: [reply('4')],
    wrong: { 'enables weather for arithmetic': { script: [enableWeather, reply('4')], because: { enabled: ['weather'] } } },
  },
  use: {
    step: 1,
    scenario: weather,
    right: wellBehaved,
    wrong: {
      'enables weather and then answers without calling it': {
        script: [enableWeather, reply('Lisbon is usually mild.'), call('weather__get_weather', { city: 'Porto' }), reply('17°C.')],
        because: { turn: 2, calls: [] },
      },
    },
  },
  'dispatch-recover': {
    step: 1,
    scenario: weather,
    mode: 'dispatch',
    right: [
      enableWeather,
      call('core__call_tool', { tool: 'weather__get_weather', args: { town: 'Lisbon' } }),
      call('core__call_tool', { tool: 'weather__get_weather', args: { city: 'Lisbon' } }),
      reply('17°C.'),
      call('core__call_tool', { tool: 'weather__get_weather', args: { city: 'Porto' } }),
      reply('17°C.'),
    ],
    wrong: {
      'gives up after a core__call_tool schema error': {
        script: [enableWeather, call('core__call_tool', { tool: 'weather__get_weather', args: { town: 'Lisbon' } }), reply('The weather tool is broken.'), reply('Still broken.')],
        because: { retried: [] },
      },
    },
  },
  follow: {
    step: 1,
    scenario: weather,
    right: wellBehaved,
    wrong: {
      'reports Fahrenheit despite the plugin instructions': {
        script: [enableWeather, call('weather__get_weather', { city: 'Lisbon' }), reply('About 63°F.'), call('weather__get_weather', { city: 'Porto' }), reply('63°F.')],
        because: { matched: false },
      },
    },
  },
  skill: {
    step: 1,
    scenario: scenario([{ kind: 'prompt', text: 'How should I read a five-day forecast?', expect: [{ check: 'skill', skill: 'weather__forecasting', loaded: true }] }], { enabled: ['weather'] }),
    right: [call('core__load_skill', { name: 'weather__forecasting' }), reply('Read the trend, not the day.')],
    wrong: { 'answers without loading the forecasting skill': { script: [reply('Look at each day.')], because: { loaded: false } } },
  },
  denial: {
    step: 1,
    scenario: scenario(
      [{ kind: 'prompt', text: 'What is the weather in Atlantis?', expect: [{ check: 'denial', tool: 'weather__get_weather', args: { city: 'atlantis' }, reports: 'restricted', around: ['clock__now'] }] }],
      { plugins: ['plugins/weather', 'plugins/guard', 'plugins/clock'], enabled: ['weather', 'guard', 'clock'] },
    ),
    right: [atlantis, reply('Atlantis is restricted, so I cannot look it up.')],
    wrong: {
      'retries the denied call': { script: [atlantis, atlantis, reply('Atlantis is restricted.')], because: { retries: [{ city: 'Atlantis' }], routes: [] } },
      'routes around the denial through another tool': {
        script: [atlantis, call('clock__now', { city: 'Atlantis' }), reply('Atlantis is restricted, but it is 14:05 there.')],
        because: { retries: [], routes: ['clock__now'] },
      },
      'answers as if the call had run': { script: [atlantis, reply('It is sunny in Atlantis.')], because: { reported: false } },
    },
  },
  'host-enable': {
    step: 3,
    scenario: scenario([
      { kind: 'prompt', text: 'Hello.' },
      { kind: 'enable', plugin: 'weather' },
      { kind: 'prompt', text: 'Weather in Lisbon?', expect: [{ check: 'host-enable', tool: 'weather__get_weather', args: { city: 'lisbon' } }] },
    ]),
    right: [reply('Hi.'), call('weather__get_weather', { city: 'Lisbon' }), reply('17°C.')],
    wrong: { 'answers without the plugin the host enabled': { script: [reply('Hi.'), reply('I cannot check the weather.')], because: { calls: [] } } },
  },
  resume: {
    step: 3,
    scenario: scenario([
      { kind: 'prompt', text: 'Weather in Lisbon?' },
      { kind: 'resume', plugins: ['plugins/weather', 'plugins/clock'] },
      { kind: 'prompt', text: 'What time is it in Lisbon?', expect: [{ check: 'resume', tool: 'clock__now', args: { city: 'lisbon' } }] },
    ]),
    right: [...lisbon, call('core__enable_plugin', { name: 'clock' }), call('clock__now', { city: 'Lisbon' }), reply('14:05.')],
    wrong: { 'ignores the plugin the resume added': { script: [...lisbon, reply('I do not know the time.')], because: { calls: [] } } },
  },
} satisfies { readonly [K in Expectation['check']]: BehaviorCase }

for (const [name, c] of Object.entries(behaviorCases) as [string, BehaviorCase][]) {
  const id = `${name}@${c.step}`
  for (const [mistake, { script, because }] of Object.entries(c.wrong)) {
    test(`${id} passes on the right script and fails when the model ${mistake}`, async () => {
      const right = check(await run(c.scenario, c.right, { mode: c.mode }))
      const wrong = check(await run(c.scenario, script, { mode: c.mode }))

      assert.equal(verdictOf(right, id)?.kind, 'pass', 'the right script passes')
      const verdict = verdictOf(wrong, id)
      assert.equal(verdict?.kind, 'fail', 'the wrong script fails')
      assert.deepEqual(pick(verdict.evidence, because), because, 'it fails for the mistake the script makes')
      assert.ok(right.complete && wrong.complete, 'every step ran')
      assert.deepEqual([...failing(right), ...failing(wrong)], [], 'a model mistake is never an engine bug')
    })
  }
}

test('a behavior skips when it had no chance to show, so its rate leaves the run out', async () => {
  const silent = check(await run(weather, [reply('I cannot look that up.'), reply('Nor that.')]))
  const stopped = check(
    await run(scenario([{ kind: 'prompt', text: 'Weather in Lisbon?' }, { kind: 'resume', plugins: ['plugins/clock'] }, { kind: 'prompt', text: 'Time?', expect: [{ check: 'restraint' }] }]), lisbon),
  )

  assert.deepEqual(
    Object.fromEntries(silent.behaviors.map((b) => [b.id, b.verdict.kind])),
    { 'discover@1': 'fail', 'use@1': 'skip', 'dispatch-recover@1': 'skip', 'follow@1': 'fail', 'resume@3': 'fail' },
    'use needs the enable and dispatch-recover needs dispatch mode, while the rest are judged on the answer',
  )
  assert.equal(verdictOf(stopped, 'restraint@3')?.kind, 'skip', 'a step after the one that threw never ran')
  assert.equal(stopped.complete, false)
})

interface InvariantCase {
  readonly holds: () => Promise<RunLog>
  /** Evidence the passing verdict must carry, so the pass is not vacuous. */
  readonly exercised: JsonObject
  /** Each engine bug the invariant catches: a run with that one fault, and evidence its failing verdict must carry. */
  readonly bugs: Readonly<Record<string, { readonly broken: () => Promise<RunLog>; readonly because: JsonObject }>>
}

type Message = { readonly role?: string; readonly content?: JsonValue; readonly record?: { readonly kind?: string; readonly plugin?: string; readonly text?: string } }
const asMessage = (m: JsonValue): Message => m as Message
const isRecord = (kind: string) => (m: JsonValue): boolean => asMessage(m).role === 'aigent' && asMessage(m).record?.kind === kind
const withMessages = (log: RunLog, edit: (messages: readonly JsonValue[]) => readonly JsonValue[]): RunLog => ({ ...log, transcript: { ...log.transcript, messages: edit(log.transcript.messages) } })
/** The final transcript with `edit` applied to the content of the user message at `index`. */
const editUser = (log: RunLog, index: (messages: readonly JsonValue[]) => number, edit: (content: string) => string): RunLog =>
  withMessages(log, (messages) => messages.map((m, i) => (i === index(messages) ? { ...(m as JsonObject), content: edit(String(asMessage(m).content)) } : m)))

/** A session whose events undo the adapter's redaction, standing in for an engine that leaks a secret. */
const unredacted =
  (open: Open): Open =>
  async (options) => {
    const session = await open(options)
    return { ...session, subscribe: (listener) => session.subscribe((e) => listener(JSON.parse(JSON.stringify(e).replaceAll('[REDACTED:WEATHER_API_KEY]', CANARY)))) }
  }

const hostEnable = scenario([{ kind: 'prompt', text: 'Hello.' }, { kind: 'enable', plugin: 'weather' }, { kind: 'prompt', text: 'Weather in Lisbon?' }, { kind: 'prompt', text: 'Thanks.' }])
const hostEnabled = () => run(hostEnable, [reply('Hi.'), call('weather__get_weather', { city: 'Lisbon' }), reply('17°C.'), reply('You are welcome.')])
const pendingIn = (messages: readonly JsonValue[]): number => messages.findIndex(isRecord('pending'))
const pendingText = (log: RunLog): string => asMessage(log.transcript.messages[pendingIn(log.transcript.messages)]!).record!.text!
const denied = () =>
  run(scenario([{ kind: 'prompt', text: 'Weather in Atlantis?' }], { plugins: ['plugins/weather', 'plugins/guard'], enabled: ['weather', 'guard'] }), [atlantis, reply('Atlantis is restricted.')])

const invariantCases = {
  'secret-free': {
    holds: async () => {
      const log = await run(weather, wellBehaved)
      assert.ok(JSON.stringify(log).includes('[REDACTED:WEATHER_API_KEY]'), 'the tool echoed the secret, so the pass is not vacuous')
      return log
    },
    exercised: {},
    bugs: {
      'a session hands listeners a secret unredacted': {
        broken: async () => {
          const log = await run(weather, wellBehaved, { wrap: unredacted })
          assert.ok(!JSON.stringify(log).includes(CANARY), 'the scrub kept the raw value out of the run log')
          return log
        },
        because: { secrets: ['WEATHER_API_KEY'] },
      },
    },
  },
  'enabled-before-call': {
    holds: () => run(weather, wellBehaved),
    exercised: { calls: 2 },
    bugs: {
      "a tool runs before its plugin's enabled record": {
        broken: async () => {
          const log = await run(weather, wellBehaved)
          const [first, ...rest] = log.steps
          assert.equal(first?.kind, 'prompt')
          const enables = first.events.filter((e) => e.type === 'record' && e.record.kind === 'enabled')
          const others = first.events.filter((e) => !enables.includes(e))
          const at = others.findIndex((e) => e.type === 'tool_start' && e.call.name === 'weather__get_weather') + 1
          return { ...log, steps: [{ ...first, events: [...others.slice(0, at), ...enables, ...others.slice(at)] }, ...rest] }
        },
        because: { violations: [{ step: 1, tool: 'weather__get_weather' }] },
      },
    },
  },
  'resume-keeps-plugins': {
    holds: () => run(weather, wellBehaved),
    exercised: { resumes: 1 },
    bugs: {
      'resume enables an enabled plugin again': {
        broken: async () => withMessages(await run(weather, wellBehaved), (ms) => [...ms, { role: 'aigent', record: { kind: 'enabled', plugin: 'weather', cause: 'host' }, timestamp: 0 }]),
        because: { violations: [{ step: 2, kind: 're-enabled', plugin: 'weather' }] },
      },
      'resume loses a saved enabled record': {
        broken: async () => withMessages(await run(weather, wellBehaved), (ms) => ms.filter((m) => !(isRecord('enabled')(m) && asMessage(m).record?.plugin === 'weather'))),
        because: { violations: [{ step: 2, kind: 'prefix' }] },
      },
    },
  },
  'denial-recorded': {
    holds: denied,
    exercised: { denials: 1 },
    bugs: {
      'a denial never reaches the record log': {
        broken: async () => withMessages(await denied(), (ms) => ms.filter((m) => !isRecord('denied')(m))),
        because: { missing: [{ step: 1, tool: 'weather__get_weather', plugin: 'guard' }] },
      },
    },
  },
  'enable-text-once': {
    holds: hostEnabled,
    exercised: { pending: 1 },
    bugs: {
      'host-enable text is delivered twice': {
        broken: async () => {
          const log = await hostEnabled()
          return editUser(log, (ms) => ms.findLastIndex((m) => asMessage(m).role === 'user'), (content) => `${content}\n\n${pendingText(log)}`)
        },
        because: { violations: [{ delivered: 2, first: true }] },
      },
      'host-enable text is never delivered': {
        broken: async () => {
          const log = await hostEnabled()
          return editUser(log, (ms) => ms.findIndex((m, i) => i > pendingIn(ms) && asMessage(m).role === 'user'), (content) => content.replace(pendingText(log), ''))
        },
        because: { violations: [{ delivered: 0, first: false }] },
      },
    },
  },
} satisfies Record<Invariant, InvariantCase>

for (const [name, c] of Object.entries(invariantCases) as [Invariant, InvariantCase][]) {
  for (const [bug, { broken, because }] of Object.entries(c.bugs)) {
    test(`${name} holds on a correct run and fails when ${bug}`, async () => {
      const held = check(await c.holds()).invariants[name]
      const verdict = check(await broken()).invariants[name]

      assert.equal(held.kind, 'pass', 'the correct run passes')
      assert.deepEqual(pick(held.evidence, c.exercised), c.exercised, 'the correct run exercised the invariant')
      assert.equal(verdict.kind, 'fail', 'the broken run fails')
      assert.deepEqual(pick(verdict.evidence, because), because, 'it fails for the bug the fault stands for')
    })
  }
}
