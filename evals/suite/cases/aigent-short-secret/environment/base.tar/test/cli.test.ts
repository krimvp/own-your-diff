// The CLI over the result directory, the contract the multeval grader will read: `aigent check` grades the files
// exactly as `check` grades the run in memory and exits by what the run went through, and `aigent run` refuses a
// directory that exists before it spends a model call.

import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { mkdir, mkdtemp, readdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { check } from '../src/eval/checks.ts'
import { runScenario, writeRun, type RunLog } from '../src/eval/run.ts'
import { parseScenario, readScenario, type Scenario } from '../src/eval/scenario.ts'
import { call, FAUX, fauxModel, reply, type Reply } from './fixtures/faux.ts'

// Before any run loads the weather plugin, which echoes it.
process.env.WEATHER_API_KEY = 'sk-canary-0123456789'
const CLI = join(import.meta.dirname, '..', 'src', 'cli.ts')
const root = join(import.meta.dirname, 'scenarios')

const aigent = (args: readonly string[], env: NodeJS.ProcessEnv = {}) => spawnSync(process.execPath, [CLI, ...args], { encoding: 'utf8', env: { ...process.env, ...env } })

async function run(scenario: Scenario, script: readonly Reply[]): Promise<RunLog> {
  const model = fauxModel(script)
  const log = await runScenario(scenario, { root, open: model.open, model: FAUX, toolMode: 'native', promptTimeoutMs: 5_000 })
  assert.equal(model.pending(), 0, 'the run used its whole script')
  return log
}

/** The run as if the engine had leaked a secret into its transcript: the scrub's mark is what secret-free reads. */
const leaked = (log: RunLog): RunLog => ({ ...log, transcript: { ...log.transcript, messages: [...log.transcript.messages, { role: 'user', content: '[LEAKED:WEATHER_API_KEY]', timestamp: 0 }] } })

const lisbon = [call('core__enable_plugin', { name: 'weather' }), call('weather__get_weather', { city: 'Lisbon' }), reply('It is 17°C in Lisbon right now.')]

test('aigent check prints the report check makes in memory, and exits by what the run went through', async () => {
  const held = await run(await readScenario(join(root, 'weather.json')), [...lisbon, call('weather__get_weather', { city: 'Porto' }), reply('Porto is at 17°C too.')])
  // The clock set lacks weather, which the saved records enabled, so the resume throws.
  const stopped = await run(
    parseScenario({ format: 'aigent-scenario/1', plugins: ['plugins/weather'], secrets: ['WEATHER_API_KEY'], systemPrompt: 'Test.', steps: [{ kind: 'prompt', text: 'Weather in Lisbon?' }, { kind: 'resume', plugins: ['plugins/clock'] }] }),
    lisbon,
  )
  const parent = await mkdtemp(join(tmpdir(), 'aigent-cli-'))
  const exits = { held: [held, 0], leaked: [leaked(held), 1], stopped: [stopped, 3], 'leaked and stopped': [leaked(stopped), 1] } as const

  for (const [name, [log, code]] of Object.entries(exits)) {
    await writeRun(join(parent, name), log)
    const child = aigent(['check', join(parent, name)])
    assert.equal(child.status, code, `${name}: ${child.stderr}`)
    assert.deepEqual(JSON.parse(child.stdout), check(log), `${name}: the files grade as the run`)
  }
  await mkdir(join(parent, 'empty'))
  const refused = aigent(['check', join(parent, 'empty')])
  assert.equal(refused.status, 2, 'a directory that holds no run is bad input')
  assert.equal(refused.stdout, '')
})

test('aigent run refuses an existing result directory before it calls a model', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'aigent-cli-'))
  // Everything else is in order, so only the directory can stop it; past that check the dead endpoint would fail later, as exit 4.
  const child = aigent(['run', join(root, 'weather.json'), '--out', dir, '--model', 'm', '--base-url', 'http://127.0.0.1:9'], { OLLAMA_API_KEY: 'unused' })

  assert.equal(child.status, 2, child.stderr)
  assert.ok(child.stderr.includes(dir), 'the refusal names the directory')
  assert.equal(child.stdout, '')
  assert.deepEqual(await readdir(dir), [])
})
