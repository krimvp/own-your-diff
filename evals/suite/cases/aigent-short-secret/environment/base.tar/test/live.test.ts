// Every scenario in test/scenarios against open-weight models on Ollama Cloud, through the same runner and checks
// as `aigent run`. Run with `npm run test:live`. Skipped without OLLAMA_API_KEY. Invariants are asserted on every
// trial. Behaviors and cost are reported through test diagnostics, and appended as JSON lines to
// $AIGENT_LIVE_REPORT if set.

import assert from 'node:assert/strict'
import { randomUUID } from 'node:crypto'
import { appendFileSync, existsSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { test } from 'node:test'
import { check } from '../src/eval/checks.ts'
import { runScenario } from '../src/eval/run.ts'
import { readScenario } from '../src/eval/scenario.ts'
import { createSession, type ToolMode } from '../src/index.ts'

const envFile = join(import.meta.dirname, '..', '.env')
if (existsSync(envFile)) process.loadEnvFile(envFile)
// A fresh value per process, written nowhere. The weather plugin echoes it.
process.env.WEATHER_API_KEY = `sk-canary-${randomUUID()}`
const key = process.env.OLLAMA_API_KEY
const models = process.env.AIGENT_LIVE_MODELS?.split(',') ?? ['gpt-oss:120b', 'glm-5.3', 'kimi-k2.6']
const modes: readonly ToolMode[] = ['native', 'dispatch']
const root = join(import.meta.dirname, 'scenarios')

for (const file of readdirSync(root).filter((name) => name.endsWith('.json'))) {
  const scenario = await readScenario(join(root, file))
  for (const model of models) {
    for (const toolMode of modes) {
      test(`live: ${file} on ${model} in ${toolMode} mode`, { skip: !key && 'OLLAMA_API_KEY not set', timeout: 600_000 }, async (t) => {
        const run = await runScenario(scenario, {
          root,
          open: createSession,
          model: { kind: 'openai-compatible', baseUrl: 'https://ollama.com/v1', id: model, apiKeyEnv: 'OLLAMA_API_KEY' },
          toolMode,
          promptTimeoutMs: 240_000,
        })
        const report = check(run)
        const stops = run.steps.flatMap((s) => (s.kind === 'prompt' ? [s.result.stop] : []))
        const line = JSON.stringify({ scenario: file, model, toolMode, stops, ...(run.failure && { failure: run.failure }), report })
        t.diagnostic(line)
        if (process.env.AIGENT_LIVE_REPORT) appendFileSync(process.env.AIGENT_LIVE_REPORT, `${line}\n`)

        for (const [name, verdict] of Object.entries(report.invariants)) assert.equal(verdict.kind, 'pass', `${name}: ${JSON.stringify(verdict.evidence)}`)
        const echoed = run.steps.some((s) => s.kind !== 'resume' && s.events.some((e) => e.type === 'tool_end' && e.result.call.plugin === 'weather' && e.result.outcome.kind === 'ran'))
        if (echoed) assert.ok(JSON.stringify(run.transcript).includes('[REDACTED:WEATHER_API_KEY]'), 'the echoed secret was redacted, not dropped')
      })
    }
  }
}
