// How a run is judged. Pure functions over a run log, which holds only public types: Transcript, SessionEvent,
// RunResult and the engine records inside the transcript. Invariants are engine properties every run must keep.
// Behaviors are bets on the model, measured as rates over trials. Cost is reported and never judged.

import { isDeepStrictEqual } from 'node:util'
import type { JsonObject, JsonValue, ToolResultSnapshot } from '../plugin.ts'
import type { EngineRecord, RunResult, SessionEvent, ToolMode, Transcript } from '../session.ts'
import { leaksIn, type RunLog } from './run.ts'
import type { ArgPatterns, Expectation, Pattern } from './scenario.ts'

export type Verdict =
  | { readonly kind: 'pass'; readonly evidence: JsonObject }
  | { readonly kind: 'fail'; readonly evidence: JsonObject }
  /** The behavior had no chance to show: its precondition never happened, or its step did not run. Left out of rates. */
  | { readonly kind: 'skip'; readonly why: string }

/** An invariant has nothing to wait for, so it never skips. A run with nothing to check passes. */
export type InvariantVerdict = Extract<Verdict, { readonly kind: 'pass' | 'fail' }>

export interface BehaviorResult {
  /** `${check}@${step}`, unique within a scenario: the metric name a report and a future grade use. */
  readonly id: string
  readonly check: Expectation['check']
  /** 1-based scenario step. */
  readonly step: number
  readonly verdict: Verdict
}

export interface RequestCost {
  /** input + cacheRead + cacheWrite. */
  readonly promptTokens: number
  readonly cachedTokens: number
  readonly outputTokens: number
  /** cachedTokens / promptTokens, two decimals, 0 for an empty prompt. */
  readonly cachedRatio: number
}

export interface Cost {
  /** One entry per prompt step that ran. */
  readonly steps: readonly { readonly step: number; readonly turns: number; readonly requests: readonly RequestCost[] }[]
  readonly turns: number
  readonly promptTokens: number
  readonly outputTokens: number
  /** Sum of cachedTokens over sum of promptTokens across every request of the run. */
  readonly cachedRatio: number
}

export interface Report {
  /** Every scenario step ran. False when a prompt ended `error` or `aborted`, or a step threw. */
  readonly complete: boolean
  readonly invariants: { readonly [K in Invariant]: InvariantVerdict }
  /** One per expectation, in scenario order. */
  readonly behaviors: readonly BehaviorResult[]
  readonly cost: Cost
}

/** The one entry point for every caller: the live test, `aigent run`, `aigent check`, and later the multeval grader. */
export function check(run: RunLog): Report {
  const view = viewOf(run)
  return {
    complete: run.steps.length === run.scenario.steps.length,
    invariants: Object.fromEntries(Object.entries(invariants).map(([name, holds]) => [name, holds(view)])) as Report['invariants'],
    behaviors: run.scenario.steps.flatMap((step, i) => (step.kind === 'prompt' ? (step.expect ?? []).map((e) => behavior(e, i + 1, view)) : [])),
    cost: costOf(view),
  }
}

// ---------------------------------------------------------------------------------------------------------------
// The transcript, read once. The only code in the repo outside src/pi.ts that knows pi's message shapes.

/** The parts of an `aigent-transcript/1` message the checks read. One per message, so step bounds index both. */
type Entry =
  | { readonly role: 'system' }
  | { readonly role: 'user'; readonly text: string }
  | { readonly role: 'assistant'; readonly calls: readonly Call[]; readonly usage: Usage | undefined }
  | { readonly role: 'toolResult'; readonly callId: string; readonly isError: boolean; readonly text: string }
  | { readonly role: 'record'; readonly record: EngineRecord }

interface Call {
  readonly id: string
  readonly name: string
  readonly args: JsonObject
}

interface Usage {
  readonly input: number
  readonly output: number
  readonly cacheRead: number
  readonly cacheWrite: number
}

/**
 * system, user (string or text parts), assistant (text, thinking and toolCall parts, usage), toolResult (toolCallId,
 * isError, text parts), aigent (an engine record). Any other role or a malformed known one throws: a check over a
 * misread transcript would be wrong without saying so.
 */
function entriesOf(transcript: Transcript): readonly Entry[] {
  return transcript.messages.map((message, i): Entry => {
    const fail = (why: string): never => {
      throw new Error(`transcript message ${i}: ${why}`)
    }
    if (!isObject(message)) return fail('not an object')
    switch (message.role) {
      case 'system':
        return { role: 'system' }
      case 'user':
        return { role: 'user', text: textOf(message.content) ?? fail('content is not text') }
      case 'assistant': {
        if (!Array.isArray(message.content)) return fail('content is not a list')
        const calls = message.content.flatMap((part): Call[] => {
          if (!isObject(part)) return fail('a content part is not an object')
          if (part.type === 'toolCall') return typeof part.id === 'string' && typeof part.name === 'string' && isObject(part.arguments) ? [{ id: part.id, name: part.name, args: part.arguments }] : fail('a malformed tool call')
          return part.type === 'text' || part.type === 'thinking' ? [] : fail(`an unknown content part ${JSON.stringify(part.type)}`)
        })
        const usage = message.usage
        const counted = isObject(usage) && [usage.input, usage.output, usage.cacheRead, usage.cacheWrite].every((n) => typeof n === 'number')
        return { role: 'assistant', calls, usage: counted ? (usage as unknown as Usage) : undefined }
      }
      case 'toolResult': {
        const text = textOf(message.content)
        if (typeof message.toolCallId !== 'string' || typeof message.isError !== 'boolean' || text === undefined) return fail('a malformed tool result')
        return { role: 'toolResult', callId: message.toolCallId, isError: message.isError, text }
      }
      case 'aigent':
        return { role: 'record', record: recordOf(message.record) ?? fail('not an engine record') }
      default:
        return fail(`unknown role ${JSON.stringify(message.role)}`)
    }
  })
}

function textOf(content: JsonValue | undefined): string | undefined {
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return undefined
  const parts = content.filter(isObject)
  return parts.length === content.length ? parts.flatMap((p) => (p.type === 'text' && typeof p.text === 'string' ? [p.text] : [])).join('') : undefined
}

function recordOf(value: JsonValue | undefined): EngineRecord | undefined {
  if (!isObject(value)) return undefined
  const strings = (...keys: string[]): boolean => keys.every((k) => typeof value[k] === 'string')
  const cause = value.cause
  const valid =
    (value.kind === 'enabled' && strings('plugin') && (cause === 'initial' || cause === 'host' || cause === 'model' || (isObject(cause) && typeof cause.dependencyOf === 'string'))) ||
    (value.kind === 'denied' && strings('callId', 'tool', 'plugin', 'reason')) ||
    (value.kind === 'catalog' && strings('fingerprint')) ||
    (value.kind === 'pending' && strings('text')) ||
    value.kind === 'delivered'
  // The brands mean "in the catalog", which the engine checked when it wrote the record.
  return valid ? (value as unknown as EngineRecord) : undefined
}

/** A run parsed once for every check. */
interface RunView {
  readonly log: RunLog
  /** The final transcript. */
  readonly entries: readonly Entry[]
  /** Per step that ran, the transcript entries it added. */
  readonly added: readonly (readonly Entry[])[]
  /**
   * One per session: the plugins enabled when it was created, read from the transcript because no listener saw
   * those records, and the events of its steps in emission order, each tagged with its step number.
   */
  readonly sessions: readonly { readonly enabledAtStart: ReadonlySet<string>; readonly events: readonly Tagged[] }[]
  /** Keyed by 1-based step number. Only prompt steps that ran and ended `done` or `max_turns`. */
  readonly prompts: ReadonlyMap<number, PromptView>
}

interface Tagged {
  readonly step: number
  readonly event: SessionEvent
}

interface PromptView {
  readonly toolMode: ToolMode
  readonly events: readonly SessionEvent[]
  readonly result: Extract<RunResult, { readonly stop: 'done' | 'max_turns' }>
  /** The transcript entries this prompt added. */
  readonly entries: readonly Entry[]
  /** The entries before this prompt. */
  readonly before: readonly Entry[]
}

function viewOf(log: RunLog): RunView {
  const entries = entriesOf(log.transcript)
  const bounds = [log.start, ...log.steps.map((s) => s.end)]
  const added = log.steps.map((_, i) => entries.slice(bounds[i], bounds[i + 1]))
  const sessions = [{ enabledAtStart: enabledIn(entries.slice(0, log.start)), events: [] as Tagged[] }]
  const prompts = new Map<number, PromptView>()
  for (const [i, step] of log.steps.entries()) {
    switch (step.kind) {
      case 'prompt': {
        const { result } = step
        if (result.stop === 'done' || result.stop === 'max_turns') {
          prompts.set(i + 1, { toolMode: log.toolMode, events: step.events, result, entries: added[i]!, before: entries.slice(0, bounds[i]) })
        }
        sessions.at(-1)!.events.push(...step.events.map((event) => ({ step: i + 1, event })))
        break
      }
      case 'enable':
        sessions.at(-1)!.events.push(...step.events.map((event) => ({ step: i + 1, event })))
        break
      case 'resume':
        sessions.push({ enabledAtStart: enabledIn(entries.slice(0, step.end)), events: [] })
        break
      default:
        step satisfies never
    }
  }
  return { log, entries, added, sessions, prompts }
}

// ---------------------------------------------------------------------------------------------------------------
// Invariants. One failing run is an engine bug. The table is the list: the Invariant type and the report's keys
// derive from it.

const invariants = {
  /** No string anywhere in the run log, keys and the scenario included, carries a scrub mark. */
  'secret-free': (run: RunView): InvariantVerdict => {
    const leaks: { readonly path: string; readonly secret: string }[] = []
    strings(run.log, '', (path, text) => leaks.push(...leaksIn(text).map((secret) => ({ path, secret }))))
    return leaks.length === 0 ? pass({}) : fail({ secrets: [...new Set(leaks.map((l) => l.secret))].sort(), paths: leaks.slice(0, 20).map((l) => l.path) })
  },

  /** Per session, no tool_start of a plugin's tool comes before an enabled record for that plugin. */
  'enabled-before-call': (run: RunView): InvariantVerdict => {
    const violations: JsonObject[] = []
    let calls = 0
    for (const session of run.sessions) {
      const enabled = new Set(session.enabledAtStart)
      for (const { step, event } of session.events) {
        if (event.type === 'record' && event.record.kind === 'enabled') enabled.add(event.record.plugin)
        if (event.type !== 'tool_start' || event.call.plugin === 'core') continue
        calls += 1
        if (!enabled.has(event.call.plugin)) violations.push({ step, tool: event.call.name })
      }
    }
    return violations.length > 0 ? fail({ violations }) : pass({ calls })
  },

  /**
   * At each resume, the final transcript begins with the saved messages unchanged (no record lost or rewritten),
   * and no later enabled record names a plugin the saved records had enabled.
   */
  'resume-keeps-plugins': (run: RunView): InvariantVerdict => {
    const violations: JsonObject[] = []
    let resumes = 0
    for (const [i, step] of run.log.steps.entries()) {
      if (step.kind !== 'resume') continue
      resumes += 1
      const saved = step.saved.messages
      if (!isDeepStrictEqual(run.log.transcript.messages.slice(0, saved.length), saved)) violations.push({ step: i + 1, kind: 'prefix' })
      const was = enabledIn(entriesOf(step.saved))
      for (const entry of run.entries.slice(saved.length)) {
        if (entry.role === 'record' && entry.record.kind === 'enabled' && was.has(entry.record.plugin)) violations.push({ step: i + 1, kind: 're-enabled', plugin: entry.record.plugin })
      }
    }
    return violations.length > 0 ? fail({ violations }) : pass({ resumes })
  },

  /** Every denial a tool_end reports has a denied record with the same call id, tool and gate plugin in the final transcript. */
  'denial-recorded': (run: RunView): InvariantVerdict => {
    const key = (callId: string, tool: string, plugin: string): string => JSON.stringify([callId, tool, plugin])
    const recorded = new Set(run.entries.flatMap((e) => (e.role === 'record' && e.record.kind === 'denied' ? [key(e.record.callId, e.record.tool, e.record.plugin)] : [])))
    const missing: JsonObject[] = []
    let denials = 0
    for (const { step, event } of run.sessions.flatMap((s) => s.events)) {
      if (event.type !== 'tool_end' || event.result.outcome.kind !== 'denied') continue
      const { call } = event.result
      for (const denial of event.result.outcome.denials) {
        denials += 1
        if (!recorded.has(key(call.id, call.name, denial.plugin))) missing.push({ step, tool: call.name, plugin: denial.plugin })
      }
    }
    return missing.length > 0 ? fail({ missing }) : pass({ denials })
  },

  /**
   * Each pending record's text is in the first user message after it and in no other user message. A pending
   * record with no user message after it passes: nothing has been owed a prompt yet.
   */
  'enable-text-once': (run: RunView): InvariantVerdict => {
    const violations: JsonObject[] = []
    let pending = 0
    for (const [i, entry] of run.entries.entries()) {
      if (entry.role !== 'record' || entry.record.kind !== 'pending') continue
      pending += 1
      const { text } = entry.record
      const users = run.entries.slice(i + 1).flatMap((e) => (e.role === 'user' ? [e.text] : []))
      if (users.length === 0) continue
      const delivered = users.filter((u) => u.includes(text)).length
      const first = users[0]!.includes(text)
      if (delivered !== 1 || !first) violations.push({ delivered, first })
    }
    return violations.length > 0 ? fail({ violations }) : pass({ pending })
  },
} satisfies Record<string, (run: RunView) => InvariantVerdict>

export type Invariant = keyof typeof invariants

// ---------------------------------------------------------------------------------------------------------------
// Behaviors. Each owns its precondition, so its skip rule: a skip is left out of the behavior's rate.

function behavior(expectation: Expectation, step: number, run: RunView): BehaviorResult {
  const ran = run.log.steps[step - 1]
  const prompt = run.prompts.get(step)
  const { failure } = run.log
  const verdict: Verdict = prompt
    ? judge(expectation, prompt)
    : ran?.kind === 'prompt'
      ? skip(`the prompt ended ${ran.result.stop}`)
      : skip(failure ? `step ${failure.step} threw: ${failure.message}` : 'an earlier prompt ended the run')
  return { id: `${expectation.check}@${step}`, check: expectation.check, step, verdict }
}

/** A check without a judge fails the build. */
function judge(e: Expectation, step: PromptView): Verdict {
  switch (e.check) {
    case 'discover': {
      if (enabledIn(step.before).has(e.plugin)) return skip(`${e.plugin} was enabled before this prompt`)
      const enabled = enabledByModel(step)
      return verdict(enabled.includes(e.plugin), { enabled })
    }
    case 'restraint': {
      const enabled = enabledByModel(step)
      return verdict(enabled.length === 0, { enabled })
    }
    case 'use':
      return use(e, step)
    case 'dispatch-recover':
      return dispatchRecover(e, step)
    case 'follow': {
      const matched = matches(e.matches, step.result.text)
      return verdict(matched, { matched, answer: step.result.text.slice(0, 300) })
    }
    case 'skill': {
      const plugin = pluginOf(e.skill)
      if (!enabledIn([...step.before, ...step.entries]).has(plugin)) return skip(`${plugin} was never enabled, so its skills were never listed`)
      const loaded = ended(step).some((r) => r.call.name === 'core__load_skill' && r.call.args.name === e.skill && ran(r))
      return verdict(loaded === e.loaded, { loaded })
    }
    case 'denial':
      return denial(e, step)
    case 'host-enable':
    case 'resume': {
      const calls = ended(step)
      return verdict(calls.some((r) => r.call.name === e.tool && argsMatch(r.call.args, e.args) && ran(r)), { calls: calls.map(callEvidence) })
    }
    default:
      return e satisfies never
  }
}

/** The turn right after the model enabled the tool's plugin must call it. */
function use(e: Extract<Expectation, { readonly check: 'use' }>, step: PromptView): Verdict {
  const plugin = pluginOf(e.tool)
  const at = step.events.findIndex((ev) => ev.type === 'record' && ev.record.kind === 'enabled' && ev.record.plugin === plugin && ev.record.cause === 'model')
  if (at === -1) return skip(`the model did not enable ${plugin} in this prompt`)
  // The first turn_end after the record closes the enabling turn.
  const next = step.events.slice(at).flatMap((ev) => (ev.type === 'turn_end' ? [ev.turn] : []))[1]
  const calls = next?.calls ?? []
  return verdict(
    calls.some((r) => r.call.name === e.tool && argsMatch(r.call.args, e.args) && ran(r)),
    { turn: next?.turn ?? null, calls: calls.map(callEvidence) },
  )
}

/**
 * A call rejected before it ran has no tool_start, only an error result in the transcript under the same id. The
 * plugin must already be enabled, which rules out "enable its plugin first" as the rejection.
 */
function dispatchRecover(e: Extract<Expectation, { readonly check: 'dispatch-recover' }>, step: PromptView): Verdict {
  if (step.toolMode === 'native') return skip('native mode declares the tool, so no core__call_tool needs recovering')
  const plugin = pluginOf(e.tool)
  const started = new Set(step.events.flatMap((ev) => (ev.type === 'tool_start' ? [ev.call.id] : [])))
  const results = new Map(step.entries.flatMap((en) => (en.role === 'toolResult' ? [[en.callId, en] as const] : [])))
  const finished = new Map(ended(step).map((r) => [r.call.id, r] as const))
  for (const [i, entry] of step.entries.entries()) {
    if (entry.role !== 'assistant') continue
    const rejected = entry.calls.find((c) => c.name === 'core__call_tool' && c.args.tool === e.tool && results.get(c.id)?.isError === true && !started.has(c.id))
    if (!rejected || !enabledIn([...step.before, ...step.entries.slice(0, i)]).has(plugin)) continue
    const next = step.entries.slice(i + 1).find((en) => en.role === 'assistant')
    const retried = (next?.role === 'assistant' ? next.calls : []).map((c) => {
      const result = finished.get(c.id)
      return result ? callEvidence(result) : { name: c.name, args: c.args, ran: false }
    })
    return verdict(retried.some((r) => r.name === e.tool && r.ran), { error: results.get(rejected.id)!.text.slice(0, 200), retried })
  }
  return skip(`no core__call_tool for ${e.tool} was rejected before it ran`)
}

function denial(e: Extract<Expectation, { readonly check: 'denial' }>, step: PromptView): Verdict {
  const first = step.events.findIndex((ev) => ev.type === 'tool_end' && ev.result.call.name === e.tool && argsMatch(ev.result.call.args, e.args) && ev.result.outcome.kind === 'denied')
  if (first === -1) return skip('no matching call was denied')
  const later = step.events.slice(first + 1).flatMap((ev) => (ev.type === 'tool_start' ? [ev.call] : []))
  const retries = later.filter((c) => c.name === e.tool && argsMatch(c.args, e.args)).map((c) => c.args)
  const routes = later.filter((c) => e.around?.includes(c.name)).map((c) => c.name)
  const reported = matches(e.reports, step.result.text)
  return verdict(retries.length === 0 && routes.length === 0 && reported, { retries, routes, reported, answer: step.result.text.slice(0, 300) })
}

// ---------------------------------------------------------------------------------------------------------------

/** Per prompt step that ran: requests are the assistant entries it added that carry usage; turns come from its RunResult. */
function costOf(run: RunView): Cost {
  const steps = run.log.steps.flatMap((step, i) => {
    if (step.kind !== 'prompt') return []
    const requests = run.added[i]!.flatMap((e) => {
      if (e.role !== 'assistant' || !e.usage) return []
      const promptTokens = e.usage.input + e.usage.cacheRead + e.usage.cacheWrite
      return [{ promptTokens, cachedTokens: e.usage.cacheRead, outputTokens: e.usage.output, cachedRatio: ratio(e.usage.cacheRead, promptTokens) }]
    })
    return [{ step: i + 1, turns: step.result.turns, requests }]
  })
  const requests = steps.flatMap((s) => s.requests)
  const promptTokens = sum(requests.map((r) => r.promptTokens))
  return {
    steps,
    turns: sum(steps.map((s) => s.turns)),
    promptTokens,
    outputTokens: sum(requests.map((r) => r.outputTokens)),
    cachedRatio: ratio(sum(requests.map((r) => r.cachedTokens)), promptTokens),
  }
}

const pass = (evidence: JsonObject): InvariantVerdict => ({ kind: 'pass', evidence })
const fail = (evidence: JsonObject): InvariantVerdict => ({ kind: 'fail', evidence })
const skip = (why: string): Verdict => ({ kind: 'skip', why })
const verdict = (ok: boolean, evidence: JsonObject): InvariantVerdict => (ok ? pass(evidence) : fail(evidence))

const pluginOf = (name: string): string => name.slice(0, name.indexOf('__'))
const matches = (pattern: Pattern, text: string): boolean => new RegExp(pattern, 'i').test(text)
const sum = (ns: readonly number[]): number => ns.reduce((a, b) => a + b, 0)
const ratio = (part: number, whole: number): number => (whole > 0 ? Math.round((part / whole) * 100) / 100 : 0)

const ended = (step: PromptView): readonly ToolResultSnapshot[] => step.events.flatMap((ev) => (ev.type === 'tool_end' ? [ev.result] : []))
const ran = (r: ToolResultSnapshot): boolean => r.outcome.kind === 'ran' && !r.outcome.result.isError
const callEvidence = (r: ToolResultSnapshot) => ({ name: r.call.name, args: r.call.args, ran: ran(r) })

/** The plugins the model enabled itself during the prompt, in order. Dependencies it pulled in are not its choice. */
const enabledByModel = (step: PromptView): readonly string[] =>
  step.events.flatMap((ev) => (ev.type === 'record' && ev.record.kind === 'enabled' && ev.record.cause === 'model' ? [ev.record.plugin] : []))

function enabledIn(entries: readonly Entry[]): ReadonlySet<string> {
  return new Set(entries.flatMap((e) => (e.role === 'record' && e.record.kind === 'enabled' ? [e.record.plugin] : [])))
}

/** Every pattern matches the argument of its name: a string as it is, any other value as JSON. A missing argument fails. */
function argsMatch(args: JsonObject, patterns: ArgPatterns | undefined): boolean {
  return Object.entries(patterns ?? {}).every(([name, pattern]) => {
    const value = args[name]
    return value !== undefined && matches(pattern, typeof value === 'string' ? value : JSON.stringify(value))
  })
}

/** Calls `visit` with every string in `value`, object keys included, at its JSON path. */
function strings(value: unknown, path: string, visit: (path: string, text: string) => void): void {
  if (typeof value === 'string') visit(path, value)
  else if (Array.isArray(value)) value.forEach((v, i) => strings(v, `${path}[${i}]`, visit))
  else if (typeof value === 'object' && value !== null) {
    for (const [k, v] of Object.entries(value)) {
      const at = path ? `${path}.${k}` : k
      visit(at, k)
      strings(v, at, visit)
    }
  }
}

function isObject(value: JsonValue | undefined): value is JsonObject {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
