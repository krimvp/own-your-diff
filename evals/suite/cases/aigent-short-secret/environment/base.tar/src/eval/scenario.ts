// What a scenario author writes, and the one place a scenario file is validated. A scenario is a JSON script of
// steps over one session. The runner (run.ts) interprets the steps; the checks (checks.ts) judge the expectations.

import { readFile } from 'node:fs/promises'
import { isAbsolute, normalize } from 'node:path'

declare const patternBrand: unique symbol
/** A regex source that compiled. Always matched case-insensitively. */
export type Pattern = string & { readonly [patternBrand]: true }

/** Argument name to the pattern its value must match: a string as it is, any other value as JSON. */
export type ArgPatterns = Readonly<Record<string, Pattern>>

/**
 * One behavior judged on one prompt step. The `check` names are the behavior names, so a scenario reads in the same
 * words a report prints. Tool names are model-facing `<plugin>__<tool>`; the plugin is the part before `__`.
 */
export type Expectation =
  /** The model enables `plugin` during this prompt. */
  | { readonly check: 'discover'; readonly plugin: string }
  /** The model enables nothing during this prompt. */
  | { readonly check: 'restraint' }
  /** In the turn right after the model enabled `tool`'s plugin, it calls `tool` with matching args and the call runs. */
  | { readonly check: 'use'; readonly tool: string; readonly args?: ArgPatterns }
  /** Dispatch mode. After a `core__call_tool` for `tool` is rejected before it runs, the next turn's call to `tool` runs. */
  | { readonly check: 'dispatch-recover'; readonly tool: string }
  /** The final answer matches `matches`, as for an instruction delivered in an enable result. */
  | { readonly check: 'follow'; readonly matches: Pattern }
  /** The model loads `skill` (`<plugin>__<skill>`) during this prompt, or does not, as `loaded` says. */
  | { readonly check: 'skill'; readonly skill: string; readonly loaded: boolean }
  /**
   * After a gate denies a call to `tool` with matching args, the model calls neither `tool` with matching args again
   * nor any tool in `around`, and its answer matches `reports`.
   */
  | { readonly check: 'denial'; readonly tool: string; readonly args?: ArgPatterns; readonly reports: Pattern; readonly around?: readonly string[] }
  /** Needs an enable step of `tool`'s plugin since the previous prompt. The model calls `tool` and the call runs. */
  | { readonly check: 'host-enable'; readonly tool: string; readonly args?: ArgPatterns }
  /** Needs a resume step since the previous prompt. The model calls `tool` and the call runs. */
  | { readonly check: 'resume'; readonly tool: string; readonly args?: ArgPatterns }

export type ScenarioStep =
  /** `expect` holds the behaviors judged on this prompt, one per check. Invariants need no declaration. */
  | { readonly kind: 'prompt'; readonly text: string; readonly expect?: readonly Expectation[] }
  /** A host enable between prompts. */
  | { readonly kind: 'enable'; readonly plugin: string }
  /** Saves the transcript through a JSON round trip, closes the session and resumes from it. `plugins` replaces the plugin set. */
  | { readonly kind: 'resume'; readonly plugins?: readonly string[] }

export interface Scenario {
  readonly format: 'aigent-scenario/1'
  /** Plugin directories relative to the scenario file. Each is loaded with loadPlugins and the sets are concatenated. */
  readonly plugins: readonly string[]
  /** Enabled at start. Passed again on every resume, where names already enabled are skipped. */
  readonly enabled?: readonly string[]
  /**
   * Env var names holding host secrets. Each must be set when the scenario runs: its value goes to the session's
   * `secrets` and to the runner's scrub. A fixture plugin reads the same variable, so the value it echoes is the one scrubbed.
   */
  readonly secrets?: readonly string[]
  readonly systemPrompt: string
  /** Model turns per prompt. The session default applies when absent. */
  readonly maxTurns?: number
  /** Non-empty. A step's number, in check ids and result files, is its 1-based position here. */
  readonly steps: readonly ScenarioStep[]
}

export class ScenarioError extends Error {
  readonly problems: readonly string[]
  constructor(problems: readonly string[]) {
    super(`invalid scenario:\n- ${problems.join('\n- ')}`)
    this.problems = problems
  }
}

export async function readScenario(file: string): Promise<Scenario> {
  let value: unknown
  try {
    value = JSON.parse(await readFile(file, 'utf8'))
  } catch (error) {
    throw new ScenarioError([`${file}: ${error instanceof Error ? error.message : String(error)}`])
  }
  return parseScenario(value)
}

/**
 * The scenario boundary, also used by readRun for the copy a result directory keeps. Collects every problem, each
 * at its JSON path, before throwing ScenarioError. Unknown fields are problems too, so a misspelled `expect` is not
 * silently a scenario without behaviors.
 */
export function parseScenario(value: unknown): Scenario {
  const p = new Problems()
  const raw = fields(value, '', ['format', 'plugins', 'enabled', 'secrets', 'systemPrompt', 'maxTurns', 'steps'], p)
  if (raw.format !== 'aigent-scenario/1') p.fail('format: must be "aigent-scenario/1"', undefined)
  const plugins = directories(raw.plugins, 'plugins', p)
  const systemPrompt = typeof raw.systemPrompt === 'string' ? raw.systemPrompt : p.fail('systemPrompt: must be a string', '')
  const maxTurns = raw.maxTurns === undefined || (typeof raw.maxTurns === 'number' && Number.isInteger(raw.maxTurns) && raw.maxTurns > 0) ? raw.maxTurns : p.fail('maxTurns: must be a positive integer', undefined)
  const rawSteps = Array.isArray(raw.steps) && raw.steps.length > 0 ? (raw.steps as readonly unknown[]) : p.fail('steps: must be a non-empty list', [])
  const steps: ScenarioStep[] = []
  for (const [i, raw] of rawSteps.entries()) {
    const step = parseStep(raw, `steps[${i}]`, steps.slice(steps.findLastIndex((s) => s.kind === 'prompt') + 1), p)
    if (step) steps.push(step)
  }
  const scenario: Scenario = {
    format: 'aigent-scenario/1',
    plugins,
    ...(raw.enabled !== undefined && { enabled: names(raw.enabled, 'enabled', PLUGIN, p) }),
    ...(raw.secrets !== undefined && { secrets: names(raw.secrets, 'secrets', ENV_NAME, p) }),
    systemPrompt,
    ...(maxTurns !== undefined && { maxTurns }),
    steps,
  }
  if (p.list.length > 0) throw new ScenarioError(p.list)
  return scenario
}

export interface Names {
  readonly plugins: readonly string[]
  readonly tools: readonly string[]
  readonly skills: readonly string[]
}

/** Names an expectation relies on, so the runner can refuse a scenario that misspells one before a paid run. */
export function referencedNames(expectation: Expectation): Names {
  switch (expectation.check) {
    case 'discover':
      return { plugins: [expectation.plugin], tools: [], skills: [] }
    case 'restraint':
    case 'follow':
      return { plugins: [], tools: [], skills: [] }
    case 'use':
    case 'dispatch-recover':
    case 'host-enable':
    case 'resume':
      return { plugins: [], tools: [expectation.tool], skills: [] }
    case 'skill':
      return { plugins: [], tools: [], skills: [expectation.skill] }
    case 'denial':
      return { plugins: [], tools: [expectation.tool, ...(expectation.around ?? [])], skills: [] }
    default:
      return expectation satisfies never
  }
}

const PLUGIN = /^[a-z0-9-]+$/
const TOOL = /^[a-z0-9-]+__[A-Za-z0-9_-]+$/
const SKILL = /^[a-z0-9-]+__[a-z0-9_-]+$/
const ENV_NAME = /^[A-Z_][A-Z0-9_]*$/

/** `since` holds the steps between the previous prompt and this one. An unknown kind has no value to stand in for it. */
function parseStep(value: unknown, at: string, since: readonly ScenarioStep[], p: Problems): ScenarioStep | undefined {
  const kind = isRecord(value) ? value.kind : undefined
  switch (kind) {
    case 'prompt': {
      const raw = fields(value, at, ['kind', 'text', 'expect'], p)
      const text = typeof raw.text === 'string' && raw.text !== '' ? raw.text : p.fail(`${at}.text: must be a non-empty string`, '')
      if (raw.expect === undefined) return { kind, text }
      if (!Array.isArray(raw.expect)) return p.fail(`${at}.expect: must be a list`, { kind, text })
      const expect: Expectation[] = []
      for (const [j, e] of (raw.expect as readonly unknown[]).entries()) {
        const parsed = parseExpectation(e, `${at}.expect[${j}]`, since, p)
        if (!parsed) continue
        if (expect.some((other) => other.check === parsed.check)) p.fail(`${at}.expect[${j}]: a second "${parsed.check}" on one step would share its id`, undefined)
        expect.push(parsed)
      }
      return { kind, text, expect }
    }
    case 'enable': {
      const raw = fields(value, at, ['kind', 'plugin'], p)
      return { kind, plugin: name(raw.plugin, `${at}.plugin`, PLUGIN, p) }
    }
    case 'resume': {
      const raw = fields(value, at, ['kind', 'plugins'], p)
      return raw.plugins === undefined ? { kind } : { kind, plugins: directories(raw.plugins, `${at}.plugins`, p) }
    }
    default:
      return p.fail(`${at}.kind: must be "prompt", "enable" or "resume"`, undefined)
  }
}

type Check = Expectation['check']

/** One parser per check. A check without one fails the build. */
const expectations: {
  readonly [K in Check]: (raw: Readonly<Record<string, unknown>>, at: string, since: readonly ScenarioStep[], p: Problems) => Extract<Expectation, { readonly check: K }>
} = {
  discover: (raw, at, _, p) => ({ check: 'discover', plugin: name(raw.plugin, `${at}.plugin`, PLUGIN, p) }),
  restraint: () => ({ check: 'restraint' }),
  use: (raw, at, _, p) => ({ check: 'use', ...called(raw, at, p) }),
  'dispatch-recover': (raw, at, _, p) => ({ check: 'dispatch-recover', tool: name(raw.tool, `${at}.tool`, TOOL, p) }),
  follow: (raw, at, _, p) => ({ check: 'follow', matches: pattern(raw.matches, `${at}.matches`, p) }),
  skill: (raw, at, _, p) => ({
    check: 'skill',
    skill: name(raw.skill, `${at}.skill`, SKILL, p),
    loaded: typeof raw.loaded === 'boolean' ? raw.loaded : p.fail(`${at}.loaded: must be true or false`, false),
  }),
  denial: (raw, at, _, p) => ({
    check: 'denial',
    ...called(raw, at, p),
    reports: pattern(raw.reports, `${at}.reports`, p),
    ...(raw.around !== undefined && { around: names(raw.around, `${at}.around`, TOOL, p) }),
  }),
  'host-enable': (raw, at, since, p) => {
    const call = called(raw, at, p)
    const plugin = call.tool.split('__')[0]
    if (call.tool && !since.some((s) => s.kind === 'enable' && s.plugin === plugin)) p.fail(`${at}: needs an enable step of "${plugin}" since the previous prompt`, undefined)
    return { check: 'host-enable', ...call }
  },
  resume: (raw, at, since, p) => {
    if (!since.some((s) => s.kind === 'resume')) p.fail(`${at}: needs a resume step since the previous prompt`, undefined)
    return { check: 'resume', ...called(raw, at, p) }
  },
}

/** The fields each check takes besides `check`. */
const FIELDS: { readonly [K in Check]: readonly string[] } = {
  discover: ['plugin'],
  restraint: [],
  use: ['tool', 'args'],
  'dispatch-recover': ['tool'],
  follow: ['matches'],
  skill: ['skill', 'loaded'],
  denial: ['tool', 'args', 'reports', 'around'],
  'host-enable': ['tool', 'args'],
  resume: ['tool', 'args'],
}

function parseExpectation(value: unknown, at: string, since: readonly ScenarioStep[], p: Problems): Expectation | undefined {
  const check = isRecord(value) ? value.check : undefined
  if (typeof check !== 'string' || !Object.hasOwn(expectations, check)) return p.fail(`${at}.check: must be one of ${Object.keys(expectations).join(', ')}`, undefined)
  return expectations[check as Check](fields(value, at, ['check', ...FIELDS[check as Check]], p), at, since, p)
}

/** `tool` and optional `args`, shared by the checks about one call. */
function called(raw: Readonly<Record<string, unknown>>, at: string, p: Problems): { readonly tool: string; readonly args?: ArgPatterns } {
  const tool = name(raw.tool, `${at}.tool`, TOOL, p)
  if (raw.args === undefined) return { tool }
  if (!isRecord(raw.args)) return p.fail(`${at}.args: must be an object of patterns`, { tool })
  return { tool, args: Object.fromEntries(Object.entries(raw.args).map(([k, v]) => [k, pattern(v, `${at}.args.${k}`, p)])) }
}

/** Every problem of one parse. `fail` records one and hands back a placeholder, so a single pass finds them all. */
class Problems {
  readonly list: string[] = []
  fail<T>(problem: string, placeholder: T): T {
    this.list.push(problem)
    return placeholder
  }
}

function fields(value: unknown, at: string, known: readonly string[], p: Problems): Readonly<Record<string, unknown>> {
  if (!isRecord(value)) return p.fail(`${at || 'scenario'}: must be an object`, {})
  for (const key of Object.keys(value)) if (!known.includes(key)) p.fail(`${at ? `${at}.` : ''}${key}: unknown field`, undefined)
  return value
}

function name(value: unknown, at: string, shape: RegExp, p: Problems): string {
  return typeof value === 'string' && shape.test(value) ? value : p.fail(`${at}: must match ${shape.source}`, '')
}

function names(value: unknown, at: string, shape: RegExp, p: Problems): readonly string[] {
  return Array.isArray(value) ? value.map((v: unknown, i) => name(v, `${at}[${i}]`, shape, p)) : p.fail(`${at}: must be a list`, [])
}

/** Non-empty, relative and inside the scenario's directory, because a multeval case carries only that directory. */
function directories(value: unknown, at: string, p: Problems): readonly string[] {
  if (!Array.isArray(value) || value.length === 0) return p.fail(`${at}: must be a non-empty list of directories`, [])
  return value.map((dir: unknown, i) =>
    typeof dir === 'string' && dir !== '' && !isAbsolute(dir) && normalize(dir).split(/[\\/]/)[0] !== '..' ? dir : p.fail(`${at}[${i}]: must be a directory inside the scenario's own`, ''),
  )
}

function pattern(value: unknown, at: string, p: Problems): Pattern {
  if (typeof value !== 'string') return p.fail(`${at}: must be a regex source`, '' as Pattern)
  try {
    new RegExp(value, 'i')
  } catch (error) {
    p.fail(`${at}: does not compile: ${error instanceof Error ? error.message : String(error)}`, undefined)
  }
  return value as Pattern
}

function isRecord(value: unknown): value is Readonly<Record<string, unknown>> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
