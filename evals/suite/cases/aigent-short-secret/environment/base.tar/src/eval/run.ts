// Running a scenario, and the result directory a run leaves. A run log is what the sessions did, scrubbed so it holds
// no raw secret value. The result directory is the run log as files and the whole input to checks: `aigent run`
// grades the files it just wrote, never its memory.

import { randomUUID } from 'node:crypto'
import { mkdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { loadPlugins, parseCatalog, type Catalog } from '../catalog.ts'
import type { Plugin } from '../plugin.ts'
import type { ModelSpec, RunResult, Session, SessionEvent, SessionOptions, ToolMode, Transcript } from '../session.ts'
import { parseScenario, referencedNames, ScenarioError, type Names, type Scenario, type ScenarioStep } from './scenario.ts'

export interface RunOptions {
  /** The directory the scenario's plugin paths are relative to, normally the scenario file's directory. */
  readonly root: string
  /** `createSession` for a real model. Tests pass a faux model's opener, which continues one script across sessions. */
  readonly open: (options: SessionOptions) => Promise<Session>
  readonly model: ModelSpec
  readonly toolMode: ToolMode
  /** Per prompt step. A prompt past it ends `aborted`, which ends the run. */
  readonly promptTimeoutMs: number
  /** Aborts the running prompt, which ends the run. The steps already taken are still returned. */
  readonly signal?: AbortSignal
  /** After each step that completed, with its 1-based number. Scrubbed like the log. */
  readonly onStep?: (step: number, log: StepLog) => void
}

/**
 * What one scenario run did. JSON-shaped, so a result directory round-trips it exactly.
 *
 * Every string has passed the scrub: a raw secret value appears only as the mark `secret-free` fails on. Adjacent
 * text deltas are joined into one text event first, so the scrub sees whole strings.
 */
export interface RunLog {
  readonly format: 'aigent-run/1'
  readonly scenario: Scenario
  readonly model: ModelSpec
  readonly toolMode: ToolMode
  /**
   * Transcript length once the first session exists: the system prompt and the records written at creation.
   * Those records reach no listener, because nobody can subscribe before the session is returned.
   */
  readonly start: number
  /**
   * `steps[i]` is what happened at `scenario.steps[i]`. Shorter than the scenario when a prompt ended `error` or
   * `aborted`, which is its last step, or when a step threw.
   */
  readonly steps: readonly StepLog[]
  /** The step that threw and ended the run there, such as a resume whose plugin set rejects the saved records. */
  readonly failure?: { readonly step: number; readonly message: string }
  /** The last session's transcript after it closed. Begins with every saved transcript's messages. */
  readonly transcript: Transcript
}

/** `end` is the transcript length after the step, so a step's messages are `transcript.messages.slice(previous end, end)`. */
export type StepLog =
  | { readonly kind: 'prompt'; readonly result: RunResult; readonly events: readonly SessionEvent[]; readonly end: number }
  | { readonly kind: 'enable'; readonly events: readonly SessionEvent[]; readonly end: number }
  /** `saved` is the JSON the new session resumed from. `end` counts the records the new session wrote at creation. */
  | { readonly kind: 'resume'; readonly saved: Transcript; readonly end: number }

/**
 * Runs every step on sessions from `options.open`. Throws ScenarioError before the first session opens when a
 * secret or the model key is unset, a plugin set does not load, or the scenario names a plugin, tool or skill its
 * set lacks. A provider error, an abort or a throwing step is not a throw: it ends the run, and the log says where.
 */
export async function runScenario(scenario: Scenario, options: RunOptions): Promise<RunLog> {
  const problems: string[] = []
  const env = (name: string): readonly [string, string] => {
    const value = process.env[name] ?? ''
    if (!value) problems.push(`${name}: not set in the environment`)
    return [name, value]
  }
  const secrets = Object.fromEntries((scenario.secrets ?? []).map(env))
  // The adapter redacts the model key itself; the runner only needs it to scrub.
  const scrubbed = options.model.kind === 'openai-compatible' ? { ...secrets, ...Object.fromEntries([env(options.model.apiKeyEnv)]) } : secrets
  const pluginsOf = await loadPluginSets(scenario, options.root, problems)
  if (problems.length > 0) throw new ScenarioError(problems)

  const base = {
    model: options.model,
    toolMode: options.toolMode,
    secrets,
    ...(scenario.enabled && { enabled: scenario.enabled }),
    ...(scenario.maxTurns !== undefined && { maxTurns: scenario.maxTurns }),
  }
  let plugins = pluginsOf(scenario.plugins)
  let session = await options.open({ ...base, plugins, systemPrompt: scenario.systemPrompt })
  const start = session.transcript().messages.length
  let events: SessionEvent[] = []
  const record = (opened: Session): void => {
    opened.subscribe((event) => {
      const last = events.at(-1)
      if (event.type === 'text' && last?.type === 'text') events[events.length - 1] = { type: 'text', delta: last.delta + event.delta }
      else events.push(event)
    })
  }
  record(session)
  const length = (): number => session.transcript().messages.length

  const take = async (step: ScenarioStep): Promise<StepLog> => {
    switch (step.kind) {
      case 'prompt': {
        events = []
        const signal = AbortSignal.any([AbortSignal.timeout(options.promptTimeoutMs), ...(options.signal ? [options.signal] : [])])
        const result = await session.prompt(step.text, { signal })
        return { kind: 'prompt', result, events, end: length() }
      }
      case 'enable':
        events = []
        await session.enable(step.plugin)
        return { kind: 'enable', events, end: length() }
      case 'resume': {
        const saved: Transcript = JSON.parse(JSON.stringify(session.transcript()))
        await session.close()
        if (step.plugins) plugins = pluginsOf(step.plugins)
        session = await options.open({ ...base, plugins, transcript: saved })
        record(session)
        return { kind: 'resume', saved, end: length() }
      }
      default:
        return step satisfies never
    }
  }

  const steps: StepLog[] = []
  let failure: RunLog['failure']
  for (const [i, step] of scenario.steps.entries()) {
    let log: StepLog
    try {
      log = await take(step)
    } catch (error) {
      failure = { step: i + 1, message: messageOf(error) }
      break
    }
    steps.push(log)
    options.onStep?.(i + 1, scrub(log, scrubbed))
    if (log.kind === 'prompt' && (log.result.stop === 'error' || log.result.stop === 'aborted')) break
  }
  await session.close()
  const run: RunLog = { format: 'aigent-run/1', scenario, model: options.model, toolMode: options.toolMode, start, steps, ...(failure && { failure }), transcript: session.transcript() }
  return scrub(run, scrubbed)
}

/** The secret names whose raw values a string held before the scrub marked them. Read by `secret-free`. */
export function leaksIn(text: string): readonly string[] {
  return [...text.matchAll(/\[LEAKED:([^\]]+)\]/g)].map((m) => m[1]!)
}

/** Every string in `value`, keys included, with each raw secret value replaced by its mark, longest value first. */
function scrub<T>(value: T, secrets: Readonly<Record<string, string>>): T {
  const entries = Object.entries(secrets)
    .filter(([, raw]) => raw.length > 0)
    .sort(([, a], [, b]) => b.length - a.length)
  const text = (s: string): string => entries.reduce((out, [name, raw]) => out.split(raw).join(`[LEAKED:${name}]`), s)
  const walk = (v: unknown): unknown => {
    if (typeof v === 'string') return text(v)
    if (Array.isArray(v)) return v.map(walk)
    if (typeof v === 'object' && v !== null) return Object.fromEntries(Object.entries(v).map(([k, x]) => [text(k), walk(x)]))
    return v
  }
  return walk(value) as T
}

/**
 * Loads every plugin set the scenario uses, and checks each name it relies on against the set in effect at that
 * step, so a misspelling costs no model call. Returns the loaded sets by their directory lists.
 */
async function loadPluginSets(scenario: Scenario, root: string, problems: string[]): Promise<(dirs: readonly string[]) => readonly Plugin[]> {
  const sets = new Map<string, { readonly plugins: readonly Plugin[]; readonly catalog: Catalog } | undefined>()
  const lists: (readonly [string, readonly string[]])[] = [['plugins', scenario.plugins]]
  for (const [i, step] of scenario.steps.entries()) if (step.kind === 'resume' && step.plugins) lists.push([`steps[${i}].plugins`, step.plugins])
  for (const [at, dirs] of lists) {
    const key = JSON.stringify(dirs)
    if (sets.has(key)) continue
    try {
      const plugins = (await Promise.all(dirs.map((dir) => loadPlugins(join(root, dir))))).flat()
      sets.set(key, { plugins, catalog: parseCatalog(plugins) })
    } catch (error) {
      problems.push(`${at}: ${messageOf(error)}`)
      sets.set(key, undefined)
    }
  }

  const need = (at: string, dirs: readonly string[], names: Names): void => {
    const set = sets.get(JSON.stringify(dirs))
    if (!set) return
    const tools = new Set<string>(set.catalog.tools.keys())
    const missing = [
      ...names.plugins.filter((n) => !set.catalog.pluginName(n)).map((n) => `plugin "${n}"`),
      ...names.tools.filter((n) => !tools.has(n)).map((n) => `tool "${n}"`),
      ...names.skills.filter((n) => !set.catalog.skills.has(n)).map((n) => `skill "${n}"`),
    ]
    for (const what of missing) problems.push(`${at}: no ${what} in ${dirs.join(', ')}`)
  }
  const enabled: Names = { plugins: scenario.enabled ?? [], tools: [], skills: [] }
  let dirs = scenario.plugins
  need('enabled', dirs, enabled)
  for (const [i, step] of scenario.steps.entries()) {
    switch (step.kind) {
      case 'prompt':
        for (const [j, expectation] of (step.expect ?? []).entries()) need(`steps[${i}].expect[${j}]`, dirs, referencedNames(expectation))
        break
      case 'enable':
        need(`steps[${i}].plugin`, dirs, { plugins: [step.plugin], tools: [], skills: [] })
        break
      case 'resume':
        if (!step.plugins) break
        dirs = step.plugins
        // Every resume passes `enabled` again.
        need(`steps[${i}].plugins`, dirs, enabled)
        break
      default:
        step satisfies never
    }
  }
  // Only called once `problems` is empty, so every set loaded.
  return (list) => sets.get(JSON.stringify(list))!.plugins
}

const RUN_FILE = 'run.json'
const TRANSCRIPT_FILE = 'transcript.json'
const EVENTS_FILE = 'events.jsonl'
const resumeFile = (step: number): string => `resume-${step}.json`

/** run.json: the run log without its event lists and transcripts, which have files of their own. */
type RunFile = Omit<RunLog, 'steps' | 'transcript'> & {
  readonly steps: readonly (
    | { readonly kind: 'prompt'; readonly result: RunResult; readonly end: number }
    | { readonly kind: 'enable'; readonly end: number }
    | { readonly kind: 'resume'; readonly end: number }
  )[]
}

/**
 * Writes the run log as a result directory, all or nothing: the files go to a sibling temp directory that is
 * renamed into place, so `dir` holds a whole run or does not exist. Rejects when `dir` exists. A crash leaves only
 * a `<dir>.partial-*` sibling, which no reader mistakes for a run.
 *
 *   <dir>/run.json         RunFile
 *   <dir>/transcript.json  the final Transcript
 *   <dir>/events.jsonl     {"step": n, "event": SessionEvent} per line, in emission order; prompt and enable steps only
 *   <dir>/resume-<n>.json  the Transcript step n saved and resumed from, one per resume step
 */
export async function writeRun(dir: string, run: RunLog): Promise<void> {
  // Checked first, because rename silently replaces an empty directory.
  if (await exists(dir)) throw new Error(`${dir} already exists`)
  await mkdir(dirname(dir), { recursive: true })
  const tmp = `${dir}.partial-${randomUUID()}`
  await mkdir(tmp)
  try {
    const { steps, transcript, ...head } = run
    const file: RunFile = {
      ...head,
      steps: steps.map((step) => {
        switch (step.kind) {
          case 'prompt':
            return { kind: step.kind, result: step.result, end: step.end }
          case 'enable':
          case 'resume':
            return { kind: step.kind, end: step.end }
          default:
            return step satisfies never
        }
      }),
    }
    const lines = steps.flatMap((step, i) => (step.kind === 'resume' ? [] : step.events.map((event) => `${JSON.stringify({ step: i + 1, event })}\n`)))
    await writeFile(join(tmp, RUN_FILE), `${JSON.stringify(file, null, 2)}\n`)
    await writeFile(join(tmp, TRANSCRIPT_FILE), `${JSON.stringify(transcript)}\n`)
    await writeFile(join(tmp, EVENTS_FILE), lines.join(''))
    for (const [i, step] of steps.entries()) if (step.kind === 'resume') await writeFile(join(tmp, resumeFile(i + 1)), `${JSON.stringify(step.saved)}\n`)
    await rename(tmp, dir)
  } catch (error) {
    await rm(tmp, { recursive: true, force: true })
    throw error
  }
}

export class RunFileError extends Error {
  readonly problems: readonly string[]
  constructor(dir: string, problems: readonly string[]) {
    super(`${dir} is not an aigent-run/1 result directory:\n- ${problems.join('\n- ')}`)
    this.problems = problems
  }
}

/**
 * The result-directory boundary, for `aigent check` and the future multeval grader. Parses what writeRun wrote
 * back into the identical RunLog, and throws RunFileError naming every problem rather than guessing. Past the
 * type tag of each event, events and transcript messages are trusted as written.
 */
export async function readRun(dir: string): Promise<RunLog> {
  const problems: string[] = []
  const read = async (name: string): Promise<string | undefined> => {
    try {
      return await readFile(join(dir, name), 'utf8')
    } catch (error) {
      problems.push(`${name}: ${messageOf(error)}`)
      return undefined
    }
  }
  const json = async (name: string): Promise<unknown> => {
    const text = await read(name)
    if (text === undefined) return undefined
    try {
      return JSON.parse(text)
    } catch (error) {
      problems.push(`${name}: ${messageOf(error)}`)
      return undefined
    }
  }
  const transcriptIn = async (name: string): Promise<Transcript> => {
    const value = await json(name)
    if (isRecord(value) && value.format === 'aigent-transcript/1' && Array.isArray(value.messages)) return value as unknown as Transcript
    if (value !== undefined) problems.push(`${name}: not an aigent-transcript/1 transcript`)
    return { format: 'aigent-transcript/1', messages: [] }
  }

  const head = parseRunFile(await json(RUN_FILE), problems)
  const transcript = await transcriptIn(TRANSCRIPT_FILE)
  const events = new Map<number, SessionEvent[]>()
  const lines = (await read(EVENTS_FILE))?.split('\n') ?? []
  let previous = 1
  for (const [i, line] of lines.entries()) {
    if (line === '' && i === lines.length - 1) continue
    const at = `${EVENTS_FILE} line ${i + 1}`
    let value: unknown
    try {
      value = JSON.parse(line)
    } catch (error) {
      problems.push(`${at}: ${messageOf(error)}`)
      continue
    }
    const step = isRecord(value) ? value.step : undefined
    const event = isRecord(value) ? value.event : undefined
    const ran = typeof step === 'number' ? head?.steps[step - 1] : undefined
    if (typeof step !== 'number' || !ran || ran.kind === 'resume' || step < previous) {
      problems.push(`${at}: "step" must name a prompt or enable step that ran, in order`)
      continue
    }
    if (!isRecord(event) || typeof event.type !== 'string' || !EVENT_TYPES.has(event.type) || Object.keys(value as object).length !== 2) {
      problems.push(`${at}: must be {"step", "event"} with a known event type`)
      continue
    }
    previous = step
    const list = events.get(step) ?? []
    list.push(event as unknown as SessionEvent)
    events.set(step, list)
  }
  const saved = new Map<number, Transcript>()
  for (const [i, step] of (head?.steps ?? []).entries()) if (step.kind === 'resume') saved.set(i + 1, await transcriptIn(resumeFile(i + 1)))
  if (head && (head.steps.at(-1)?.end ?? head.start) > transcript.messages.length) problems.push(`${TRANSCRIPT_FILE}: shorter than the last step's end`)
  if (!head || problems.length > 0) throw new RunFileError(dir, problems)

  const steps = head.steps.map((step, i): StepLog => {
    switch (step.kind) {
      case 'prompt':
        return { kind: step.kind, result: step.result, events: events.get(i + 1) ?? [], end: step.end }
      case 'enable':
        return { kind: step.kind, events: events.get(i + 1) ?? [], end: step.end }
      case 'resume':
        return { kind: step.kind, saved: saved.get(i + 1)!, end: step.end }
      default:
        return step satisfies never
    }
  })
  return { ...head, steps, transcript }
}

const EVENT_TYPES = new Set<string>(['text', 'tool_start', 'tool_end', 'record', 'turn_end'] satisfies SessionEvent['type'][])

/** run.json against the scenario it carries: each step the kind its scenario step is, ends that never shrink, and a run that stops only where it may. */
function parseRunFile(value: unknown, problems: string[]): RunFile | undefined {
  if (value === undefined) return undefined
  if (!isRecord(value) || value.format !== 'aigent-run/1') {
    problems.push(`${RUN_FILE}: format must be "aigent-run/1"`)
    return undefined
  }
  const fail = (problem: string): void => {
    problems.push(`${RUN_FILE}: ${problem}`)
  }
  const known = ['format', 'scenario', 'model', 'toolMode', 'start', 'steps', 'failure']
  for (const key of Object.keys(value)) if (!known.includes(key)) fail(`unknown field "${key}"`)
  let scenario: Scenario | undefined
  try {
    scenario = parseScenario(value.scenario)
  } catch (error) {
    if (!(error instanceof ScenarioError)) throw error
    for (const problem of error.problems) fail(`scenario: ${problem}`)
  }
  if (!isModelSpec(value.model)) fail('model is not a ModelSpec')
  if (value.toolMode !== 'native' && value.toolMode !== 'dispatch') fail('toolMode must be "native" or "dispatch"')
  if (!isCount(value.start)) fail('start must be a non-negative integer')
  if (!Array.isArray(value.steps)) fail('steps must be a list')
  if (!scenario || !isCount(value.start) || !Array.isArray(value.steps)) return undefined

  const steps: readonly unknown[] = value.steps
  if (steps.length > scenario.steps.length) fail(`${steps.length} steps ran but the scenario has ${scenario.steps.length}`)
  let end = value.start
  for (const [i, step] of steps.entries()) {
    const kind = scenario.steps[i]?.kind
    if (!isRecord(step) || step.kind !== kind) {
      fail(`steps[${i}] must be a ${kind ?? 'missing'} step, as the scenario's step ${i + 1} is`)
      continue
    }
    const fields = kind === 'prompt' ? ['kind', 'result', 'end'] : ['kind', 'end']
    if (Object.keys(step).some((k) => !fields.includes(k))) fail(`steps[${i}] fields must be ${fields.join(', ')}`)
    if (!isCount(step.end) || step.end < end) fail(`steps[${i}].end must be an integer no smaller than the one before`)
    else end = step.end
    if (kind !== 'prompt') continue
    if (!isRunResult(step.result)) fail(`steps[${i}].result is not a RunResult`)
    else if (i < steps.length - 1 && (step.result.stop === 'error' || step.result.stop === 'aborted')) fail(`steps[${i}] ended ${step.result.stop}, so no step may follow it`)
  }
  const { failure } = value
  const failed = isRecord(failure) && failure.step === steps.length + 1 && failure.step <= scenario.steps.length && typeof failure.message === 'string' && Object.keys(failure).length === 2
  if (failure !== undefined && !failed) fail('failure must be {"step", "message"} naming the step after the last that ran')
  return problems.length > 0 ? undefined : { ...(value as unknown as RunFile), scenario }
}

function isModelSpec(value: unknown): value is ModelSpec {
  if (!isRecord(value) || typeof value.id !== 'string') return false
  const optional = (key: string, type: 'boolean' | 'number'): boolean => value[key] === undefined || typeof value[key] === type
  switch (value.kind) {
    case 'builtin':
      return typeof value.provider === 'string'
    case 'openai-compatible':
      return typeof value.baseUrl === 'string' && typeof value.apiKeyEnv === 'string' && optional('reasoning', 'boolean') && optional('contextWindow', 'number') && optional('maxTokens', 'number')
    default:
      return false
  }
}

function isRunResult(value: unknown): value is RunResult {
  if (!isRecord(value) || !isCount(value.turns)) return false
  switch (value.stop) {
    case 'done':
    case 'max_turns':
      return typeof value.text === 'string'
    case 'aborted':
      return true
    case 'error':
      return typeof value.message === 'string'
    default:
      return false
  }
}

function isCount(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0
}

function isRecord(value: unknown): value is Readonly<Record<string, unknown>> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

async function exists(path: string): Promise<boolean> {
  try {
    await stat(path)
    return true
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false
    throw error
  }
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
