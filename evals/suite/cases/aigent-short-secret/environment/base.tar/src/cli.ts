#!/usr/bin/env node
// `aigent run` and `aigent check`. The whole shell: argv and the environment in, a result directory and one JSON
// report on stdout out. Progress and problems go to stderr.

import { stat } from 'node:fs/promises'
import { dirname } from 'node:path'
import { parseArgs } from 'node:util'
import { check, type Report } from './eval/checks.ts'
import { readRun, RunFileError, runScenario, writeRun, type StepLog } from './eval/run.ts'
import { readScenario, ScenarioError } from './eval/scenario.ts'
import { createSession, type ModelSpec, type ToolMode } from './index.ts'

const USAGE = `usage:
  aigent run <scenario.json> --out <dir> --model <id> [--tool-mode native|dispatch]
             [--base-url <url>] [--api-key-env <NAME>] [--prompt-timeout <seconds>]
  aigent check <dir>

run    runs the scenario on an OpenAI-compatible model, writes the result directory <dir>
       (which must not exist), then checks the files it wrote.
       defaults: --tool-mode native, --base-url https://ollama.com/v1, --api-key-env OLLAMA_API_KEY,
       --prompt-timeout 240
check  checks an existing result directory.

stdout: the report as JSON. exit: 0 complete and every invariant held, 1 an invariant failed,
2 bad usage or input and nothing ran, 3 the run stopped before its last step, 4 the runner failed.`

/**
 * 0  every step ran and every invariant held. Behaviors never change the code; they are rates, not gates.
 * 1  an invariant failed: an engine bug. Wins over 3.
 * 2  bad argv, scenario, result directory or environment, found before anything ran. Nothing written.
 * 3  the run stopped early: a prompt ended `error` or `aborted` (provider failure, timeout, Ctrl-C) or a step threw.
 *    The steps that ran were written and checked.
 * 4  the runner itself failed. Nothing written.
 */
type Exit = 0 | 1 | 2 | 3 | 4

type Command =
  | {
      readonly kind: 'run'
      readonly scenario: string
      readonly out: string
      readonly model: Extract<ModelSpec, { readonly kind: 'openai-compatible' }>
      readonly toolMode: ToolMode
      readonly promptTimeoutMs: number
    }
  | { readonly kind: 'check'; readonly dir: string }

/** The argv boundary. A string is the problem that makes it exit 2. */
function parseCommand(argv: readonly string[]): Command | string {
  let parsed
  try {
    parsed = parseArgs({
      args: [...argv],
      allowPositionals: true,
      strict: true,
      options: {
        out: { type: 'string' },
        model: { type: 'string' },
        'tool-mode': { type: 'string' },
        'base-url': { type: 'string' },
        'api-key-env': { type: 'string' },
        'prompt-timeout': { type: 'string' },
      },
    })
  } catch (error) {
    return messageOf(error)
  }
  const { values, positionals } = parsed
  const [command, path, ...extra] = positionals
  if (!path || extra.length > 0) return 'expected a command and one path'
  if (command === 'check') return Object.keys(values).length > 0 ? 'check takes no flags' : { kind: 'check', dir: path }
  if (command !== 'run') return `unknown command "${command}"`
  if (!values.out || !values.model) return 'run needs --out and --model'
  const toolMode = values['tool-mode'] ?? 'native'
  if (toolMode !== 'native' && toolMode !== 'dispatch') return '--tool-mode must be native or dispatch'
  const seconds = Number(values['prompt-timeout'] ?? '240')
  if (!(seconds > 0)) return '--prompt-timeout must be a positive number of seconds'
  const apiKeyEnv = values['api-key-env'] ?? 'OLLAMA_API_KEY'
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(apiKeyEnv)) return '--api-key-env must name an environment variable'
  const model = { kind: 'openai-compatible', baseUrl: values['base-url'] ?? 'https://ollama.com/v1', id: values.model, apiKeyEnv } as const
  return { kind: 'run', scenario: path, out: values.out, model, toolMode, promptTimeoutMs: seconds * 1000 }
}

async function main(argv: readonly string[]): Promise<Exit> {
  const command = parseCommand(argv)
  if (typeof command === 'string') return refuse(`${command}\n\n${USAGE}`)
  if (command.kind === 'check') {
    const run = await readRun(command.dir).catch(refusal(RunFileError))
    return typeof run === 'number' ? run : print(check(run))
  }

  if (await exists(command.out)) return refuse(`${command.out} already exists`)
  const scenario = await readScenario(command.scenario).catch(refusal(ScenarioError))
  if (typeof scenario === 'number') return scenario
  const controller = new AbortController()
  process.once('SIGINT', () => controller.abort())
  const log = await runScenario(scenario, {
    root: dirname(command.scenario),
    open: createSession,
    model: command.model,
    toolMode: command.toolMode,
    promptTimeoutMs: command.promptTimeoutMs,
    signal: controller.signal,
    onStep: (step, ran) => process.stderr.write(`aigent: step ${step}/${scenario.steps.length} ${progress(ran)}\n`),
  }).catch(refusal(ScenarioError))
  if (typeof log === 'number') return log
  await writeRun(command.out, log)
  // The verdict comes from the files, so every run proves they are enough to grade it.
  return print(check(await readRun(command.out)))
}

function progress(step: StepLog): string {
  switch (step.kind) {
    case 'prompt':
      return `prompt: ${step.result.stop} after ${step.result.turns} turns`
    case 'enable':
    case 'resume':
      return step.kind
    default:
      return step satisfies never
  }
}

function print(report: Report): Exit {
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`)
  if (Object.values(report.invariants).some((verdict) => verdict.kind === 'fail')) return 1
  return report.complete ? 0 : 3
}

function refuse(problem: string): Exit {
  process.stderr.write(`aigent: ${problem}\n`)
  return 2
}

/** Turns a rejection of the boundary's own error class into exit 2, and lets anything else reach exit 4. */
function refusal(kind: new (...args: never[]) => Error): (error: unknown) => Exit {
  return (error) => {
    if (error instanceof kind) return refuse(error.message)
    throw error
  }
}

async function exists(path: string): Promise<boolean> {
  return stat(path).then(
    () => true,
    (error: NodeJS.ErrnoException) => {
      if (error.code === 'ENOENT') return false
      throw error
    },
  )
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

process.exitCode = await main(process.argv.slice(2)).catch((error: unknown) => {
  process.stderr.write(`aigent: ${error instanceof Error ? (error.stack ?? error.message) : String(error)}\n`)
  return 4
})
