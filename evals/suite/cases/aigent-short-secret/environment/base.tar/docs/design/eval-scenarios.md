# Eval scenarios and checks

## Problem

The live weather test was one hard-coded script with its own metrics and three asserts. This unit turns it into data. It adds a scenario file, a runner that executes it on a real or faux model, a result directory that a future multeval grader reads, and checks that judge a run from public types alone.

Five facts shaped the design. Probes on pi's faux provider measured the first three.

- Records written while a session is created never reach a listener. A fresh session's transcript holds 2 messages, the system prompt and the catalog record, before anyone can subscribe. Initial enables and resume-time enables show only in the transcript.
- A `core__call_tool` schema error emits no `tool_start` and no `tool_end`. It shows only as an `isError` tool result in the transcript, under the same call id the events use.
- `src/pi.ts` used to redact each `text` delta on its own. A faux reply that carried a secret streamed in 4 deltas, none of which held the whole secret, and the joined deltas did. The transcript and the `RunResult` stayed clean. The adapter now holds back the last `longest secret - 1` characters of an assistant message's text until more text arrives or the message ends, so a listener that joins deltas never sees a secret.
- multeval's exec grader is offline and reads files. Workdir collection caps a file at 64 KiB and an attempt at 1 MiB (`multeval/artifacts.py`). So the result directory is the whole input to grading, and grading must not need secret values.
- `test/boundary.test.ts` lets only `src/pi.ts` import pi and only `src/index.ts` import the adapter. So the runner takes a session opener instead of importing `createSession` or `startSession`.

## Usage

### A scenario file

`test/scenarios/weather.json` is the ported live test:

```json
{
  "format": "aigent-scenario/1",
  "plugins": ["plugins/weather"],
  "secrets": ["WEATHER_API_KEY"],
  "systemPrompt": "You are a helpful assistant. Enable a plugin when you need a capability you lack.",
  "maxTurns": 8,
  "steps": [
    {
      "kind": "prompt",
      "text": "I'm flying to Lisbon from Chicago tomorrow. What's the temperature there right now?",
      "expect": [
        { "check": "discover", "plugin": "weather" },
        { "check": "use", "tool": "weather__get_weather", "args": { "city": "lisbon" } },
        { "check": "dispatch-recover", "tool": "weather__get_weather" },
        {
          "check": "follow",
          "matches": "\\b17\\s*(°\\s*)?C\\b|\\b17\\s*degrees?\\s*C|celsius"
        }
      ]
    },
    { "kind": "resume" },
    {
      "kind": "prompt",
      "text": "And what about Porto?",
      "expect": [{ "check": "resume", "tool": "weather__get_weather", "args": { "city": "porto" } }]
    }
  ]
}
```

A step is a prompt, a host enable or a resume. A resume saves the transcript through a JSON round trip, closes the session and opens a new one from it. A resume's own `plugins` list replaces the plugin set. A prompt step lists the behaviors it is judged on. Invariants need no declaration, because they run on every run.

A behavior's id is `<check>@<step>` with 1-based steps, so `use@1` is the `use` expectation on the first step. One step takes at most one expectation per check, so ids stay unique. Patterns are regex sources, always matched case-insensitively. The `follow` pattern compiles to the exact source of the old live test's `CELSIUS`. Giving Celsius follows "Report temperatures in Celsius" even when the answer adds a Fahrenheit conversion, so the scenario does not reject Fahrenheit. `args` maps an argument name to a pattern its value must match, as a string or, for any other value, as JSON.

Plugin paths are directories relative to the scenario file, and each must stay inside the scenario's directory, because a multeval case carries only that directory. The runner loads each with `loadPlugins` and concatenates the sets. `secrets` names env vars that must be set. The session redacts each value and the runner scrubs it. `parseScenario` reports every problem at its JSON path in one pass, unknown fields included, so a misspelled `expect` cannot silently drop a step's behaviors.

The nine check kinds are the behavior names: `discover`, `restraint`, `use`, `dispatch-recover`, `follow`, `skill`, `denial`, `host-enable` and `resume`. Cost is always reported and never declared.

### The CLI

```
aigent run <scenario.json> --out <dir> --model <id> [--tool-mode native|dispatch]
           [--base-url <url>] [--api-key-env <NAME>] [--prompt-timeout <seconds>]
aigent check <dir>
```

The defaults are `--tool-mode native`, `--base-url https://ollama.com/v1`, `--api-key-env OLLAMA_API_KEY` and `--prompt-timeout 240`. `--model` names a model on an OpenAI-compatible endpoint, which is what multeval will run. The scenario is the case and the flags are the subject, so model and tool mode never go in a scenario file.

`run` refuses an existing `<dir>` before it reads the scenario. It runs every step, writes `<dir>` atomically, reads it back and checks the files it read. `check` checks an existing directory. Both print one JSON `Report` on stdout and send progress to stderr. Ctrl-C aborts the running prompt, and the steps that ran are still written.

| Exit | Meaning |
|---|---|
| 0 | Every step ran and every invariant held. Behaviors never change the exit code. |
| 1 | An invariant failed. That is an engine bug, so it wins over 3. |
| 2 | Bad argv, scenario, result directory or environment, found before anything ran. Nothing is written. |
| 3 | The run stopped before its last step, because a prompt ended `error` or `aborted` or a step threw. The steps that ran are written and checked. |
| 4 | The runner itself failed. Nothing is written. |

`package.json` has `"bin": { "aigent": "src/cli.ts" }` and the script `"aigent": "node --env-file-if-exists=.env src/cli.ts"`. A person runs `WEATHER_API_KEY=x npm run aigent -- run test/scenarios/weather.json --out runs/w1 --model gpt-oss:120b`.

### The result directory

```
<dir>/
  run.json          {"format":"aigent-run/1","scenario":{...},"model":{...},"toolMode":"native","start":2,
                     "steps":[{"kind":"prompt","result":{"stop":"done","text":"...","turns":3},"end":9},
                              {"kind":"resume","end":9},
                              {"kind":"prompt","result":{"stop":"done","text":"...","turns":2},"end":14}]}
  transcript.json   the final Transcript, {"format":"aigent-transcript/1","messages":[...]}
  events.jsonl      {"step":1,"event":<SessionEvent>} per line, in emission order. Only prompt and enable steps have lines.
  resume-2.json     the Transcript that step 2 saved and resumed from. One file per resume step, named by step number.
```

The numbers above are illustrative. `end` is the transcript length after a step, so step n's messages are `transcript.messages.slice(end of step n-1, end)`, and `start` comes before step 1. `steps[i]` is what happened at `scenario.steps[i]`. A run that stopped early has fewer steps than its scenario. When a step threw, `run.json` also has `"failure": {"step": n, "message": "..."}` for the step after the last one that ran.

Every string in every file has passed the scrub, keys included, so a raw secret value appears only as `[LEAKED:<NAME>]`. The runner joins adjacent text deltas into one text event before the scrub. `readRun` reads the directory back into exactly the run log `writeRun` wrote, and names every problem it finds instead of guessing.

### Call sites

`test/live.test.ts` runs every scenario file under `test/scenarios/`. Its body is now this:

```ts
const run = await runScenario(scenario, { root, open: createSession, model, toolMode, promptTimeoutMs: 240_000 })
const report = check(run)
t.diagnostic(JSON.stringify({ scenario: file, model, toolMode, stops, report }))
for (const [name, verdict] of Object.entries(report.invariants)) assert.equal(verdict.kind, 'pass', name)
```

A faux check test, from `test/checks.test.ts`, runs one scenario twice:

```ts
const right = check(await run(c.scenario, c.right, { mode: c.mode }))
const wrong = check(await run(c.scenario, script, { mode: c.mode }))
assert.equal(verdictOf(right, id)?.kind, 'pass', 'the right script passes')
assert.deepEqual(pick(verdict.evidence, because), because, 'it fails for the mistake the script makes')
```

The future multeval exec grader is not in this unit. The directory path below is a guess at where the adapter will put the run.

```ts
const request = JSON.parse(await readAll(process.stdin))
const report = check(await readRun(join(request.attempt_dir, 'artifacts', 'workdir', 'aigent-run')))
// scores: one bool per invariant and per behavior that did not skip, plus the cost numbers
```

## Shape

### Data first

Three types carry the design.

- `Scenario` is the input. Steps are a tagged union of `prompt`, `enable` and `resume`, and expectations sit on the prompt they judge. `parseScenario` is its one boundary. `readRun` uses it too, for the copy inside `run.json`.
- `RunLog` is what happened, in public types only. A step log holds outcomes alone (`result`, `events`, `saved`, `end`). What the step asked stays in `scenario.steps[i]`, so nothing is stored twice. A step's messages are a slice of the one final transcript, not a copy per step.
- `Report` is the judgment. `Verdict` is a sum type. `pass` and `fail` carry evidence, and `skip` carries a reason. `InvariantVerdict` excludes `skip` by type, so an invariant cannot quietly skip. A skip means the behavior had no chance to show, and rates leave it out instead of counting it as a failure.

### Modules

| Path | Owns |
|---|---|
| `src/eval/scenario.ts` | The scenario vocabulary and its boundary: `Scenario`, `ScenarioStep`, `Expectation`, `Pattern`, `ScenarioError`, `parseScenario`, `readScenario`, the parse rule of each check, and `referencedNames`. |
| `src/eval/run.ts` | Running and the result directory: `runScenario`, `RunLog`, `writeRun`, `readRun`, `RunFileError`. Also the leak mark, both its writer (the scrub) and its reader (`leaksIn`). |
| `src/eval/checks.ts` | Judging: `check`, the five invariants, the nine behaviors with their skip rules, and cost. The only transcript reader outside `src/pi.ts`. |
| `src/cli.ts` | Argv, environment and exit codes. Passes `createSession` to `runScenario`. |
| `test/fixtures/faux.ts` | `fauxModel`, one scripted faux model shared by every session it opens, so a script continues across a resume. `test/pi.test.ts` uses it too. |
| `test/scenarios/` | `weather.json`, plugin directories that re-export the fixtures in `test/fixtures/plugins.ts`, and a `clock` plugin for "added on resume". |

Imports run one way. `run.ts` imports `scenario.ts`, and `checks.ts` imports both. The only runtime import from `checks.ts` into `run.ts` is `leaksIn`, so the mark format has one owner. A check traces through `checks.ts` and the `RunLog` type. A CLI run traces through three files.

### Load-bearing decisions

1. **Scrub and mark instead of grading with secrets.** The runner knows every secret value, because it reads the scenario's `secrets` and the model's `apiKeyEnv` itself. Before it returns the log or hands a step to `onStep`, it replaces each raw value anywhere in the log with `[LEAKED:<NAME>]`, and `secret-free` fails on any mark. The files never hold a secret, even when the engine leaks one. A grader needs no key in its environment, and `multeval regrade` works without one.
2. **Behavior checks in the user's vocabulary.** `Expectation` is a union keyed by `check`. `scenario.ts` parses it through a table mapped over the check names, and `checks.ts` judges it through an exhaustive switch, so a check without either fails the build. Each behavior owns its precondition and so its skip rule. `discover` skips when the plugin was already enabled, `use` when the model never enabled the tool's plugin, `dispatch-recover` in native mode or without a rejected call, `skill` when the skill's plugin was never enabled, and `denial` without a matching denial. Any behavior skips on a step the run never reached. Preconditions on the script are parse errors. A `host-enable` expectation without an enable step of the tool's plugin since the previous prompt is a `ScenarioError`, and so is a `resume` expectation without a resume step.
3. **Invariants read the transcript and the events together.** Events miss creation records and schema errors. The transcript cannot tell a call that ran from one rejected before the gates without reading error wording. `check` parses both once. Each session's starting enabled set comes from the transcript before its first step, and order within a session comes from its events.
4. **The CLI grades its own files.** `aigent run` writes the directory, reads it back with `readRun` and checks what it read. Every run proves the files are enough to grade it, not only a test.
5. **Fail before paying.** `runScenario` loads every plugin set the scenario uses, and checks every referenced plugin, tool and skill name against the set in effect at its step, before the first session opens. An unset secret or a misspelled tool exits 2. Without the check, the run would spend model calls and come back full of failing behaviors.
6. **A step that throws is recorded.** A step can throw mid-run. A resume whose plugin set rejects the saved records is the common case. The log then records `failure`, the directory is still written, `complete` is false, and behaviors on the steps that never ran skip with the failure as their reason.
7. **Atomic output that refuses an existing directory.** `writeRun` writes a sibling temp directory and renames it into place. A crashed run leaves only a `<dir>.partial-*` sibling. A second run into the same directory exits 2 before any model call.
8. **Negative controls at the owning boundary.** A behavior's failing run is a real faux run with a wrong script. No model script can make a correct engine break an invariant, so an invariant's failing run is a recorded run with one fault, named for the engine bug it stands for, such as "a denial never reaches the record log". `secret-free` is the exception. The runner's scrub does its detection, so its fault goes in at the `Session` the runner reads, through a decorator that undoes redaction. Both case tables are typed by the check names with `satisfies`, so a check added without a passing and a failing case does not compile. Each failing case asserts the evidence that names its mistake, so it cannot fail by accident, and every behavior case asserts that no invariant broke, so a model mistake never shows up as an engine bug.
9. **The import rule is a test.** A `test/boundary.test.ts` case fails the build if a file under `src/eval/` imports `engine`, `pi` or `index`.

### Interface depth

The public functions are `runScenario`, `check`, `readScenario`, `parseScenario`, `writeRun` and `readRun`, plus `referencedNames` and `leaksIn`, which the other eval modules use. `check(run)` takes one argument. It hides transcript parsing, step slicing, session seeding, five invariants, nine behaviors with their skip rules, and cost. `runScenario` hides session lifecycles, the JSON round trip at resume, event capture and delta joining, the scrub, plugin loading, name validation and early stop. No caller sees a pi message shape. The CLI adds argv parsing and exit codes and no other logic.

The design leaves out multeval code, ATIF, aggregation across trials, writes during a run, and builtin-provider models in the CLI. Each is either a later unit or open below.

## Synthesis decision

The design came from an arena with two candidates and an independent cross-judge. Both the parent and the judge picked candidate 1 as the base, because its contract is right where candidate 2's is wrong. `check(run)` needs no secret values. Behaviors have a `skip` verdict, so rates exclude trials where the precondition never happened, and invariant verdicts cannot skip. The result directory is atomic, split into files under multeval's 64 KiB cap, and graded from the files by `aigent run`.

Four parts came from candidate 2.

- Compile-enforced failability. `test/checks.test.ts` types its tables by the check names with `satisfies`, so a check without its cases does not compile. All nine behaviors and all five invariants have real entries.
- `src/eval/scenario.ts` owns the scenario vocabulary and the parse rule of each check. That split removed candidate 1's runtime import from `run.ts` into `checks.ts`.
- An exhaustive step interpreter, ending in `default: step satisfies never`.
- A thrown step is recorded, not lost. Exit 3 covers every run that stopped early. Exit 4 is only for a failure of the runner itself.

Three parts of candidate 2 stayed out.

- An `Env { secrets }` argument to `check`. The grader would need the key, and `secret-free` would pass vacuously when the key was unset.
- Boolean behaviors without preconditions, which count a trial that had no chance as a failure.
- A `--provider` flag for pi's builtin providers. The runner cannot scrub a builtin key it never sees, so the CLI stays OpenAI-compatible only.

Three choices of candidate 1 stand as designed. `use` is strict, scenario `plugins` is a list of directories, and a pending record with no later user message passes `enable-text-once`.

Building it changed five things.

- The engine fix holds back text for the whole assistant message, not for one text block. pi emits nothing between two text blocks of one message, so a listener, and the runner's delta joining, would rejoin a secret split across blocks. pi ends every assistant message with `message_end`, whether it finished, errored or was aborted, so the flush there loses nothing. A cut never separates the two halves of a surrogate pair.
- `discover` and `skill` gained skip rules, for a plugin already enabled and a skill whose plugin was never enabled. Both had no chance to show in those runs.
- Behaviors dispatch through an exhaustive switch instead of a table and a cast, so the compiler proves each judge gets its own expectation type.
- `leaksIn` reads any name inside the mark, so a model key under a lower-case env var name cannot slip past `secret-free`.
- A behavior or an invariant with more than one way to fail has a case for each way. `denial` has three, and `resume-keeps-plugins` and `enable-text-once` have two each.

## Tradeoffs accepted

- We accept a second reader of pi's message shapes, `entriesOf` in `checks.ts`, in exchange for checks that never import pi. Every check test feeds it transcripts from real pi through the faux provider, so a shape change fails `npm test`.
- We accept a `use` check stricter than the old `toolCallCorrect`. It wants the call in the turn right after the enable, as the behavior is defined. A dispatch run that recovers from a schema error scores `use` fail and `dispatch-recover` pass, where the old metric said true.
- We accept invariant negative controls built from recorded runs plus a named fault, because a model script cannot make a correct engine break an invariant.
- We accept a copy of each resume's saved transcript in `resume-<n>.json`. It is the only independent witness that resume kept the record prefix.
- We accept that an engine dropping a plugin on resume shows at the run-log level only as the `resume` behavior failing. `resume-keeps-plugins` sees lost records, rewritten records and re-enables, not engine state.
- We accept losing delta boundaries in `events.jsonl` in exchange for a scrub that sees whole strings.
- We accept that a declared secret must be set in the environment, because a fixture plugin reads the same variable. In exchange, no secret value appears in a scenario or a result file.
- We accept writing nothing until a run ends, so `events.jsonl` cannot be tailed live, in exchange for all-or-nothing result directories.
- We accept that `readRun` checks only each event's type tag and trusts the rest as `writeRun` wrote it. `check` parses the transcript itself and throws on a message it cannot read.

## Alternatives considered

- **Scenario as a TypeScript module with its own `grade(run)`.** It is the most flexible shape, and the shallowest. Every scenario reimplements its predicates, and two scenarios can measure `discover` differently, so rates stop being comparable. Neither the Python adapter nor a pre-run name check can read it.
- **A predicate algebra with behavior names as free labels**, such as `{ "label": "discover", "enables": "weather" }`. Its vocabulary is smaller. But preconditions and skip rules differ per behavior, so the algebra needs operators for "after the enable", "after a rejected call" and "after a denial". That complexity moves into every scenario file.
- **Grading with secret values, or with their hashes in `run.json`.** Values tie the offline grader to its environment and rule out regrading without the key. Hashes need a sliding-window scan over every string, and they give a brute-force target to anyone who holds the directory. Scrub-and-mark makes the check a substring search over files that hold no secret.
- **Events only, no transcript reads.** It is simpler. But events miss creation-time records and dispatch schema errors. `enabled-before-call` would lose its seed, and `dispatch-recover` could not exist.
- **One `run.json` with everything in it.** One file is easier to parse. But the adapter wants `transcript.json` by name for ATIF, and multeval's 64 KiB per-file cap arrives sooner.

## Verification

- `test/run.test.ts` shows that a bad scenario reports every problem at its place, and that a run refuses unset secrets and unknown names before any model call. It shows that a thrown step ends the run and is recorded, and that a reply streamed in many deltas is one text event. It shows that a result directory reads back as exactly the run that was written, and that `writeRun` refuses an existing directory and leaves nothing beside it.
- `test/checks.test.ts` runs a passing and a failing faux run for every behavior and every invariant, and checks each failure against its evidence. One more run shows behaviors that skip because they had no chance.
- `test/cli.test.ts` shows that `aigent check` prints the report `check` makes in memory, exits 0, 1 or 3 by what the run went through, and exits 2 on a directory with no run. It also shows that `aigent run` refuses an existing directory before it calls a model.
- `test/pi.test.ts` shows that a listener that joins text deltas never sees a secret and gets the whole text, and that an abort mid-reply still delivers every character the transcript kept.
- `test/boundary.test.ts` fails the build when a file under `src/eval/` imports the engine, the adapter or the host entry.
- `test/live.test.ts` runs every scenario file on gpt-oss:120b, glm-5.3 and kimi-k2.6 in both tool modes, asserts the invariants and reports behaviors and cost. It skips without `OLLAMA_API_KEY`.

## Open questions

- Will the multeval adapter read the result directory through workdir collection? A live transcript with reasoning text may pass 64 KiB. That is a guess, not a measurement. Should the adapter return the directory as evidence or copy it uncapped?
- How should a `skip` map to a multeval grade, which allows only bool, int and float scores? Should the adapter omit the metric, or emit opportunity and success counts per behavior?
- Is it acceptable that `aigent run` takes only OpenAI-compatible models for now? A builtin provider's key comes from pi's auth, which the runner cannot see, so the runner could not scrub it.
- Who sets declared secrets under multeval? The adapter would generate a canary per attempt for each name in `scenario.secrets`.
- Is a derived 1-based step number the right public id (`use@1`), given that inserting a step renumbers later ids? Inserting a step already changes the case, so derived ids won over hand-assigned ones.
