// The adapter offline, against pi's faux provider: what reaches the model, and in which request.

import assert from 'node:assert/strict'
import { test } from 'node:test'
import { collapseSystemMessages, fauxAssistantMessage, fauxToolCall, getCurrentTools, type Message, type TranscriptContext } from '@earendil-works/pi-ai'
import type { Plugin } from '../src/plugin.ts'
import type { ToolMode } from '../src/session.ts'
import { call, FAUX, fauxModel, reply, type Reply } from './fixtures/faux.ts'
import { makeWeather, units } from './fixtures/plugins.ts'

const declared = (context: TranscriptContext | undefined) => getCurrentTools(context?.messages ?? []).map((t) => t.name)
const lastToolResult = (context: TranscriptContext | undefined) =>
  context?.messages.findLast((m): m is Extract<Message, { role: 'toolResult' }> => m.role === 'toolResult')?.content.map((c) => (c.type === 'text' ? c.text : '')).join('')

/** Each request extends the previous one, as a provider without mid-conversation system messages renders it. */
function prefixOnlyGrows(requests: readonly TranscriptContext[]): boolean {
  const rendered = requests.map((r) => collapseSystemMessages(r).messages.map((m) => JSON.stringify(m)))
  return rendered.every((messages, i) => i === 0 || rendered[i - 1]!.every((m, j) => messages[j] === m))
}

for (const mode of ['native', 'dispatch'] as const satisfies readonly ToolMode[]) {
  test(`the enabled tool and its text reach the model before the request that uses them, in ${mode} mode`, async () => {
    const weather = makeWeather()
    const useWeather = mode === 'native' ? call('weather__get_weather', { city: 'Lisbon' }) : call('core__call_tool', { tool: 'weather__get_weather', args: { city: 'Lisbon' } })
    const model = fauxModel([call('core__enable_plugin', { name: 'weather' }), useWeather, reply('It is 17C in Lisbon.')])
    const { requests } = model
    const session = await model.open({ model: FAUX, systemPrompt: 'You are a test agent.', plugins: [units, weather.plugin], toolMode: mode })

    const result = await session.prompt('Weather in Lisbon?')

    assert.deepEqual(result, { stop: 'done', text: 'It is 17C in Lisbon.', turns: 3 })
    assert.equal(weather.calls.getWeather, 1)
    assert.ok(!declared(requests[0]).includes('weather__get_weather'), 'not declared before the enable')
    assert.match(lastToolResult(requests[1]) ?? '', /Report temperatures in Celsius/)
    if (mode === 'native') assert.ok(declared(requests[1]).includes('weather__get_weather'), 'declared on the request that uses it')
    else {
      assert.deepEqual(declared(requests[1]), declared(requests[0]), 'declarations never change in dispatch mode')
      assert.match(lastToolResult(requests[1]) ?? '', /weather__get_weather: Current weather for a city\.\n {2}Parameters: \{"type":"object"/)
    }
    assert.equal(prefixOnlyGrows(requests), mode === 'dispatch')
  })
}

test('a transcript survives JSON and resumes the enabled set without rerunning onEnable or holding a secret', async () => {
  const key = 'sk-station-0123456789'
  const first = makeWeather()
  const base = { model: FAUX, secrets: { STATION_KEY: key } } as const
  const model = fauxModel([call('core__enable_plugin', { name: 'weather' }), call('weather__get_weather', { city: 'Porto' }), reply('16C.')])
  const original = await model.open({ ...base, plugins: [units, first.plugin], systemPrompt: 'You are a test agent.', maxTurns: 1 })
  assert.equal((await original.prompt('Weather in Lisbon?')).stop, 'max_turns')
  const saved = JSON.parse(JSON.stringify(original.transcript()))

  const second = makeWeather({ echo: key })
  const resumed = await model.open({ ...base, plugins: [units, second.plugin], transcript: saved })
  const result = await resumed.prompt('And in Porto?')
  const after = JSON.stringify(resumed.transcript())
  const firstAfterResume = model.requests[1]

  assert.equal(saved.format, 'aigent-transcript/1')
  assert.equal(result.stop, 'done')
  assert.equal(second.calls.onEnable, 0)
  assert.equal(second.calls.getWeather, 1)
  assert.ok(declared(firstAfterResume).includes('weather__get_weather'))
  assert.match(String(firstAfterResume?.messages[0]?.content), /^You are a test agent\./)
  assert.deepEqual(
    firstAfterResume?.messages.filter((m) => m.role === 'user').map((m) => m.content),
    ['Weather in Lisbon?', 'And in Porto?'],
    'records and enable text never become messages of their own',
  )
  assert.ok(!after.includes(key) && after.includes('[REDACTED:STATION_KEY]'))
})

test('a host enable saved in an idle transcript reaches the first user message after resume', async () => {
  const base = { model: FAUX, toolMode: 'dispatch' } as const
  const model = fauxModel([reply('ok')])
  const original = await model.open({ ...base, plugins: [units, makeWeather().plugin], systemPrompt: 'You are a test agent.' })
  await original.enable('weather')
  const saved = JSON.parse(JSON.stringify(original.transcript()))

  const second = makeWeather()
  const resumed = await model.open({ ...base, plugins: [units, second.plugin], transcript: saved })
  await resumed.prompt('Weather in Lisbon?')

  const users = model.requests[0]?.messages.filter((m) => m.role === 'user').map((m) => String(m.content))
  assert.equal(users?.length, 1)
  assert.match(users?.[0] ?? '', /^Weather in Lisbon\?\n\n[\s\S]*Weather data refreshes every 10 minutes\.[\s\S]*weather__get_weather: Current weather for a city\.\n {2}Parameters: /)
  assert.equal(second.calls.onEnable, 0)
})

test('streamed deltas never rejoin a split secret or split a character, and the text arrives whole', async () => {
  // Longer than the faux provider's largest chunk (20 characters), so every run splits it across deltas.
  const key = 'sk-station-0123456789abcdef'
  // The last cut falls 26 characters before the end, between the two halves of an emoji.
  const rain = `${'🌧'.repeat(20)}!`
  const session = await fauxModel([reply(`The station key is ${key}, keep it safe. ${rain}`)]).open({ model: FAUX, systemPrompt: 'Test.', plugins: [], secrets: { STATION_KEY: key } })
  const deltas: string[] = []
  session.subscribe((e) => {
    if (e.type === 'text') deltas.push(e.delta)
  })

  await session.prompt('Hi')

  assert.equal(deltas.join(''), `The station key is [REDACTED:STATION_KEY], keep it safe. ${rain}`)
  assert.deepEqual(deltas.filter((d) => /^[\uDC00-\uDFFF]|[\uD800-\uDBFF]$/.test(d)), [], 'no delta ends or starts inside a surrogate pair')
})

test('an abort mid-reply still delivers every character the transcript kept', async () => {
  const key = 'sk-station-0123456789abcdef'
  const text = `The station key is ${key}, keep it safe.`
  const controller = new AbortController()
  // Paced by timers, so the abort lands before the provider streams the rest of the reply.
  const session = await fauxModel([reply(text)], { tokensPerSecond: 1_000_000 }).open({ model: FAUX, systemPrompt: 'Test.', plugins: [], secrets: { STATION_KEY: key } })
  const deltas: string[] = []
  session.subscribe((e) => {
    if (e.type !== 'text') return
    deltas.push(e.delta)
    controller.abort()
  })

  assert.equal((await session.prompt('Hi', { signal: controller.signal })).stop, 'aborted')

  const kept = session.transcript().messages.flatMap((m) => {
    const message = m as { role?: string; content?: { type: string; text?: string }[] }
    return message.role === 'assistant' ? (message.content ?? []).flatMap((c) => (c.type === 'text' ? [c.text ?? ''] : [])) : []
  })
  assert.ok(kept.join('').length < text.length, 'the abort cut the reply short')
  assert.equal(deltas.join(''), kept.join(''), 'the held-back tail reached listeners')
})

test('a provider error ends the run with a redacted error result', async () => {
  const key = 'sk-provider-0123456789'
  const session = await fauxModel([() => fauxAssistantMessage('', { stopReason: 'error', errorMessage: `key ${key} was rejected` })]).open({
    model: FAUX,
    systemPrompt: 'Test.',
    plugins: [],
    secrets: { PROVIDER_KEY: key },
  })

  const result = await session.prompt('Hello?')

  assert.deepEqual(result, { stop: 'error', message: 'key [REDACTED:PROVIDER_KEY] was rejected', turns: 1 })
  assert.ok(!JSON.stringify(session.transcript()).includes(key))
})

test('the host signal cuts the model off, and max turns stops a model that keeps calling tools', async () => {
  const controller = new AbortController()
  const weather = makeWeather()
  const abortThenCall: Reply = () => {
    controller.abort()
    return fauxAssistantMessage(fauxToolCall('weather__get_weather', { city: 'Lisbon' }), { stopReason: 'toolUse' })
  }
  const aborting = await fauxModel([abortThenCall, reply('late')]).open({ model: FAUX, systemPrompt: 'Test.', plugins: [units, weather.plugin], enabled: ['weather'] })
  assert.equal((await aborting.prompt('Hello?', { signal: controller.signal })).stop, 'aborted')
  assert.equal(weather.calls.getWeather, 0, 'the aborted response never ran its tool call')

  const convert = call('units__c_to_f', { celsius: '17' })
  const looping = fauxModel([convert, convert, convert])
  const session = await looping.open({ model: FAUX, systemPrompt: 'Test.', plugins: [units], enabled: ['units'], maxTurns: 2 })
  assert.equal((await session.prompt('Convert forever.')).stop, 'max_turns')
  assert.equal(looping.pending(), 1, 'the third reply was never requested')
})

test('a second prompt while one runs rejects', async () => {
  let release = () => {}
  const held = new Promise<void>((resolve) => (release = resolve))
  const session = await fauxModel([
    async () => {
      await held
      return fauxAssistantMessage('done')
    },
  ]).open({ model: FAUX, systemPrompt: 'Test.', plugins: [] as Plugin[] })

  const first = session.prompt('One.')
  await assert.rejects(session.prompt('Two.'), /already running/)
  release()
  assert.equal((await first).stop, 'done')
})
