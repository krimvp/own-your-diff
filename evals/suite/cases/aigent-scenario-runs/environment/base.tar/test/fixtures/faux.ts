// One scripted faux model for any number of sessions, so a scenario's resume continues the same script. With
// pi.test.ts, the only test code that imports pi, and the only code but the host entry that opens the adapter.

import { fauxAssistantMessage, fauxProvider, fauxToolCall, type AssistantMessage, type RegisterFauxProviderOptions, type TranscriptContext } from '@earendil-works/pi-ai'
import { createModels } from '@earendil-works/pi-ai/models'
import { startSession } from '../../src/pi.ts'
import type { JsonObject } from '../../src/plugin.ts'
import type { ModelSpec, Session, SessionOptions } from '../../src/session.ts'

/** One model response. Gets the context the model received and the request's signal. */
export type Reply = (context: TranscriptContext, signal: AbortSignal | undefined) => AssistantMessage | Promise<AssistantMessage>

/** The spec sessions on a faux model carry. Nothing resolves it: `open` hands the adapter the faux model itself. */
export const FAUX: ModelSpec = { kind: 'builtin', provider: 'faux', id: 'faux-1' }

export const call = (name: string, args: JsonObject): Reply => () => fauxAssistantMessage(fauxToolCall(name, args), { stopReason: 'toolUse' })
export const reply = (text: string): Reply => () => fauxAssistantMessage(text)

export interface FauxModel {
  /** Opens a session on this model. Every session it opens takes its replies from the one script. */
  open(options: SessionOptions): Promise<Session>
  /** A copy of every context the model received, across sessions, in order. */
  readonly requests: readonly TranscriptContext[]
  /** Replies the script still holds. A run that leaves some unused did not go the way its script assumed. */
  pending(): number
}

export function fauxModel(script: readonly Reply[], provider: RegisterFauxProviderOptions = {}): FauxModel {
  const faux = fauxProvider(provider)
  const models = createModels()
  models.setProvider(faux.provider)
  const requests: TranscriptContext[] = []
  faux.setResponses(
    script.map((next) => (context, options) => {
      requests.push(structuredClone(context))
      return next(context, options?.signal)
    }),
  )
  return {
    open: (options) => startSession(options, { model: faux.getModel(), streamFn: (m, c, o) => models.streamSimple(m, c, o), secrets: {} }),
    requests,
    pending: () => faux.getPendingResponseCount(),
  }
}
