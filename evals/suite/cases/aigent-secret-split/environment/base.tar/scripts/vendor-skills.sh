#!/usr/bin/env bash
# Re-vendor third-party agent skills into .agents/skills/ at pinned refs.
# Usage: scripts/vendor-skills.sh [--update]   (--update moves pins to each upstream's HEAD)
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SKILLS="$ROOT/.agents/skills"
LOCK="$ROOT/.agents/skills.lock"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

PSTACK_REPO=https://github.com/backnotprop/pstack.git
MATT_REPO=https://github.com/mattpocock/skills.git
OPENCLAW_REPO=https://github.com/openclaw/openclaw.git

# Matt Pocock skills we take. The rest overlap pstack (tdd, teach, prototype,
# diagnosing-bugs, code-review) or need tracker setup we have not chosen yet.
MATT_SKILLS=(
  engineering/codebase-design
  engineering/domain-modeling
  engineering/grill-with-docs
  productivity/grilling
  productivity/handoff
  productivity/writing-for-agents
)

pin() { [[ -f "$LOCK" ]] && awk -v k="$1" '$1==k {print $2}' "$LOCK" || true; }

fetch() { # name repo [sparse paths...]
  local name=$1 repo=$2; shift 2
  local ref; ref=$([[ "${UPDATE:-0}" == 1 ]] && echo "" || pin "$name")
  git clone -q --filter=blob:none --no-checkout "$repo" "$WORK/$name"
  if (($#)); then git -C "$WORK/$name" sparse-checkout set --no-cone "$@"; fi
  git -C "$WORK/$name" checkout -q "${ref:-HEAD}"
  git -C "$WORK/$name" rev-parse HEAD
}

UPDATE=0; [[ "${1:-}" == --update ]] && UPDATE=1

PSTACK_SHA=$(fetch pstack "$PSTACK_REPO")
MATT_SHA=$(fetch mattpocock "$MATT_REPO" "${MATT_SKILLS[@]/#/skills/}" LICENSE)
OPENCLAW_SHA=$(fetch openclaw "$OPENCLAW_REPO" .agents/skills/test-audit LICENSE)

mkdir -p "$SKILLS"

for dir in "$WORK"/pstack/skills/*/; do
  name=$(basename "$dir")
  rsync -a --delete "$dir" "$SKILLS/$name/"
done
mkdir -p "$ROOT/third_party/pstack"
cp "$WORK/pstack/LICENSE" "$ROOT/third_party/pstack/LICENSE"
cp "$WORK/pstack/agents/"*.md "$ROOT/third_party/pstack/"

for path in "${MATT_SKILLS[@]}"; do
  rsync -a --delete "$WORK/mattpocock/skills/$path/" "$SKILLS/$(basename "$path")/"
done
mkdir -p "$ROOT/third_party/mattpocock-skills"
cp "$WORK/mattpocock/LICENSE" "$ROOT/third_party/mattpocock-skills/LICENSE"

# test-audit is an adapted port (openclaw-specific links and commands removed),
# so it is never overwritten. Show what upstream changed since our pin instead.
mkdir -p "$ROOT/third_party/openclaw"
cp "$WORK/openclaw/LICENSE" "$ROOT/third_party/openclaw/LICENSE"
OLD_OPENCLAW=$(pin openclaw)
if [[ -n "$OLD_OPENCLAW" && "$OLD_OPENCLAW" != "$OPENCLAW_SHA" ]]; then
  git -C "$WORK/openclaw" fetch -q --filter=blob:none origin "$OLD_OPENCLAW" || true
  echo "== upstream test-audit changes since $OLD_OPENCLAW (port by hand into .agents/skills/test-audit):"
  git -C "$WORK/openclaw" diff --stat "$OLD_OPENCLAW" HEAD -- .agents/skills/test-audit || true
fi

cat >"$LOCK" <<EOF
# name sha source
pstack $PSTACK_SHA $PSTACK_REPO
mattpocock $MATT_SHA $MATT_REPO
openclaw $OPENCLAW_SHA $OPENCLAW_REPO
EOF

echo "vendored: pstack@${PSTACK_SHA:0:7} mattpocock@${MATT_SHA:0:7} openclaw@${OPENCLAW_SHA:0:7}"
