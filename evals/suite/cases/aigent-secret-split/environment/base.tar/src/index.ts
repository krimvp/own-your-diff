// Host entry, published as `aigent`. The only module that imports the adapter.

export { CatalogError, loadPlugins } from './catalog.ts'
export { createSession } from './pi.ts'
export type {
  Content,
  Denial,
  EnableCause,
  EnableSnapshot,
  GateVerdict,
  Hooks,
  JsonObject,
  JsonSchema,
  JsonValue,
  Plugin,
  PromptSnapshot,
  SessionEndSnapshot,
  Skill,
  Tool,
  ToolCallSnapshot,
  ToolOutcome,
  ToolResult,
  ToolResultSnapshot,
  TurnSnapshot,
} from './plugin.ts'
export type { EngineRecord, ModelSpec, RunResult, Session, SessionEvent, SessionOptions, ToolMode, Transcript } from './session.ts'
