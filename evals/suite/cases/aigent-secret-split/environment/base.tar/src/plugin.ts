// Plugin-author vocabulary, published as `aigent/plugin`. Types only, so a plugin depends on nothing at runtime.

export type JsonValue = null | boolean | number | string | readonly JsonValue[] | JsonObject
export type JsonObject = { readonly [key: string]: JsonValue }

/** Plain JSON Schema with an object root. Hand-written, TypeBox or zod output all fit. */
export type JsonSchema = { readonly type: 'object' } & JsonObject

export type MaybePromise<T> = T | Promise<T>

export type Content =
  | { readonly type: 'text'; readonly text: string }
  | { readonly type: 'image'; readonly data: string; readonly mimeType: string }

export interface ToolResult {
  readonly content: readonly Content[]
  readonly isError?: boolean
}

export interface Tool {
  /** `[A-Za-z0-9_-]+`. The model sees `<plugin>__<name>`. */
  readonly name: string
  readonly description: string
  readonly parameters: JsonSchema
  /** `args` passed validation against `parameters` and every gate saw the same frozen object. A throw becomes an error result. */
  execute(args: JsonObject, signal: AbortSignal): Promise<ToolResult>
}

export interface Skill {
  /** `[a-z0-9_-]+`. The model loads it as `<plugin>__<name>`. */
  readonly name: string
  /** Visible once the plugin is enabled. */
  readonly description: string
  /** Read only when the model asks for it. */
  load(): MaybePromise<string>
}

export type GateVerdict = 'allow' | { readonly deny: string }

export type EnableCause = 'initial' | 'host' | 'model' | { readonly dependencyOf: string }

export interface EnableSnapshot {
  readonly plugin: string
  readonly cause: EnableCause
  /** Every enabled plugin, this one included, in enable order. */
  readonly enabled: readonly string[]
}

export interface PromptSnapshot {
  readonly text: string
  readonly enabled: readonly string[]
}

export interface ToolCallSnapshot {
  readonly id: string
  /** The resolved `<plugin>__<tool>` name, never `core__call_tool`. */
  readonly name: string
  readonly plugin: string
  readonly tool: string
  readonly args: JsonObject
}

export interface Denial {
  readonly plugin: string
  readonly reason: string
}

export type ToolOutcome =
  | { readonly kind: 'ran'; readonly result: ToolResult }
  | { readonly kind: 'denied'; readonly denials: readonly Denial[] }

export interface ToolResultSnapshot {
  readonly call: ToolCallSnapshot
  readonly outcome: ToolOutcome
}

export interface TurnSnapshot {
  /** 1-based within the current prompt. */
  readonly turn: number
  readonly text: string
  readonly calls: readonly ToolResultSnapshot[]
}

export interface SessionEndSnapshot {
  readonly turns: number
  readonly enabled: readonly string[]
}

/**
 * Hooks observe, add, or gate. The return types are the whole capability: an add hook can only return text to
 * append, a gate can only allow or deny, an observer has nothing to return. Each hook gets a deep-frozen snapshot
 * and a signal that fires on timeout or session close.
 */
export interface Hooks {
  /** Add. Fires once, when this plugin is enabled. */
  onEnable?(event: EnableSnapshot, signal: AbortSignal): MaybePromise<string | undefined>
  /** Add. Text is appended to the user message, after the prompt, in plugin enable order. */
  onUserPrompt?(event: PromptSnapshot, signal: AbortSignal): MaybePromise<string | undefined>
  /** Gate. Runs before every tool call of every plugin, core included. Any deny wins. A throw or timeout denies. */
  beforeToolCall?(call: ToolCallSnapshot, signal: AbortSignal): MaybePromise<GateVerdict>
  onToolResult?(event: ToolResultSnapshot, signal: AbortSignal): MaybePromise<void>
  onTurnEnd?(event: TurnSnapshot, signal: AbortSignal): MaybePromise<void>
  onSessionEnd?(event: SessionEndSnapshot, signal: AbortSignal): MaybePromise<void>
}

export interface Plugin {
  /** `[a-z0-9-]+`, unique. `core` is reserved. */
  readonly name: string
  /** One line, shown in the catalog. */
  readonly description: string
  /** Enabled first, in this order. Names only. */
  readonly dependsOn?: readonly string[]
  /** Shown to the model once, when the plugin is enabled. */
  readonly instructions?: string
  readonly tools?: readonly Tool[]
  readonly skills?: readonly Skill[]
  readonly hooks?: Hooks
}
