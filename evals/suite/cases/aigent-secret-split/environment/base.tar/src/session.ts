// Host vocabulary. Types only. No loop-library type crosses this surface; `createSession` lives in the adapter.

import type { PluginName, ToolName } from './catalog.ts'
import type { JsonValue, Plugin, ToolCallSnapshot, ToolResultSnapshot, TurnSnapshot } from './plugin.ts'

/** The engine's only state. Entries ride in the transcript, so a resumed session rebuilds the same engine. */
export type EngineRecord =
  | {
      readonly kind: 'enabled'
      readonly plugin: PluginName
      readonly cause: 'initial' | 'host' | 'model' | { readonly dependencyOf: PluginName }
    }
  | { readonly kind: 'denied'; readonly callId: string; readonly tool: ToolName; readonly plugin: PluginName; readonly reason: string }
  /** What the model was last told about the plugin set. Drives catalog drift detection on resume. */
  | { readonly kind: 'catalog'; readonly fingerprint: string }
  /** Redacted enable text waiting for the next user message. */
  | { readonly kind: 'pending'; readonly text: string }
  /** The next user message carried every `pending` text before it. */
  | { readonly kind: 'delivered' }

export type ModelSpec =
  /** A model from pi's built-in catalog, authenticated the way that provider usually is. */
  | { readonly kind: 'builtin'; readonly provider: string; readonly id: string }
  /** Any OpenAI-compatible chat-completions endpoint, such as Ollama Cloud at https://ollama.com/v1. */
  | {
      readonly kind: 'openai-compatible'
      readonly baseUrl: string
      readonly id: string
      /** Env var holding the API key. Its value is redacted everywhere. */
      readonly apiKeyEnv: string
      readonly reasoning?: boolean
      readonly contextWindow?: number
      readonly maxTokens?: number
    }

/**
 * `native` declares every enabled tool with its schema, so each enable changes the request's tool list.
 * `dispatch` keeps the declared list fixed and reaches later-enabled tools through `core__call_tool`.
 */
export type ToolMode = 'native' | 'dispatch'

/** JSON-serializable and redacted. Persist it and pass it back to resume. */
export interface Transcript {
  readonly format: 'aigent-transcript/1'
  readonly messages: readonly JsonValue[]
}

interface CommonOptions {
  readonly model: ModelSpec
  /** Every plugin the session may enable. */
  readonly plugins: readonly Plugin[]
  /** Enabled at start with their dependencies. On resume, names already enabled are skipped. */
  readonly enabled?: readonly string[]
  /** Default `native`. */
  readonly toolMode?: ToolMode
  /** NAME to value. Each value becomes `[REDACTED:NAME]`. The model API key is added automatically. */
  readonly secrets?: Readonly<Record<string, string>>
  /** Model turns per `prompt()`. Default 25. */
  readonly maxTurns?: number
  /** Per hook call. A gate past it denies; any other hook past it is ignored. Default 10000. */
  readonly hookTimeoutMs?: number
  /** Receives redacted lines. Default `console.error`. */
  readonly log?: (line: string) => void
}

/** pi ignores a system prompt when the transcript already starts with one, so a session takes one or the other. */
export type SessionOptions = CommonOptions &
  (
    | { readonly systemPrompt: string; readonly transcript?: never }
    | { readonly transcript: Transcript; readonly systemPrompt?: never }
  )

export type RunResult =
  | { readonly stop: 'done'; readonly text: string; readonly turns: number }
  | { readonly stop: 'max_turns'; readonly text: string; readonly turns: number }
  | { readonly stop: 'aborted'; readonly turns: number }
  | { readonly stop: 'error'; readonly message: string; readonly turns: number }

/** Everything a host can watch. Redacted. */
export type SessionEvent =
  | { readonly type: 'text'; readonly delta: string }
  | { readonly type: 'tool_start'; readonly call: ToolCallSnapshot }
  | { readonly type: 'tool_end'; readonly result: ToolResultSnapshot }
  | { readonly type: 'record'; readonly record: EngineRecord }
  | { readonly type: 'turn_end'; readonly turn: TurnSnapshot }

export interface Session {
  /** Runs until the model stops, a stop condition fires, or the run fails. Rejects while another prompt runs. */
  prompt(text: string, options?: { readonly signal?: AbortSignal }): Promise<RunResult>
  /** Enables a plugin and its dependencies, usable from the next model request. Rejects on an unknown name. */
  enable(name: string): Promise<void>
  subscribe(listener: (event: SessionEvent) => void): () => void
  /** Complete whenever no prompt is running. */
  transcript(): Transcript
  /** Aborts any run, fires `onSessionEnd` once, and rejects later prompts. */
  close(): Promise<void>
}
