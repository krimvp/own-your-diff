// The engine core: the record log and everything derived from it, the core plugin, enabling, the tool pipeline,
// gates, redaction, stop conditions and the run outcome. Knows nothing about pi; any loop drives it through Engine.

import { CORE, qualify, type Catalog, type PluginName, type ToolName } from './catalog.ts'
import type {
  Content,
  Hooks,
  JsonObject,
  JsonSchema,
  MaybePromise,
  Plugin,
  Tool,
  ToolCallSnapshot,
  ToolResult,
  ToolResultSnapshot,
} from './plugin.ts'
import type { EngineRecord, RunResult, SessionEvent, ToolMode } from './session.ts'

export interface ToolSpec {
  readonly name: ToolName
  readonly description: string
  readonly parameters: JsonSchema
}

/** A call as the loop hands it over. For a declared tool, `args` already passed validation. */
export interface ToolCall {
  readonly id: string
  readonly name: string
  readonly args: JsonObject
}

/** One completed model turn, as the loop saw it. */
export type Turn = { readonly kind: 'ok'; readonly text: string } | { readonly kind: 'error'; readonly message: string } | { readonly kind: 'aborted' }

/** Validates and coerces `args` against `schema`, as the loop does for declared tools. */
export type Validate = (schema: JsonSchema, args: JsonObject, tool: string) => { readonly ok: true; readonly args: JsonObject } | { readonly ok: false; readonly error: string }

export interface EngineOptions {
  readonly catalog: Catalog
  readonly toolMode: ToolMode
  /** Fresh sessions build a system prompt. Resumed ones replay the records a transcript carried, running no hooks. */
  readonly start: { readonly kind: 'fresh'; readonly systemPrompt: string } | { readonly kind: 'resume'; readonly records: readonly unknown[] }
  /** Enabled at creation. On resume, names already enabled are skipped and the rest are delivered like a host enable. */
  readonly enabled: readonly string[]
  readonly secrets: Readonly<Record<string, string>>
  readonly maxTurns: number
  readonly hookTimeoutMs: number
  readonly validate: Validate
  readonly emit: (event: SessionEvent) => void
  readonly log: (line: string) => void
}

/**
 * The port. Per prompt a loop calls: beginPrompt, then per model request tools() and, after the turn,
 * callTool* and endTurn, then takeRecords to append new records to its transcript; endRun once the run stops.
 * `enable` may be called at any time, including mid-run.
 */
export interface Engine {
  /** The leading system prompt of a fresh session. Undefined on resume, where the transcript already has one. */
  readonly systemPrompt: string | undefined
  /** Declarations for the next request, in stable order. */
  tools(): readonly ToolSpec[]
  /** Records appended since the last call. */
  takeRecords(): readonly EngineRecord[]
  /** Starts a run and returns the user message text: the prompt, then queued enable text, catalog drift and onUserPrompt text. */
  beginPrompt(text: string, signal: AbortSignal): Promise<string>
  /** Resolve, unwrap, gate, execute, redact, observe. Never rejects. */
  callTool(call: ToolCall, signal: AbortSignal): Promise<ToolResult>
  /** Runs onTurnEnd observers, then the stop conditions. */
  endTurn(turn: Turn): Promise<'continue' | 'stop'>
  endRun(): RunResult
  /** Host enable. Rejects on an unknown name. */
  enable(name: string): Promise<void>
  redact(text: string): string
  /** Fires onSessionEnd once and rejects later prompts. */
  close(): Promise<void>
}

type EnabledRecord = Extract<EngineRecord, { kind: 'enabled' }>
type StopReason = 'aborted' | 'max_turns'

interface Run {
  readonly signal: AbortSignal
  turns: number
  last: Turn | undefined
  stoppedBy: StopReason | undefined
  calls: ToolResultSnapshot[]
}

interface Entry {
  readonly name: ToolName
  readonly plugin: PluginName
  readonly tool: Tool
}

type Settled<T> = { readonly ok: true; readonly value: T } | { readonly ok: false; readonly reason: string }

const CALL_TOOL: ToolSpec = {
  name: qualify(CORE, 'call_tool'),
  description: 'Call a tool of a plugin enabled during this conversation. Its name and parameters are listed where it was enabled.',
  parameters: {
    type: 'object',
    properties: {
      tool: { type: 'string', description: 'Full tool name, <plugin>__<tool>' },
      args: { type: 'object', description: "Arguments matching the tool's parameters" },
    },
    required: ['tool'],
    additionalProperties: false,
  },
}

export async function createEngine(options: EngineOptions): Promise<Engine> {
  const { catalog, toolMode, validate, emit } = options
  const redact = makeRedactor(options.secrets)
  const log = (line: string) => options.log(redact(line))

  const records: EngineRecord[] = []
  const byKind = {
    enabled: new Map<PluginName, EnabledRecord>(),
    catalog: [] as Extract<EngineRecord, { kind: 'catalog' }>[],
    undelivered: [] as string[],
  }
  let taken = 0
  const index = (record: EngineRecord): void => {
    records.push(record)
    switch (record.kind) {
      case 'enabled':
        byKind.enabled.set(record.plugin, record)
        return
      case 'catalog':
        byKind.catalog.push(record)
        return
      case 'pending':
        byKind.undelivered.push(record.text)
        return
      case 'delivered':
        byKind.undelivered = []
        return
      case 'denied':
        return
      default:
        return record satisfies never
    }
  }
  const append = (record: EngineRecord): void => {
    index(record)
    emit({ type: 'record', record })
  }

  const closing = new AbortController()
  let ended: Promise<void> | undefined
  let run: Run = { signal: new AbortController().signal, turns: 0, last: undefined, stoppedBy: undefined, calls: [] }
  let totalTurns = 0
  let hookPhase: Promise<unknown> = Promise.resolve()

  const enabled = (): PluginName[] => [...byKind.enabled.keys()]
  const pluginOf = (name: PluginName): Plugin => catalog.plugins.get(name)!
  const activePlugins = (): Plugin[] => enabled().map(pluginOf)

  /** In the first request's tool list: enabled at creation, or a dependency pulled in by such a plugin. */
  const isInitial = (name: PluginName): boolean => {
    const cause = byKind.enabled.get(name)?.cause
    return cause === 'initial' || (typeof cause === 'object' && byKind.enabled.get(cause.dependencyOf)?.cause === 'initial')
  }
  const declaresNatively = (name: PluginName): boolean => toolMode === 'native' || isInitial(name)

  const catalogText = (): string => {
    const lines = [...catalog.plugins].filter(([name]) => !byKind.enabled.has(name)).map(([name, p]) => `- ${name}: ${p.description}`)
    const body = lines.length > 0 ? `Plugins you can enable with core__enable_plugin:\n${lines.join('\n')}` : 'Every available plugin is enabled.'
    return redact(`<plugin-catalog>\n${body}\n</plugin-catalog>`)
  }

  const pluginText = (name: PluginName, added: string | undefined): string => {
    const plugin = pluginOf(name)
    const tools = (plugin.tools ?? []).map((tool) => ({ name: qualify(name, tool.name), tool }))
    const parts = [plugin.instructions, added]
    if (plugin.skills?.length) {
      parts.push(`Skills (load with core__load_skill):\n${plugin.skills.map((s) => `- ${name}__${s.name}: ${s.description}`).join('\n')}`)
    }
    if (tools.length > 0 && declaresNatively(name)) parts.push(`Tools: ${tools.map((t) => t.name).join(', ')}`)
    else if (tools.length > 0) {
      const lines = tools.map((t) => `- ${t.name}: ${t.tool.description}\n  Parameters: ${JSON.stringify(t.tool.parameters)}`)
      parts.push(`Tools (call with ${CALL_TOOL.name}):\n${lines.join('\n')}`)
    }
    return redact(`<plugin name="${name}">\n${parts.filter((p) => p?.trim()).join('\n\n')}\n</plugin>`)
  }

  /** Calls one hook under the timeout, never rejecting. The hook's signal fires on timeout, close or `extra`. */
  async function settle<T>(call: (signal: AbortSignal) => MaybePromise<T>, extra: readonly AbortSignal[]): Promise<Settled<T>> {
    // A ref'd timer, unlike AbortSignal.timeout, so a hook that never settles still gets its verdict.
    const timeout = new AbortController()
    const timer = setTimeout(() => timeout.abort(new Error('timeout')), options.hookTimeoutMs)
    const signal = AbortSignal.any([timeout.signal, ...extra])
    let onAbort = () => {}
    try {
      const value = await new Promise<T>((resolve, reject) => {
        onAbort = () => reject(signal.reason)
        if (signal.aborted) onAbort()
        signal.addEventListener('abort', onAbort, { once: true })
        Promise.resolve()
          .then(() => call(signal))
          .then(resolve, reject)
      })
      return { ok: true, value }
    } catch (error) {
      return { ok: false, reason: timeout.signal.aborted ? `timed out after ${options.hookTimeoutMs}ms` : messageOf(error) }
    } finally {
      clearTimeout(timer)
      signal.removeEventListener('abort', onAbort)
    }
  }

  /** Runs one hook across the plugins that define it, concurrently, returning results in plugin order. */
  function each<T>(
    plugins: readonly Plugin[],
    hook: keyof Hooks,
    invoke: (hooks: Hooks, signal: AbortSignal) => MaybePromise<T>,
    extra: readonly AbortSignal[] = [closing.signal],
  ): Promise<{ readonly plugin: PluginName; readonly settled: Settled<T> }[]> {
    const hooked = plugins.filter((p) => p.hooks?.[hook])
    return Promise.all(hooked.map(async (p) => ({ plugin: p.name as PluginName, settled: await settle((s) => invoke(p.hooks!, s), extra) })))
  }

  const logFailures = (hook: keyof Hooks, results: readonly { plugin: PluginName; settled: Settled<unknown> }[]): void => {
    for (const { plugin, settled } of results) if (!settled.ok) log(`plugin "${plugin}" ${hook} failed: ${settled.reason}`)
  }

  const addedText = (hook: keyof Hooks, results: readonly { plugin: PluginName; settled: Settled<string | undefined> }[]): string[] => {
    logFailures(hook, results)
    return results.flatMap(({ settled }) => (settled.ok && typeof settled.value === 'string' && settled.value.trim() ? [settled.value] : []))
  }

  async function runGates(call: ToolCallSnapshot, signal: AbortSignal): Promise<{ plugin: PluginName; reason: string }[]> {
    const results = await each(activePlugins(), 'beforeToolCall', (h, s) => h.beforeToolCall!(call, s), [closing.signal, signal])
    return results.flatMap(({ plugin, settled }) => {
      if (!settled.ok) return [{ plugin, reason: redact(`gate failed: ${settled.reason}`) }]
      const verdict: unknown = settled.value
      if (verdict === 'allow') return []
      const deny = typeof verdict === 'object' && verdict !== null ? (verdict as { deny?: unknown }).deny : undefined
      return [{ plugin, reason: typeof deny === 'string' ? redact(deny) : 'gate returned no verdict' }]
    })
  }

  /**
   * Commits the `enabled` records before the first await, so a racing enable sees the plugin enabled and adds
   * nothing. onEnable phases run through one promise chain so their text lands in enable order.
   */
  async function enablePlugin(name: PluginName, cause: 'initial' | 'host' | 'model'): Promise<{ added: PluginName[]; text: string }> {
    const added = catalog.closures.get(name)!.filter((n) => !byKind.enabled.has(n))
    for (const n of added) append({ kind: 'enabled', plugin: n, cause: n === name ? cause : { dependencyOf: name } })
    if (added.length === 0) return { added, text: '' }
    const phase = hookPhase.then(async () => {
      const blocks: string[] = []
      for (const n of added) {
        const snapshot = deepFreeze({ plugin: n as string, cause: byKind.enabled.get(n)!.cause, enabled: enabled() as string[] })
        const [extra] = addedText('onEnable', await each([pluginOf(n)], 'onEnable', (h, s) => h.onEnable!(snapshot, s)))
        blocks.push(pluginText(n, extra))
      }
      return blocks.join('\n\n')
    })
    hookPhase = phase.catch(() => {})
    return { added, text: await phase }
  }

  const parseName = (name: string): PluginName => {
    const parsed = catalog.pluginName(name)
    if (!parsed) throw new Error(`unknown plugin "${name}"`)
    return parsed
  }

  const core: Plugin = {
    name: CORE,
    description: 'Enables plugins and loads skills.',
    tools: [
      {
        name: 'enable_plugin',
        description: 'Enable a plugin from the catalog. Its tools and skills are usable from your next step.',
        parameters: {
          type: 'object',
          properties: { name: { type: 'string', description: 'Plugin name from the catalog' } },
          required: ['name'],
          additionalProperties: false,
        },
        async execute(args) {
          const name = catalog.pluginName(String(args.name))
          if (!name) return errorResult(`No plugin named "${String(args.name)}". Available: ${[...catalog.plugins.keys()].join(', ')}.`)
          const { added, text } = await enablePlugin(name, 'model')
          if (added.length === 0) return textResult(`${name} is already enabled.`)
          return textResult(`Enabled ${added.join(', ')}. Usable from your next step.\n\n${text}`)
        },
      },
      {
        name: 'load_skill',
        description: 'Load the full text of a skill listed by an enabled plugin.',
        parameters: {
          type: 'object',
          properties: { name: { type: 'string', description: 'Skill name, <plugin>__<skill>' } },
          required: ['name'],
          additionalProperties: false,
        },
        async execute(args) {
          const found = catalog.skills.get(String(args.name))
          if (!found || !byKind.enabled.has(found.plugin)) return errorResult(`No skill named "${String(args.name)}" in an enabled plugin.`)
          return textResult(redact(await found.skill.load()))
        },
      },
    ],
  }

  const registry = new Map<string, Entry>([
    ...(core.tools ?? []).map((tool): [string, Entry] => [qualify(CORE, tool.name), { name: qualify(CORE, tool.name), plugin: CORE, tool }]),
    ...[...catalog.tools.values()].map((t): [string, Entry] => [t.name, t]),
  ])
  const activeEntry = (name: string): Entry | undefined => {
    const entry = registry.get(name)
    return entry && (entry.plugin === CORE || byKind.enabled.has(entry.plugin)) ? entry : undefined
  }

  type Resolved = { readonly kind: 'ok'; readonly entry: Entry; readonly args: JsonObject } | { readonly kind: 'error'; readonly result: ToolResult }

  function resolve(call: ToolCall): Resolved {
    if (toolMode !== 'dispatch' || call.name !== CALL_TOOL.name) {
      const entry = activeEntry(call.name)
      return entry ? { kind: 'ok', entry, args: call.args } : { kind: 'error', result: errorResult(`Unknown tool "${call.name}".`) }
    }
    const target = String(call.args.tool)
    const entry = activeEntry(target)
    if (!entry) return { kind: 'error', result: errorResult(`Unknown tool "${target}". Enable its plugin first.`) }
    if (entry.plugin === CORE) return { kind: 'error', result: errorResult(`Call ${target} directly, not through ${CALL_TOOL.name}.`) }
    const raw = call.args.args ?? {}
    const checked: ReturnType<Validate> =
      typeof raw === 'object' && raw !== null && !Array.isArray(raw)
        ? validate(entry.tool.parameters, raw as JsonObject, target)
        : { ok: false, error: '"args" must be an object' }
    if (!checked.ok) {
      return { kind: 'error', result: errorResult(`Invalid arguments for ${target}: ${checked.error}\nParameters: ${JSON.stringify(entry.tool.parameters)}`) }
    }
    return { kind: 'ok', entry, args: checked.args }
  }

  async function execute(entry: Entry, args: JsonObject, signal: AbortSignal): Promise<ToolResult> {
    try {
      const raw: unknown = await entry.tool.execute(args, signal)
      const result = parseResult(raw)
      if (!result) return errorResult(`Tool ${entry.name} returned a malformed result.`)
      return { content: result.content.map((c) => (c.type === 'text' ? { type: 'text', text: redact(c.text) } : c)), ...(result.isError ? { isError: true } : {}) }
    } catch (error) {
      return errorResult(redact(`Tool ${entry.name} failed: ${messageOf(error)}`))
    }
  }

  if (options.start.kind === 'resume') {
    for (const value of options.start.records) index(parseRecord(value, catalog, registry))
    taken = records.length
  }
  const queue = (text: string): void => {
    if (text) append({ kind: 'pending', text })
  }
  const initialText: string[] = []
  for (const name of options.enabled) {
    const parsed = parseName(name)
    if (byKind.enabled.has(parsed)) continue
    const { text } = await enablePlugin(parsed, options.start.kind === 'fresh' ? 'initial' : 'host')
    if (options.start.kind === 'fresh') initialText.push(text)
    else queue(text)
  }
  let systemPrompt: string | undefined
  if (options.start.kind === 'fresh') {
    systemPrompt = [redact(options.start.systemPrompt), catalogText(), ...initialText].filter((p) => p.trim()).join('\n\n')
    append({ kind: 'catalog', fingerprint: catalog.fingerprint })
  }

  return {
    systemPrompt,

    tools() {
      const declared = enabled().filter(declaresNatively)
      const coreSpecs = (core.tools ?? []).map((tool) => spec(qualify(CORE, tool.name), tool))
      const pluginSpecs = declared.flatMap((name) => (pluginOf(name).tools ?? []).map((tool) => spec(qualify(name, tool.name), tool)))
      return [...coreSpecs, ...(toolMode === 'dispatch' ? [CALL_TOOL] : []), ...pluginSpecs]
    },

    takeRecords() {
      const fresh = records.slice(taken)
      taken = records.length
      return fresh
    },

    async beginPrompt(text, signal) {
      if (ended) throw new Error('session is closed')
      run = { signal, turns: 0, last: undefined, stoppedBy: undefined, calls: [] }
      const parts = [redact(text), ...byKind.undelivered]
      if (byKind.undelivered.length > 0) append({ kind: 'delivered' })
      if (byKind.catalog.at(-1)?.fingerprint !== catalog.fingerprint) {
        parts.push(catalogText())
        append({ kind: 'catalog', fingerprint: catalog.fingerprint })
      }
      const snapshot = deepFreeze({ text: parts[0]!, enabled: enabled() as string[] })
      parts.push(...addedText('onUserPrompt', await each(activePlugins(), 'onUserPrompt', (h, s) => h.onUserPrompt!(snapshot, s))).map(redact))
      return parts.join('\n\n')
    },

    async callTool(call, signal) {
      const resolved = resolve(call)
      if (resolved.kind === 'error') return resolved.result
      const { entry, args } = resolved
      const snapshot: ToolCallSnapshot = deepFreeze({
        id: call.id,
        name: entry.name as string,
        plugin: entry.plugin as string,
        tool: entry.tool.name,
        args: structuredClone(args),
      })
      emit({ type: 'tool_start', call: snapshot })
      const denials = await runGates(snapshot, signal)
      for (const d of denials) append({ kind: 'denied', callId: call.id, tool: entry.name, plugin: d.plugin, reason: d.reason })
      const result = denials.length > 0 ? errorResult(`Denied by ${denials.map((d) => `${d.plugin}: ${d.reason}`).join('; ')}`) : await execute(entry, snapshot.args, signal)
      const event: ToolResultSnapshot = deepFreeze({ call: snapshot, outcome: denials.length > 0 ? { kind: 'denied', denials } : { kind: 'ran', result } })
      run.calls.push(event)
      logFailures('onToolResult', await each(activePlugins(), 'onToolResult', (h, s) => h.onToolResult!(event, s)))
      emit({ type: 'tool_end', result: event })
      return result
    },

    async endTurn(turn) {
      run.turns += 1
      totalTurns += 1
      run.last = turn.kind === 'ok' ? { kind: 'ok', text: redact(turn.text) } : turn.kind === 'error' ? { kind: 'error', message: redact(turn.message) } : turn
      const snapshot = deepFreeze({ turn: run.turns, text: run.last.kind === 'ok' ? run.last.text : '', calls: run.calls })
      run.calls = []
      logFailures('onTurnEnd', await each(activePlugins(), 'onTurnEnd', (h, s) => h.onTurnEnd!(snapshot, s)))
      emit({ type: 'turn_end', turn: snapshot })
      for (const condition of stopConditions) {
        const reason = condition(run, options.maxTurns)
        if (reason) {
          run.stoppedBy = reason
          return 'stop'
        }
      }
      return 'continue'
    },

    endRun() {
      return runOutcome(run)
    },

    async enable(name) {
      queue((await enablePlugin(parseName(name), 'host')).text)
    },

    redact,

    close() {
      ended ??= (async () => {
        closing.abort(new Error('session closed'))
        // The close signal has already fired, so onSessionEnd runs under its timeout alone.
        const snapshot = deepFreeze({ turns: totalTurns, enabled: enabled() as string[] })
        logFailures('onSessionEnd', await each(activePlugins(), 'onSessionEnd', (h, s) => h.onSessionEnd!(snapshot, s), []))
      })()
      return ended
    },
  }
}

/** Abort first: an aborted run reports aborted even when it also hit max turns on the same turn. */
const stopConditions: readonly ((run: Run, maxTurns: number) => StopReason | undefined)[] = [
  (run) => (run.signal.aborted ? 'aborted' : undefined),
  (run, maxTurns) => (run.turns >= maxTurns ? 'max_turns' : undefined),
]

function runOutcome({ turns, last, stoppedBy }: Run): RunResult {
  if (stoppedBy === 'aborted' || last?.kind === 'aborted') return { stop: 'aborted', turns }
  if (last?.kind === 'error') return { stop: 'error', message: last.message, turns }
  const text = last?.kind === 'ok' ? last.text : ''
  return stoppedBy === 'max_turns' ? { stop: 'max_turns', text, turns } : { stop: 'done', text, turns }
}

/** Transcript boundary: a malformed or unknown record throws, because guessing would rebuild a different engine. */
function parseRecord(value: unknown, catalog: Catalog, registry: ReadonlyMap<string, { readonly name: ToolName }>): EngineRecord {
  const fail = (why: string): never => {
    throw new Error(`transcript record ${JSON.stringify(value)}: ${why}`)
  }
  if (typeof value !== 'object' || value === null) return fail('not an object')
  const r = value as Record<string, unknown>
  const plugin = (field: unknown): PluginName =>
    (typeof field === 'string' && catalog.pluginName(field)) || fail(`plugin ${JSON.stringify(field)} is not in the plugin set`)
  switch (r.kind) {
    case 'enabled': {
      const cause = r.cause
      if (cause === 'initial' || cause === 'host' || cause === 'model') return { kind: 'enabled', plugin: plugin(r.plugin), cause }
      if (typeof cause === 'object' && cause !== null && 'dependencyOf' in cause) {
        return { kind: 'enabled', plugin: plugin(r.plugin), cause: { dependencyOf: plugin(cause.dependencyOf) } }
      }
      return fail('unknown cause')
    }
    case 'denied': {
      const tool = typeof r.tool === 'string' ? registry.get(r.tool)?.name : undefined
      if (!tool) return fail('unknown tool')
      if (typeof r.callId !== 'string' || typeof r.reason !== 'string') return fail('missing callId or reason')
      return { kind: 'denied', callId: r.callId, tool, plugin: plugin(r.plugin), reason: r.reason }
    }
    case 'catalog':
      return typeof r.fingerprint === 'string' ? { kind: 'catalog', fingerprint: r.fingerprint } : fail('missing fingerprint')
    case 'pending':
      return typeof r.text === 'string' ? { kind: 'pending', text: r.text } : fail('missing text')
    case 'delivered':
      return { kind: 'delivered' }
    default:
      return fail('unknown kind')
  }
}

/** Known secret values become `[REDACTED:NAME]`, longest first so a secret containing another is replaced whole. */
function makeRedactor(secrets: Readonly<Record<string, string>>): (text: string) => string {
  const entries = Object.entries(secrets)
    .filter(([, value]) => value.length > 0)
    .sort(([, a], [, b]) => b.length - a.length)
  return (text) => entries.reduce((out, [name, value]) => out.split(value).join(`[REDACTED:${name}]`), text)
}

/** Plugin output is untrusted shape-wise; a JS plugin can return anything. */
function parseResult(value: unknown): ToolResult | undefined {
  if (typeof value !== 'object' || value === null) return undefined
  const { content, isError } = value as { content?: unknown; isError?: unknown }
  if (!Array.isArray(content)) return undefined
  const blocks: Content[] = []
  for (const c of content as unknown[]) {
    const block = c as Record<string, unknown>
    if (block?.type === 'text' && typeof block.text === 'string') blocks.push({ type: 'text', text: block.text })
    else if (block?.type === 'image' && typeof block.data === 'string' && typeof block.mimeType === 'string') {
      blocks.push({ type: 'image', data: block.data, mimeType: block.mimeType })
    } else return undefined
  }
  return { content: blocks, isError: isError === true }
}

function spec(name: ToolName, tool: Tool): ToolSpec {
  return { name, description: tool.description, parameters: tool.parameters }
}

function textResult(text: string): ToolResult {
  return { content: [{ type: 'text', text }] }
}

function errorResult(text: string): ToolResult {
  return { content: [{ type: 'text', text }], isError: true }
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function deepFreeze<T>(value: T): T {
  if (typeof value === 'object' && value !== null && !Object.isFrozen(value)) {
    Object.freeze(value)
    for (const child of Object.values(value)) deepFreeze(child)
  }
  return value
}
