// The only place plugin objects are validated. Everything downstream trusts a Catalog and its brands.

import { createHash } from 'node:crypto'
import { readdir } from 'node:fs/promises'
import { join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import type { Plugin, Skill, Tool } from './plugin.ts'

declare const pluginNameBrand: unique symbol
/** A plugin name that exists in the catalog, or `core`. */
export type PluginName = string & { readonly [pluginNameBrand]: true }

declare const toolNameBrand: unique symbol
/** A model-facing `<plugin>__<tool>` name of a tool that exists. */
export type ToolName = string & { readonly [toolNameBrand]: true }

export const CORE = 'core' as PluginName

/** Unambiguous because plugin names cannot contain `_`. */
export function qualify(plugin: PluginName, local: string): ToolName {
  return `${plugin}__${local}` as ToolName
}

export interface CatalogTool {
  readonly name: ToolName
  readonly plugin: PluginName
  readonly tool: Tool
}

export interface CatalogSkill {
  readonly plugin: PluginName
  readonly skill: Skill
}

export interface Catalog {
  /** Name order, so text derived from it is stable. */
  readonly plugins: ReadonlyMap<PluginName, Plugin>
  /** Dependencies first, the plugin itself last. */
  readonly closures: ReadonlyMap<PluginName, readonly PluginName[]>
  readonly tools: ReadonlyMap<ToolName, CatalogTool>
  /** Keyed by `<plugin>__<skill>`. */
  readonly skills: ReadonlyMap<string, CatalogSkill>
  /** Changes when a plugin is added, removed, renamed or redescribed. */
  readonly fingerprint: string
  pluginName(name: string): PluginName | undefined
}

export class CatalogError extends Error {
  readonly problems: readonly string[]
  constructor(problems: readonly string[]) {
    super(`invalid plugins:\n- ${problems.join('\n- ')}`)
    this.problems = problems
  }
}

const PLUGIN_NAME = /^[a-z0-9-]+$/
const TOOL_NAME = /^[A-Za-z0-9_-]+$/
const SKILL_NAME = /^[a-z0-9_-]+$/
// OpenAI-compatible endpoints reject longer function names.
const MAX_TOOL_NAME = 64
const HOOKS = new Set(['onEnable', 'onUserPrompt', 'beforeToolCall', 'onToolResult', 'onTurnEnd', 'onSessionEnd'])

export function parseCatalog(plugins: readonly Plugin[]): Catalog {
  const problems: string[] = []
  const byName = new Map<PluginName, Plugin>()
  for (const [index, value] of plugins.entries()) {
    const parsed = parsePlugin(value, `plugins[${index}]`)
    if (!parsed.ok) {
      problems.push(...parsed.problems)
      continue
    }
    const name = parsed.plugin.name as PluginName
    if (byName.has(name)) problems.push(`plugin "${name}" is defined twice`)
    else byName.set(name, parsed.plugin)
  }
  for (const [name, plugin] of byName) {
    for (const dep of plugin.dependsOn ?? []) {
      if (dep === name) problems.push(`plugin "${name}" depends on itself`)
      else if (!byName.has(dep as PluginName)) problems.push(`plugin "${name}" depends on unknown plugin "${dep}"`)
    }
  }
  if (problems.length > 0) throw new CatalogError(problems)

  const closures = new Map<PluginName, PluginName[]>()
  const visiting: PluginName[] = []
  const visit = (name: PluginName): PluginName[] => {
    const done = closures.get(name)
    if (done) return done
    const cycleStart = visiting.indexOf(name)
    if (cycleStart !== -1) throw new CatalogError([`dependency cycle: ${[...visiting.slice(cycleStart), name].join(' -> ')}`])
    visiting.push(name)
    const closure = [...new Set([...(byName.get(name)!.dependsOn ?? []).flatMap((dep) => visit(dep as PluginName)), name])]
    visiting.pop()
    closures.set(name, closure)
    return closure
  }
  const sorted = [...byName.keys()].sort()
  for (const name of sorted) visit(name)

  const tools = new Map<ToolName, CatalogTool>()
  const skills = new Map<string, CatalogSkill>()
  for (const name of sorted) {
    const plugin = byName.get(name)!
    for (const tool of plugin.tools ?? []) tools.set(qualify(name, tool.name), { name: qualify(name, tool.name), plugin: name, tool })
    for (const skill of plugin.skills ?? []) skills.set(`${name}__${skill.name}`, { plugin: name, skill })
  }

  const fingerprint = createHash('sha256')
    .update(JSON.stringify(sorted.map((name) => [name, byName.get(name)!.description])))
    .digest('hex')
    .slice(0, 16)

  return {
    plugins: new Map(sorted.map((name) => [name, byName.get(name)!])),
    closures,
    tools,
    skills,
    fingerprint,
    pluginName: (name) => (byName.has(name as PluginName) ? (name as PluginName) : undefined),
  }
}

/**
 * Imports every plugin module in a trusted local directory: `*.ts`, `*.js` or `*.mjs` files, and subdirectories
 * with an `index.ts` or `index.js`. Each must default-export a plugin. Sorted by entry name so the catalog is stable.
 */
export async function loadPlugins(dir: string | URL): Promise<Plugin[]> {
  const root = typeof dir === 'string' ? dir : fileURLToPath(dir)
  const entries = (await readdir(root, { withFileTypes: true })).sort((a, b) => (a.name < b.name ? -1 : 1))
  const plugins: Plugin[] = []
  for (const entry of entries) {
    const path = entry.isDirectory() ? await indexOf(join(root, entry.name)) : moduleFile(root, entry.name)
    if (!path) continue
    const mod: { default?: unknown } = await import(pathToFileURL(path).href)
    const parsed = parsePlugin(mod.default, path)
    if (!parsed.ok) throw new CatalogError(parsed.problems)
    plugins.push(parsed.plugin)
  }
  return plugins
}

function moduleFile(root: string, name: string): string | undefined {
  if (name.startsWith('.') || name.endsWith('.d.ts') || name.endsWith('.test.ts')) return undefined
  return /\.(ts|js|mjs)$/.test(name) ? join(root, name) : undefined
}

async function indexOf(dir: string): Promise<string | undefined> {
  const names = new Set(await readdir(dir))
  const index = ['index.ts', 'index.js'].find((name) => names.has(name))
  return index && join(dir, index)
}

type Parsed = { readonly ok: true; readonly plugin: Plugin } | { readonly ok: false; readonly problems: readonly string[] }

/** Shape and per-plugin rules. Cross-plugin rules (duplicates, dependencies) live in parseCatalog. */
function parsePlugin(value: unknown, source: string): Parsed {
  if (!isRecord(value)) return { ok: false, problems: [`${source}: default export is not a plugin object`] }
  const problems: string[] = []
  const { name, description, dependsOn, instructions, tools, skills, hooks } = value
  const label = typeof name === 'string' ? `plugin "${name}"` : source
  const fail = (problem: string) => problems.push(`${label}: ${problem}`)

  if (typeof name !== 'string' || !PLUGIN_NAME.test(name)) fail('name must match [a-z0-9-]+')
  else if (name === CORE) fail('"core" is reserved')
  if (typeof description !== 'string' || description.trim() === '' || description.includes('\n')) fail('description must be one non-empty line')
  if (dependsOn !== undefined && !(Array.isArray(dependsOn) && dependsOn.every((d) => typeof d === 'string'))) fail('dependsOn must be a list of plugin names')
  if (instructions !== undefined && typeof instructions !== 'string') fail('instructions must be a string')

  if (tools !== undefined && !Array.isArray(tools)) fail('tools must be a list')
  const toolNames = new Set<string>()
  for (const tool of Array.isArray(tools) ? tools : []) {
    if (!isRecord(tool) || typeof tool.name !== 'string' || !TOOL_NAME.test(tool.name)) {
      fail('every tool needs a name matching [A-Za-z0-9_-]+')
      continue
    }
    const at = `tool "${tool.name}"`
    if (toolNames.has(tool.name)) fail(`${at} is defined twice`)
    toolNames.add(tool.name)
    if (typeof name === 'string' && `${name}__${tool.name}`.length > MAX_TOOL_NAME) fail(`${at}: "${name}__${tool.name}" is longer than ${MAX_TOOL_NAME} characters`)
    if (typeof tool.description !== 'string') fail(`${at}: description must be a string`)
    if (!isRecord(tool.parameters) || tool.parameters.type !== 'object') fail(`${at}: parameters must be a JSON Schema with type "object"`)
    if (typeof tool.execute !== 'function') fail(`${at}: execute must be a function`)
  }

  if (skills !== undefined && !Array.isArray(skills)) fail('skills must be a list')
  const skillNames = new Set<string>()
  for (const skill of Array.isArray(skills) ? skills : []) {
    if (!isRecord(skill) || typeof skill.name !== 'string' || !SKILL_NAME.test(skill.name)) {
      fail('every skill needs a name matching [a-z0-9_-]+')
      continue
    }
    const at = `skill "${skill.name}"`
    if (skillNames.has(skill.name)) fail(`${at} is defined twice`)
    skillNames.add(skill.name)
    if (typeof skill.description !== 'string') fail(`${at}: description must be a string`)
    if (typeof skill.load !== 'function') fail(`${at}: load must be a function`)
  }

  if (hooks !== undefined && !isRecord(hooks)) fail('hooks must be an object')
  for (const [hook, fn] of Object.entries(isRecord(hooks) ? hooks : {})) {
    if (!HOOKS.has(hook)) fail(`unknown hook "${hook}"`)
    else if (typeof fn !== 'function') fail(`hook "${hook}" must be a function`)
  }

  // Every field the Plugin type declares was checked above.
  return problems.length > 0 ? { ok: false, problems } : { ok: true, plugin: value as unknown as Plugin }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
