// The only module that imports @earendil-works/*. It binds the engine port to pi's Agent, resolves models, and
// carries engine records inside pi's transcript. Every plugin rule lives behind the Engine port.

import { Agent, type AgentMessage, type AgentTool, type StreamFn } from '@earendil-works/pi-agent-core'
import { envApiKeyAuth, validateToolArguments, type Api, type AssistantMessage, type Message, type Model, type TSchema } from '@earendil-works/pi-ai'
import { openAICompletionsApi } from '@earendil-works/pi-ai/api/openai-completions.lazy'
import { createModels, createProvider } from '@earendil-works/pi-ai/models'
import { builtinModels } from '@earendil-works/pi-ai/providers/all'
import { parseCatalog } from './catalog.ts'
import { createEngine, type Engine, type Turn, type Validate } from './engine.ts'
import type { JsonObject, JsonValue, ToolResult } from './plugin.ts'
import type { EngineRecord, ModelSpec, RunResult, Session, SessionEvent, SessionOptions, Transcript } from './session.ts'

/** Engine records ride in pi's transcript under their own role; convertToLlm drops them. */
interface RecordMessage {
  readonly role: 'aigent'
  readonly record: EngineRecord
  readonly timestamp: number
}

declare module '@earendil-works/pi-agent-core' {
  interface CustomAgentMessages {
    aigent: RecordMessage
  }
}

export interface ResolvedModel {
  readonly model: Model<Api>
  readonly streamFn: StreamFn
  /** The model's API key under its env var name, so it is redacted like any host secret. */
  readonly secrets: Readonly<Record<string, string>>
}

const TRANSCRIPT_FORMAT = 'aigent-transcript/1'

export async function createSession(options: SessionOptions): Promise<Session> {
  return startSession(options, await resolveModel(options.model))
}

/** `createSession` with the model already resolved. The adapter's offline test passes pi's faux provider here. */
export async function startSession(options: SessionOptions, resolved: ResolvedModel): Promise<Session> {
  if (options.systemPrompt !== undefined && options.transcript !== undefined) throw new Error('pass systemPrompt or transcript, not both')
  const resumed = options.transcript && parseTranscript(options.transcript)
  const listeners = new Set<(event: SessionEvent) => void>()
  const writeLog = options.log ?? ((line: string) => console.error(`[aigent] ${line}`))
  // Nobody can subscribe before createSession returns, so this never runs before `engine` exists.
  const dispatch = (event: SessionEvent): void => {
    for (const listener of listeners) {
      try {
        listener(redactJson(event, engine.redact))
      } catch (error) {
        writeLog(engine.redact(`listener threw: ${messageOf(error)}`))
      }
    }
  }

  const engine: Engine = await createEngine({
    catalog: parseCatalog(options.plugins),
    toolMode: options.toolMode ?? 'native',
    start: resumed ? { kind: 'resume', records: resumed.records } : { kind: 'fresh', systemPrompt: options.systemPrompt ?? '' },
    enabled: options.enabled ?? [],
    secrets: { ...options.secrets, ...resolved.secrets },
    maxTurns: options.maxTurns ?? 25,
    hookTimeoutMs: options.hookTimeoutMs ?? 10_000,
    validate: piValidate,
    emit: dispatch,
    log: writeLog,
  })

  const agentTools = (): AgentTool[] =>
    engine.tools().map((spec) => ({
      name: spec.name,
      label: spec.name,
      description: spec.description,
      parameters: spec.parameters as unknown as TSchema,
      execute: async (toolCallId, params, signal) => {
        const result = await engine.callTool({ id: toolCallId, name: spec.name, args: params as JsonObject }, signal ?? new AbortController().signal)
        return toAgentResult(result)
      },
    }))
  const wrap = (record: EngineRecord): RecordMessage => ({ role: 'aigent', record, timestamp: Date.now() })

  // The last assistant message finishTurn reported, so a run pi ends without calling it still gets its turn.
  let reported: AgentMessage | undefined
  const agent = new Agent({
    initialState: { model: resolved.model, systemPrompt: engine.systemPrompt, tools: agentTools(), messages: resumed?.messages ?? [] },
    streamFn: resolved.streamFn,
    convertToLlm: (messages) => messages.filter((m): m is Message => m.role !== 'aigent'),
    // Runs before pi declares tool changes, so the new declarations land ahead of the request that can use them.
    prepareNextTurnWithContext: (turn) => ({ context: { ...turn.context, tools: agentTools() }, messages: engine.takeRecords().map(wrap) }),
    finishTurn: async (turn) => {
      reported = turn.message
      return (await engine.endTurn(toTurn(turn.message))) === 'stop' ? { action: 'end' } : undefined
    },
  })
  agent.subscribe((event) => {
    if (event.type === 'message_update' && event.assistantMessageEvent.type === 'text_delta') {
      dispatch({ type: 'text', delta: event.assistantMessageEvent.delta })
    }
  })

  const flush = (): void => {
    const records = engine.takeRecords()
    if (records.length > 0) agent.state.messages = [...agent.state.messages, ...records.map(wrap)]
  }
  flush()

  let running: AbortController | undefined
  let closed: Promise<void> | undefined

  return {
    async prompt(text, { signal } = {}) {
      if (closed) throw new Error('session is closed')
      if (running) throw new Error('a prompt is already running')
      const controller = new AbortController()
      running = controller
      const runSignal = signal ? AbortSignal.any([signal, controller.signal]) : controller.signal
      const onAbort = () => agent.abort()
      runSignal.addEventListener('abort', onAbort, { once: true })
      try {
        const content = await engine.beginPrompt(text, runSignal)
        agent.state.tools = agentTools()
        reported = undefined
        const run = agent.prompt([...engine.takeRecords().map(wrap), { role: 'user', content, timestamp: Date.now() }])
        // agent.prompt registers its run synchronously, so an abort that fired before it started still lands.
        if (runSignal.aborted) agent.abort()
        await run
        const last = agent.state.messages.at(-1)
        if (last?.role === 'assistant' && last !== reported) await engine.endTurn(toTurn(last))
        flush()
        return engine.endRun()
      } finally {
        runSignal.removeEventListener('abort', onAbort)
        running = undefined
      }
    },

    async enable(name) {
      await engine.enable(name)
      if (!running) flush()
    },

    subscribe(listener) {
      listeners.add(listener)
      return () => listeners.delete(listener)
    },

    transcript() {
      const messages = JSON.parse(JSON.stringify(agent.state.messages)) as AgentMessage[]
      return { format: TRANSCRIPT_FORMAT, messages: messages.map((m) => exportMessage(m, engine.redact)) as unknown as JsonValue[] }
    },

    close() {
      closed ??= (async () => {
        running?.abort()
        await agent.waitForIdle()
        flush()
        await engine.close()
      })()
      return closed
    },
  }
}

async function resolveModel(spec: ModelSpec): Promise<ResolvedModel> {
  if (spec.kind === 'openai-compatible') {
    const key = process.env[spec.apiKeyEnv]
    if (!key) throw new Error(`${spec.apiKeyEnv} is not set`)
    const models = createModels()
    models.setProvider(
      createProvider({
        id: 'openai-compatible',
        baseUrl: spec.baseUrl,
        auth: { apiKey: envApiKeyAuth(spec.apiKeyEnv, [spec.apiKeyEnv]) },
        models: [
          {
            id: spec.id,
            name: spec.id,
            api: 'openai-completions',
            baseUrl: spec.baseUrl,
            provider: 'openai-compatible',
            type: 'chat',
            reasoning: spec.reasoning ?? true,
            input: ['text'],
            cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
            contextWindow: spec.contextWindow ?? 131_072,
            maxTokens: spec.maxTokens ?? 8192,
          },
        ],
        api: openAICompletionsApi(),
      }),
    )
    const model = models.getModel('openai-compatible', spec.id)
    if (!model) throw new Error(`model ${spec.id} did not register`)
    return { model, streamFn: (m, context, o) => models.streamSimple(m, context, o), secrets: { [spec.apiKeyEnv]: key } }
  }
  const models = builtinModels()
  const model = models.getModel(spec.provider, spec.id)
  if (!model) throw new Error(`unknown model ${spec.provider}/${spec.id}`)
  const key = (await models.getAuth(model))?.auth.apiKey
  return { model, streamFn: (m, context, o) => models.streamSimple(m, context, o), secrets: key ? { MODEL_API_KEY: key } : {} }
}

const piValidate: Validate = (schema, args, name) => {
  try {
    const tool = { name, description: '', parameters: schema as unknown as TSchema }
    const valid: JsonObject = validateToolArguments(tool, { type: 'toolCall', id: '', name, arguments: args as Record<string, never> })
    return { ok: true, args: valid }
  } catch (error) {
    return { ok: false, error: messageOf(error) }
  }
}

function toAgentResult(result: ToolResult) {
  return { content: result.content.map((c) => ({ ...c })), details: undefined, ...(result.isError ? { isError: true } : {}) }
}

function toTurn(message: AssistantMessage): Turn {
  if (message.stopReason === 'aborted') return { kind: 'aborted' }
  if (message.stopReason === 'error') return { kind: 'error', message: message.errorMessage ?? 'model request failed' }
  return { kind: 'ok', text: message.content.flatMap((c) => (c.type === 'text' ? [c.text] : [])).join('') }
}

/** Resume boundary: the format tag and a role on every message. Records are parsed by the engine. */
function parseTranscript(transcript: Transcript): { readonly messages: AgentMessage[]; readonly records: readonly unknown[] } {
  if (transcript?.format !== TRANSCRIPT_FORMAT || !Array.isArray(transcript.messages)) throw new Error(`not an ${TRANSCRIPT_FORMAT} transcript`)
  const messages = transcript.messages.map((m, i) => {
    if (typeof m !== 'object' || m === null || Array.isArray(m) || typeof (m as { role?: unknown }).role !== 'string') {
      throw new Error(`transcript message ${i} has no role`)
    }
    return m as unknown as AgentMessage
  })
  return { messages, records: messages.flatMap((m) => (m.role === 'aigent' ? [m.record as unknown] : [])) }
}

/** Text fields only. Opaque provider fields such as thinking and text signatures pass through untouched. */
function exportMessage(message: AgentMessage, redact: (text: string) => string): AgentMessage {
  const text = <T extends { type: string }>(c: T): T => (c.type === 'text' ? { ...c, text: redact((c as unknown as { text: string }).text) } : c)
  switch (message.role) {
    case 'system':
      return {
        ...message,
        content: typeof message.content === 'string' ? redact(message.content) : message.content.map(text),
        ...(message.sections ? { sections: Object.fromEntries(Object.entries(message.sections).map(([k, v]) => [k, v === null ? v : redact(v)])) } : {}),
      }
    case 'user':
      return { ...message, content: typeof message.content === 'string' ? redact(message.content) : message.content.map(text) }
    case 'assistant':
      return {
        ...message,
        content: message.content.map((c) =>
          c.type === 'text' ? text(c) : c.type === 'thinking' ? { ...c, thinking: redact(c.thinking) } : { ...c, arguments: redactJson(c.arguments, redact) },
        ),
        ...(message.errorMessage ? { errorMessage: redact(message.errorMessage) } : {}),
      }
    case 'toolResult':
      return { ...message, content: message.content.map(text) }
    case 'aigent': {
      const { record } = message
      if (record.kind === 'denied') return { ...message, record: { ...record, reason: redact(record.reason) } }
      if (record.kind === 'pending') return { ...message, record: { ...record, text: redact(record.text) } }
      return message
    }
    default:
      return message satisfies never
  }
}

/** Deep-redacts strings in our own JSON-shaped values. Image data is left alone. */
function redactJson<T>(value: T, redact: (text: string) => string): T {
  if (typeof value === 'string') return redact(value) as T
  if (Array.isArray(value)) return value.map((v) => redactJson(v, redact)) as T
  if (typeof value !== 'object' || value === null) return value
  const image = (value as { type?: unknown }).type === 'image'
  return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, image && k === 'data' ? v : redactJson(v, redact)])) as T
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
