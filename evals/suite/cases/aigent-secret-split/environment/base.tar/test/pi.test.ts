// The adapter offline, against pi's faux provider: what reaches the model, and in which request.

import assert from 'node:assert/strict'
import { test } from 'node:test'
import {
  collapseSystemMessages,
  fauxAssistantMessage,
  fauxProvider,
  fauxToolCall,
  getCurrentTools,
  type AssistantMessage,
  type Message,
  type TranscriptContext,
} from '@earendil-works/pi-ai'
import { createModels } from '@earendil-works/pi-ai/models'
import { startSession } from '../src/pi.ts'
import type { Plugin } from '../src/plugin.ts'
import type { Session, SessionOptions, ToolMode } from '../src/session.ts'
import { makeWeather, units } from './fixtures/plugins.ts'

type Step = (context: TranscriptContext, signal: AbortSignal | undefined) => AssistantMessage | Promise<AssistantMessage>

/** A session on the faux model. `requests` holds a copy of every context the model received. */
async function fauxSession(options: SessionOptions, steps: readonly Step[]): Promise<{ session: Session; requests: TranscriptContext[]; callCount: () => number }> {
  const faux = fauxProvider()
  const models = createModels()
  models.setProvider(faux.provider)
  const requests: TranscriptContext[] = []
  faux.setResponses(steps.map((step) => (context, streamOptions) => {
    requests.push(structuredClone(context))
    return step(context, streamOptions?.signal)
  }))
  const session = await startSession(options, { model: faux.getModel(), streamFn: (m, c, o) => models.streamSimple(m, c, o), secrets: {} })
  return { session, requests, callCount: () => faux.state.callCount }
}

const toolCall = (name: string, args: Record<string, string | Record<string, string>>): Step => () =>
  fauxAssistantMessage(fauxToolCall(name, args), { stopReason: 'toolUse' })
const reply = (text: string): Step => () => fauxAssistantMessage(text)
const declared = (context: TranscriptContext | undefined) => getCurrentTools(context?.messages ?? []).map((t) => t.name)
const lastToolResult = (context: TranscriptContext | undefined) =>
  context?.messages.findLast((m): m is Extract<Message, { role: 'toolResult' }> => m.role === 'toolResult')?.content.map((c) => (c.type === 'text' ? c.text : '')).join('')

/** Each request extends the previous one, as a provider without mid-conversation system messages renders it. */
function prefixOnlyGrows(requests: readonly TranscriptContext[]): boolean {
  const rendered = requests.map((r) => collapseSystemMessages(r).messages.map((m) => JSON.stringify(m)))
  return rendered.every((messages, i) => i === 0 || rendered[i - 1]!.every((m, j) => messages[j] === m))
}

for (const mode of ['native', 'dispatch'] as const satisfies readonly ToolMode[]) {
  test(`the enabled tool and its text reach the model before the request that uses them, in ${mode} mode`, async () => {
    const weather = makeWeather()
    const useWeather = mode === 'native' ? toolCall('weather__get_weather', { city: 'Lisbon' }) : toolCall('core__call_tool', { tool: 'weather__get_weather', args: { city: 'Lisbon' } })
    const { session, requests } = await fauxSession({ model: { kind: 'builtin', provider: 'faux', id: 'faux-1' }, systemPrompt: 'You are a test agent.', plugins: [units, weather.plugin], toolMode: mode }, [
      toolCall('core__enable_plugin', { name: 'weather' }),
      useWeather,
      reply('It is 17C in Lisbon.'),
    ])

    const result = await session.prompt('Weather in Lisbon?')

    assert.deepEqual(result, { stop: 'done', text: 'It is 17C in Lisbon.', turns: 3 })
    assert.equal(weather.calls.getWeather, 1)
    assert.ok(!declared(requests[0]).includes('weather__get_weather'), 'not declared before the enable')
    assert.match(lastToolResult(requests[1]) ?? '', /Report temperatures in Celsius/)
    if (mode === 'native') assert.ok(declared(requests[1]).includes('weather__get_weather'), 'declared on the request that uses it')
    else {
      assert.deepEqual(declared(requests[1]), declared(requests[0]), 'declarations never change in dispatch mode')
      assert.match(lastToolResult(requests[1]) ?? '', /weather__get_weather: Current weather for a city\.\n {2}Parameters: \{"type":"object"/)
    }
    assert.equal(prefixOnlyGrows(requests), mode === 'dispatch')
  })
}

test('a transcript survives JSON and resumes the enabled set without rerunning onEnable or holding a secret', async () => {
  const key = 'sk-station-0123456789'
  const first = makeWeather()
  const base = { model: { kind: 'builtin', provider: 'faux', id: 'faux-1' }, secrets: { STATION_KEY: key } } as const
  const original = await fauxSession({ ...base, plugins: [units, first.plugin], systemPrompt: 'You are a test agent.', maxTurns: 1 }, [
    toolCall('core__enable_plugin', { name: 'weather' }),
  ])
  assert.equal((await original.session.prompt('Weather in Lisbon?')).stop, 'max_turns')
  const saved = JSON.parse(JSON.stringify(original.session.transcript()))

  const second = makeWeather({ echo: key })
  const resumed = await fauxSession({ ...base, plugins: [units, second.plugin], transcript: saved }, [toolCall('weather__get_weather', { city: 'Porto' }), reply('16C.')])
  const result = await resumed.session.prompt('And in Porto?')
  const after = JSON.stringify(resumed.session.transcript())

  assert.equal(saved.format, 'aigent-transcript/1')
  assert.equal(result.stop, 'done')
  assert.equal(second.calls.onEnable, 0)
  assert.equal(second.calls.getWeather, 1)
  assert.ok(declared(resumed.requests[0]).includes('weather__get_weather'))
  assert.match(String(resumed.requests[0]?.messages[0]?.content), /^You are a test agent\./)
  assert.deepEqual(
    resumed.requests[0]?.messages.filter((m) => m.role === 'user').map((m) => m.content),
    ['Weather in Lisbon?', 'And in Porto?'],
    'records and enable text never become messages of their own',
  )
  assert.ok(!after.includes(key) && after.includes('[REDACTED:STATION_KEY]'))
})

test('a host enable saved in an idle transcript reaches the first user message after resume', async () => {
  const base = { model: { kind: 'builtin', provider: 'faux', id: 'faux-1' }, toolMode: 'dispatch' } as const
  const original = await fauxSession({ ...base, plugins: [units, makeWeather().plugin], systemPrompt: 'You are a test agent.' }, [])
  await original.session.enable('weather')
  const saved = JSON.parse(JSON.stringify(original.session.transcript()))

  const second = makeWeather()
  const resumed = await fauxSession({ ...base, plugins: [units, second.plugin], transcript: saved }, [reply('ok')])
  await resumed.session.prompt('Weather in Lisbon?')

  const users = resumed.requests[0]?.messages.filter((m) => m.role === 'user').map((m) => String(m.content))
  assert.equal(users?.length, 1)
  assert.match(users?.[0] ?? '', /^Weather in Lisbon\?\n\n[\s\S]*Weather data refreshes every 10 minutes\.[\s\S]*weather__get_weather: Current weather for a city\.\n {2}Parameters: /)
  assert.equal(second.calls.onEnable, 0)
})

test('a provider error ends the run with a redacted error result', async () => {
  const key = 'sk-provider-0123456789'
  const { session } = await fauxSession({ model: { kind: 'builtin', provider: 'faux', id: 'faux-1' }, systemPrompt: 'Test.', plugins: [], secrets: { PROVIDER_KEY: key } }, [
    () => fauxAssistantMessage('', { stopReason: 'error', errorMessage: `key ${key} was rejected` }),
  ])

  const result = await session.prompt('Hello?')

  assert.deepEqual(result, { stop: 'error', message: 'key [REDACTED:PROVIDER_KEY] was rejected', turns: 1 })
  assert.ok(!JSON.stringify(session.transcript()).includes(key))
})

test('the host signal cuts the model off, and max turns stops a model that keeps calling tools', async () => {
  const controller = new AbortController()
  const weather = makeWeather()
  const abortThenCall: Step = () => {
    controller.abort()
    return fauxAssistantMessage(fauxToolCall('weather__get_weather', { city: 'Lisbon' }), { stopReason: 'toolUse' })
  }
  const aborting = await fauxSession({ model: { kind: 'builtin', provider: 'faux', id: 'faux-1' }, systemPrompt: 'Test.', plugins: [units, weather.plugin], enabled: ['weather'] }, [abortThenCall, reply('late')])
  assert.equal((await aborting.session.prompt('Hello?', { signal: controller.signal })).stop, 'aborted')
  assert.equal(weather.calls.getWeather, 0, 'the aborted response never ran its tool call')

  const convert = toolCall('units__c_to_f', { celsius: '17' })
  const looping = await fauxSession({ model: { kind: 'builtin', provider: 'faux', id: 'faux-1' }, systemPrompt: 'Test.', plugins: [units], enabled: ['units'], maxTurns: 2 }, [convert, convert, convert])
  assert.equal((await looping.session.prompt('Convert forever.')).stop, 'max_turns')
  assert.equal(looping.callCount(), 2)
})

test('a second prompt while one runs rejects', async () => {
  let release = () => {}
  const held = new Promise<void>((resolve) => (release = resolve))
  const { session } = await fauxSession({ model: { kind: 'builtin', provider: 'faux', id: 'faux-1' }, systemPrompt: 'Test.', plugins: [] as Plugin[] }, [
    async () => {
      await held
      return fauxAssistantMessage('done')
    },
  ])

  const first = session.prompt('One.')
  await assert.rejects(session.prompt('Two.'), /already running/)
  release()
  assert.equal((await first).stop, 'done')
})
