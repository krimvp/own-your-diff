// The weather scenario against open-weight models on Ollama Cloud, through the public host API.
// Run with `npm run test:live`. Skipped without OLLAMA_API_KEY. Engine invariants are asserted; model behavior
// is measured and reported through test diagnostics, and appended as JSON lines to $AIGENT_LIVE_REPORT if set.

import assert from 'node:assert/strict'
import { appendFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { test } from 'node:test'
import { createSession, type SessionEvent, type ToolMode, type Transcript } from '../src/index.ts'
import { makeWeather, units } from './fixtures/plugins.ts'

const envFile = join(import.meta.dirname, '..', '.env')
if (existsSync(envFile)) process.loadEnvFile(envFile)
const key = process.env.OLLAMA_API_KEY
const models = process.env.AIGENT_LIVE_MODELS?.split(',') ?? ['gpt-oss:120b', 'glm-5.3', 'kimi-k2.6']
const modes: readonly ToolMode[] = ['native', 'dispatch']

// Invites Fahrenheit without asking for it, against the plugin's "Report temperatures in Celsius."
const PROMPT = "I'm flying to Lisbon from Chicago tomorrow. What's the temperature there right now?"
const CELSIUS = /\b17\s*(°\s*)?C\b|\b17\s*degrees?\s*C|celsius/i
const FAHRENHEIT = /\b6[23](\.\d+)?\s*(°\s*)?F\b|fahrenheit/i

interface Usage {
  readonly input: number
  readonly cacheRead: number
  readonly cacheWrite: number
}

/** Per model request: prompt tokens and the cached share of them. */
function requestUsage(transcript: Transcript, after: number): { promptTokens: number[]; cachedRatios: number[] } {
  const usages = transcript.messages.slice(after).flatMap((m) => {
    const message = m as { role?: string; usage?: Usage }
    return message.role === 'assistant' && message.usage ? [message.usage] : []
  })
  const prompts = usages.map((u) => u.input + u.cacheRead + u.cacheWrite)
  return { promptTokens: prompts, cachedRatios: usages.map((u, i) => (prompts[i]! > 0 ? Math.round((u.cacheRead / prompts[i]!) * 100) / 100 : 0)) }
}

const enabledRecords = (transcript: Transcript) =>
  transcript.messages.flatMap((m) => {
    const message = m as { role?: string; record?: { kind?: string; plugin?: string; cause?: unknown } }
    return message.role === 'aigent' && message.record?.kind === 'enabled' ? [message.record] : []
  })

const calledWeatherFor = (events: readonly SessionEvent[], city: RegExp) =>
  events.some((e) => e.type === 'tool_end' && e.result.call.name === 'weather__get_weather' && city.test(String(e.result.call.args.city)) && e.result.outcome.kind === 'ran')

for (const model of models) {
  for (const toolMode of modes) {
    test(`live: ${model} in ${toolMode} mode`, { skip: !key && 'OLLAMA_API_KEY not set', timeout: 600_000 }, async (t) => {
      const base = {
        model: { kind: 'openai-compatible', baseUrl: 'https://ollama.com/v1', id: model, apiKeyEnv: 'OLLAMA_API_KEY' },
        plugins: [units, makeWeather({ echo: key }).plugin],
        toolMode,
        maxTurns: 8,
      } as const

      const session = await createSession({ ...base, systemPrompt: 'You are a helpful assistant. Enable a plugin when you need a capability you lack.' })
      const events: SessionEvent[] = []
      session.subscribe((e) => events.push(e))
      const result = await session.prompt(PROMPT, { signal: AbortSignal.timeout(240_000) })
      const saved: Transcript = JSON.parse(JSON.stringify(session.transcript()))
      await session.close()
      const answer = result.stop === 'done' || result.stop === 'max_turns' ? result.text : ''

      const resumed = await createSession({ ...base, transcript: saved })
      const resumedEvents: SessionEvent[] = []
      resumed.subscribe((e) => resumedEvents.push(e))
      const resumedResult = await resumed.prompt('And what about Porto?', { signal: AbortSignal.timeout(240_000) })
      const after: Transcript = JSON.parse(JSON.stringify(resumed.transcript()))
      await resumed.close()

      const metrics = {
        model,
        toolMode,
        stop: result.stop,
        ...(result.stop === 'error' ? { error: result.message } : {}),
        toolCallCorrect: calledWeatherFor(events, /lisbon/i),
        celsius: CELSIUS.test(answer),
        fahrenheit: FAHRENHEIT.test(answer),
        ...requestUsage(saved, 0),
        resumeStop: resumedResult.stop,
        resumeToolCallCorrect: calledWeatherFor(resumedEvents, /porto/i),
        resume: requestUsage(after, saved.messages.length),
        answer: answer.slice(0, 300),
      }
      t.diagnostic(JSON.stringify(metrics))
      if (process.env.AIGENT_LIVE_REPORT) appendFileSync(process.env.AIGENT_LIVE_REPORT, `${JSON.stringify(metrics)}\n`)

      const everything = JSON.stringify([saved, after, events, resumedEvents, result, resumedResult])
      assert.ok(!everything.includes(key!), 'the API key never leaves the engine unredacted')
      if (metrics.toolCallCorrect) assert.ok(JSON.stringify(saved).includes('[REDACTED:OLLAMA_API_KEY]'), 'the echoed key was redacted, not dropped')
      if (events.some((e) => e.type === 'tool_end' && e.result.call.name === 'weather__get_weather')) {
        assert.ok(enabledRecords(saved).some((r) => r.plugin === 'weather'), 'a weather call implies a weather enable record')
      }
      assert.deepEqual(enabledRecords(after), enabledRecords(saved), 'resume neither re-enables nor loses a plugin')
    })
  }
}
