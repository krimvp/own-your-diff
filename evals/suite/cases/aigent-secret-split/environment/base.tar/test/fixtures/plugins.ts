// Plugins written the way an author would, importing only types from the plugin API. The counters let tests
// prove what ran.

import type { Plugin, ToolResult } from '../../src/plugin.ts'

const text = (s: string): ToolResult => ({ content: [{ type: 'text', text: s }] })

export const units: Plugin = {
  name: 'units',
  description: 'Temperature unit conversions.',
  tools: [
    {
      name: 'c_to_f',
      description: 'Convert Celsius to Fahrenheit.',
      parameters: { type: 'object', properties: { celsius: { type: 'number' } }, required: ['celsius'], additionalProperties: false },
      execute: async (args) => text(String((Number(args.celsius) * 9) / 5 + 32)),
    },
  ],
}

export function makeWeather(options: { readonly echo?: string } = {}) {
  const calls = { onEnable: 0, getWeather: 0 }
  const plugin: Plugin = {
    name: 'weather',
    description: 'Current weather lookups for any city.',
    dependsOn: ['units'],
    instructions: 'Report temperatures in Celsius.',
    tools: [
      {
        name: 'get_weather',
        description: 'Current weather for a city.',
        parameters: { type: 'object', properties: { city: { type: 'string' } }, required: ['city'], additionalProperties: false },
        execute: async (args) => {
          calls.getWeather++
          return text(`${String(args.city)}: 17C, light rain.${options.echo ? ` debug=${options.echo}` : ''}`)
        },
      },
    ],
    skills: [{ name: 'forecasting', description: 'How to read a multi-day forecast.', load: () => 'Read the trend, not the single day.' }],
    hooks: {
      onEnable: () => {
        calls.onEnable++
        return 'Weather data refreshes every 10 minutes.'
      },
    },
  }
  return { plugin, calls }
}

export const guard: Plugin = {
  name: 'guard',
  description: 'Blocks weather lookups for restricted cities.',
  hooks: {
    beforeToolCall: (call) => (call.name === 'weather__get_weather' && call.args.city === 'Atlantis' ? { deny: 'Atlantis is restricted' } : 'allow'),
  },
}
