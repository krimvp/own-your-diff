import assert from 'node:assert/strict'
import { readdir, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { test } from 'node:test'

const ROOT = join(import.meta.dirname, '..')
// The adapter's own offline test drives pi's faux provider, so it is the one test allowed across the line.
const PI_IMPORTERS = new Set(['src/pi.ts', 'test/pi.test.ts'])
const ADAPTER_IMPORTERS = new Set(['src/index.ts', 'test/pi.test.ts'])

test('only the adapter imports @earendil-works packages', async () => {
  const offenders: string[] = []
  for (const file of await sourceFiles()) {
    if (PI_IMPORTERS.has(file)) continue
    if ((await specifiers(file)).some((s) => s.startsWith('@earendil-works/'))) offenders.push(file)
  }
  assert.deepEqual(offenders, [], 'files outside the adapter import pi')
  assert.ok((await specifiers('src/pi.ts')).some((s) => s.startsWith('@earendil-works/')), 'src/pi.ts no longer imports pi; update PI_IMPORTERS so this test still guards the boundary')
})

test('nothing but the host entry imports the adapter', async () => {
  const offenders: string[] = []
  for (const file of await sourceFiles()) {
    if (ADAPTER_IMPORTERS.has(file)) continue
    if ((await specifiers(file)).some((s) => /(^|\/)pi(\.ts)?$/.test(s))) offenders.push(file)
  }
  assert.deepEqual(offenders, [], 'the engine core and plugin API must not reach pi through the adapter')
})

async function sourceFiles(): Promise<readonly string[]> {
  const files: string[] = []
  for (const dir of ['src', 'test']) {
    const names = await readdir(join(ROOT, dir), { recursive: true }).catch((error: NodeJS.ErrnoException) => {
      if (error.code === 'ENOENT') return []
      throw error
    })
    files.push(...names.filter((name) => name.endsWith('.ts')).map((name) => `${dir}/${name.split('\\').join('/')}`))
  }
  return files
}

/** Static `import`/`export … from`, side-effect `import '…'`, and dynamic `import('…')` specifiers. */
async function specifiers(file: string): Promise<readonly string[]> {
  const source = await readFile(join(ROOT, file), 'utf8')
  return [...source.matchAll(/(?:\bfrom\s*|\bimport\s*\(?\s*)['"]([^'"]+)['"]/g)].map((m) => m[1]!)
}
