import assert from 'node:assert/strict'
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { CatalogError, loadPlugins, parseCatalog } from '../src/catalog.ts'
import type { Plugin, Tool } from '../src/plugin.ts'

const tool = (name: string): Tool => ({
  name,
  description: 'A tool.',
  parameters: { type: 'object', properties: {} },
  execute: async () => ({ content: [] }),
})
const plugin = (name: string, extra: Partial<Plugin> = {}): Plugin => ({ name, description: `The ${name} plugin.`, ...extra })

const rejected: readonly (readonly [string, readonly Plugin[], RegExp])[] = [
  ['a name outside [a-z0-9-]', [plugin('Weather')], /name must match/],
  ['the reserved core name', [plugin('core')], /"core" is reserved/],
  ['a multi-line description', [plugin('weather', { description: 'one\ntwo' })], /description must be one non-empty line/],
  ['two plugins with one name', [plugin('weather'), plugin('weather')], /"weather" is defined twice/],
  ['two tools with one name', [plugin('weather', { tools: [tool('get'), tool('get')] })], /tool "get" is defined twice/],
  ['an exposed tool name over 64 characters', [plugin('weather', { tools: [tool('x'.repeat(60))] })], /longer than 64/],
  ['parameters without an object root', [plugin('weather', { tools: [{ ...tool('get'), parameters: { type: 'string' } as never }] })], /parameters must be a JSON Schema/],
  ['an unknown dependency', [plugin('weather', { dependsOn: ['geo'] })], /"weather" depends on unknown plugin "geo"/],
  ['a self dependency', [plugin('weather', { dependsOn: ['weather'] })], /"weather" depends on itself/],
  ['a dependency cycle', [plugin('a', { dependsOn: ['b'] }), plugin('b', { dependsOn: ['a'] })], /cycle: a -> b -> a/],
  ['a misspelled hook', [plugin('weather', { hooks: { beforeToolcall: () => 'allow' } as never })], /unknown hook "beforeToolcall"/],
]

for (const [label, plugins, problem] of rejected) {
  test(`parseCatalog rejects ${label}`, () => {
    assert.throws(
      () => parseCatalog(plugins),
      (error) => error instanceof CatalogError && error.problems.some((p) => problem.test(p)),
    )
  })
}

test('parseCatalog accepts a coherent set and reports every problem of an incoherent one', () => {
  const coherent = [plugin('geo', { tools: [tool('locate')] }), plugin('weather', { dependsOn: ['geo'], tools: [tool('get')] })]
  assert.doesNotThrow(() => parseCatalog(coherent))
  assert.throws(
    () => parseCatalog([plugin('Bad'), plugin('weather', { dependsOn: ['nowhere'] })]),
    (error) => error instanceof CatalogError && error.problems.length === 2,
  )
})

test('loadPlugins imports plugin files and folders in name order and names a file with a bad export', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'aigent-plugins-'))
  try {
    await writeFile(join(dir, 'b.mjs'), `export default { name: 'beta', description: 'Second.' }\n`)
    await mkdir(join(dir, 'a'))
    await writeFile(join(dir, 'a', 'index.ts'), `export default { name: 'alpha', description: 'First.' }\n`)
    await writeFile(join(dir, 'README.md'), 'not a plugin\n')
    assert.deepEqual((await loadPlugins(dir)).map((p) => p.name), ['alpha', 'beta'])

    await writeFile(join(dir, 'c.mjs'), `export default 42\n`)
    await assert.rejects(loadPlugins(dir), (error) => error instanceof CatalogError && error.problems.some((p) => p.includes('c.mjs')))
  } finally {
    await rm(dir, { recursive: true, force: true })
  }
})
