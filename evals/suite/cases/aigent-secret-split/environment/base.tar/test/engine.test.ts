// Plugins through a scripted fake loop with no pi: the Engine port is the whole loop contract.

import assert from 'node:assert/strict'
import { test } from 'node:test'
import { setTimeout as sleep } from 'node:timers/promises'
import { parseCatalog } from '../src/catalog.ts'
import { createEngine, type Engine, type EngineOptions, type Validate } from '../src/engine.ts'
import type { JsonObject, Plugin, ToolResult } from '../src/plugin.ts'
import type { EngineRecord, RunResult, ToolMode } from '../src/session.ts'
import { guard, makeWeather, units } from './fixtures/plugins.ts'

/** A small stand-in for the loop's schema validator: required keys, primitive types, closed objects. */
const validate: Validate = (schema, args) => {
  const properties = (schema.properties ?? {}) as Record<string, { type?: string }>
  for (const key of (schema.required ?? []) as string[]) if (!(key in args)) return { ok: false, error: `missing "${key}"` }
  for (const [key, value] of Object.entries(args)) {
    const type = properties[key]?.type
    if (!type && schema.additionalProperties === false) return { ok: false, error: `unexpected "${key}"` }
    if (type && typeof value !== type) return { ok: false, error: `"${key}" must be a ${type}` }
  }
  return { ok: true, args }
}

interface Setup {
  readonly mode?: ToolMode
  readonly enabled?: readonly string[]
  readonly resume?: readonly EngineRecord[]
  readonly secrets?: Readonly<Record<string, string>>
  readonly maxTurns?: number
}

function engineWith(plugins: readonly Plugin[], setup: Setup = {}): Promise<Engine> {
  const options: EngineOptions = {
    catalog: parseCatalog(plugins),
    toolMode: setup.mode ?? 'native',
    start: setup.resume ? { kind: 'resume', records: setup.resume } : { kind: 'fresh', systemPrompt: 'You are a test agent.' },
    enabled: setup.enabled ?? [],
    secrets: setup.secrets ?? {},
    maxTurns: setup.maxTurns ?? 10,
    hookTimeoutMs: 50,
    validate,
    emit: () => {},
    log: () => {},
  }
  return createEngine(options)
}

type Reply = { readonly text?: string; readonly calls?: readonly { readonly name: string; readonly args: JsonObject }[] }

interface FakeRun {
  readonly user: string
  /** Tool names declared on each model request. */
  readonly requests: readonly (readonly string[])[]
  readonly results: readonly ToolResult[]
  readonly records: readonly EngineRecord[]
  readonly result: RunResult
}

/** The smallest native loop: the model may only call what was declared on that request. */
async function runFakeLoop(engine: Engine, prompt: string, script: readonly Reply[], signal = new AbortController().signal): Promise<FakeRun> {
  const user = await engine.beginPrompt(prompt, signal)
  const requests: string[][] = []
  const results: ToolResult[] = []
  const records = [...engine.takeRecords()]
  for (const [i, reply] of script.entries()) {
    const declared = engine.tools().map((t) => t.name as string)
    requests.push(declared)
    const calls = reply.calls ?? []
    for (const call of calls) assert.ok(declared.includes(call.name), `${call.name} is declared on request ${i + 1}`)
    results.push(...(await Promise.all(calls.map((call, j) => engine.callTool({ id: `call-${i}-${j}`, ...call }, signal)))))
    const decision = await engine.endTurn({ kind: 'ok', text: reply.text ?? '' })
    records.push(...engine.takeRecords())
    if (decision === 'stop' || calls.length === 0) break
  }
  return { user, requests, results, records, result: engine.endRun() }
}

const textOf = (result: ToolResult | undefined): string => (result?.content ?? []).map((c) => (c.type === 'text' ? c.text : '')).join('')
const call = (name: string, args: JsonObject): Reply => ({ calls: [{ name, args }] })
const enableWeather = call('core__enable_plugin', { name: 'weather' })

test('a plugin the model enables is declared, dependencies first, on the next request, with its text in the result', async () => {
  const weather = makeWeather()
  const engine = await engineWith([units, weather.plugin])

  const run = await runFakeLoop(engine, 'Weather in Lisbon?', [enableWeather, call('weather__get_weather', { city: 'Lisbon' }), { text: 'It is 17C.' }])

  assert.deepEqual(run.requests[0], ['core__enable_plugin', 'core__load_skill'])
  assert.deepEqual(run.requests[1], ['core__enable_plugin', 'core__load_skill', 'units__c_to_f', 'weather__get_weather'])
  assert.deepEqual(
    run.records.filter((r) => r.kind === 'enabled'),
    [
      { kind: 'enabled', plugin: 'units', cause: { dependencyOf: 'weather' } },
      { kind: 'enabled', plugin: 'weather', cause: 'model' },
    ],
  )
  assert.match(textOf(run.results[0]), /<plugin name="units">[\s\S]*<plugin name="weather">[\s\S]*Report temperatures in Celsius[\s\S]*refreshes every 10 minutes[\s\S]*weather__forecasting/)
  assert.equal(textOf(run.results[1]), 'Lisbon: 17C, light rain.')
  assert.deepEqual(run.result, { stop: 'done', text: 'It is 17C.', turns: 3 })
})

test('dispatch mode keeps the declared tools fixed and runs late tools through core__call_tool', async () => {
  const weather = makeWeather()
  const engine = await engineWith([units, weather.plugin, guard], { mode: 'dispatch', enabled: ['units', 'guard'] })

  const run = await runFakeLoop(engine, 'Weather?', [
    enableWeather,
    call('core__call_tool', { tool: 'weather__get_weather', args: { city: 'Lisbon' } }),
    call('core__call_tool', { tool: 'weather__get_weather', args: { city: 'Atlantis' } }),
    { text: 'done' },
  ])

  const fixed = ['core__enable_plugin', 'core__load_skill', 'core__call_tool', 'units__c_to_f']
  assert.deepEqual(run.requests, [fixed, fixed, fixed, fixed])
  assert.match(textOf(run.results[0]), /weather__get_weather: Current weather for a city\.\n {2}Parameters: \{"type":"object"/)
  assert.equal(textOf(run.results[1]), 'Lisbon: 17C, light rain.')
  assert.equal(run.results[2]?.isError, true)
  assert.deepEqual(
    run.records.filter((r) => r.kind === 'denied').map((r) => r.kind === 'denied' && [r.tool, r.plugin]),
    [['weather__get_weather', 'guard']],
  )
  assert.equal(weather.calls.getWeather, 1)
})

test('dispatch mode rejects arguments that fail the target schema, showing the schema, without running the tool', async () => {
  const weather = makeWeather()
  const engine = await engineWith([units, weather.plugin], { mode: 'dispatch', enabled: ['weather'] })

  const run = await runFakeLoop(engine, 'Weather?', [call('core__call_tool', { tool: 'weather__get_weather', args: { town: 'Lisbon' } }), { text: 'sorry' }])

  assert.equal(run.results[0]?.isError, true)
  assert.match(textOf(run.results[0]), /weather__get_weather[\s\S]*Parameters: \{"type":"object","properties":\{"city"/)
  assert.equal(weather.calls.getWeather, 0)
})

test('a denying gate blocks any tool, core tools included, and the denial names its plugin', async () => {
  const weather = makeWeather()
  const coreGuard: Plugin = {
    name: 'core-guard',
    description: 'Forbids enabling plugins.',
    hooks: { beforeToolCall: (c) => (c.name === 'core__enable_plugin' ? { deny: 'no new plugins' } : 'allow') },
  }
  const engine = await engineWith([units, weather.plugin, guard, coreGuard], { enabled: ['weather', 'guard', 'core-guard'] })

  const run = await runFakeLoop(engine, 'Atlantis?', [call('weather__get_weather', { city: 'Atlantis' }), call('core__enable_plugin', { name: 'units' }), { text: 'no' }])

  assert.match(textOf(run.results[0]), /guard: Atlantis is restricted/)
  assert.equal(weather.calls.getWeather, 0)
  assert.deepEqual(
    run.records.flatMap((r) => (r.kind === 'denied' ? [[r.plugin, r.tool, r.reason]] : [])),
    [
      ['guard', 'weather__get_weather', 'Atlantis is restricted'],
      ['core-guard', 'core__enable_plugin', 'no new plugins'],
    ],
  )
})

const brokenGates: readonly (readonly [string, Plugin['hooks'], RegExp])[] = [
  ['throws', { beforeToolCall: () => { throw new Error('boom') } }, /gate failed: boom/],
  ['never settles', { beforeToolCall: () => new Promise(() => {}) }, /timed out after 50ms/],
  ['returns no verdict', { beforeToolCall: () => 'yes' as never }, /no verdict/],
]

for (const [label, hooks, reason] of brokenGates) {
  test(`a gate that ${label} denies`, async () => {
    const weather = makeWeather()
    const broken: Plugin = { name: 'broken', description: 'A broken gate.', hooks }
    const engine = await engineWith([units, weather.plugin, broken], { enabled: ['weather', 'broken'] })

    const run = await runFakeLoop(engine, 'Weather?', [call('weather__get_weather', { city: 'Lisbon' }), { text: 'no' }])

    assert.equal(run.results[0]?.isError, true)
    assert.equal(weather.calls.getWeather, 0)
    const denial = run.records.find((r) => r.kind === 'denied')
    assert.ok(denial?.kind === 'denied' && denial.plugin === 'broken' && reason.test(denial.reason), JSON.stringify(denial))
  })
}

test('a host enable racing a model enable of the same plugin enables it once', async () => {
  const weather = makeWeather()
  const engine = await engineWith([units, weather.plugin])
  const signal = new AbortController().signal
  await engine.beginPrompt('go', signal)

  const [, modelResult] = await Promise.all([
    engine.enable('weather'),
    engine.callTool({ id: 'c1', name: 'core__enable_plugin', args: { name: 'weather' } }, signal),
  ])

  assert.equal(textOf(modelResult), 'weather is already enabled.')
  assert.deepEqual(engine.takeRecords().flatMap((r) => (r.kind === 'enabled' ? [r.plugin] : [])), ['units', 'weather'])
  assert.equal(weather.calls.onEnable, 1)
})

test('added text lands in enable order whatever order the hooks settle in', async () => {
  const slow: Plugin = {
    name: 'slow',
    description: 'Settles late.',
    hooks: { onEnable: () => sleep(30, 'slow enable'), onUserPrompt: () => sleep(30, 'slow prompt') },
  }
  const fast: Plugin = { name: 'fast', description: 'Settles at once.', hooks: { onEnable: () => 'fast enable', onUserPrompt: () => 'fast prompt' } }
  const engine = await engineWith([slow, fast])

  await Promise.all([engine.enable('slow'), engine.enable('fast')])
  const user = await engine.beginPrompt('Hello.', new AbortController().signal)

  const order = ['Hello.', 'slow enable', 'fast enable', 'slow prompt', 'fast prompt'].map((s) => user.indexOf(s))
  assert.ok(order.every((at, i) => at >= 0 && (i === 0 || at > order[i - 1]!)), user)
})

test('resume rebuilds the enabled set from the records without rerunning onEnable', async () => {
  const first = makeWeather()
  const original = await runFakeLoop(await engineWith([units, first.plugin]), 'Weather?', [enableWeather, { text: 'ok' }])

  const second = makeWeather()
  const resumed = await engineWith([units, second.plugin], { resume: original.records })

  assert.ok(resumed.tools().some((t) => t.name === 'weather__get_weather'))
  assert.equal(second.calls.onEnable, 0)
  assert.deepEqual(resumed.takeRecords(), [])
  assert.equal(await resumed.beginPrompt('And in Porto?', new AbortController().signal), 'And in Porto?')
})

test('text from a host enable made while idle reaches the next prompt of a resumed session once, without rerunning onEnable', async () => {
  const first = makeWeather()
  const original = await engineWith([units, first.plugin], { mode: 'dispatch' })
  await original.enable('weather')
  const saved = original.takeRecords()
  const signal = new AbortController().signal

  const second = makeWeather()
  const resumed = await engineWith([units, second.plugin], { mode: 'dispatch', resume: saved })
  const user = await resumed.beginPrompt('Weather in Lisbon?', signal)
  const again = await engineWith([units, makeWeather().plugin], { mode: 'dispatch', resume: [...saved, ...resumed.takeRecords()] })

  assert.match(user, /^Weather in Lisbon\?\n\n<plugin name="units">[\s\S]*<plugin name="weather">[\s\S]*Weather data refreshes every 10 minutes\.[\s\S]*weather__get_weather: Current weather for a city\.\n {2}Parameters: /)
  assert.equal(first.calls.onEnable, 1)
  assert.equal(second.calls.onEnable, 0)
  assert.equal(await again.beginPrompt('And in Porto?', signal), 'And in Porto?')
})

test('resume tells the model about a changed plugin set once, with the next prompt', async () => {
  const original = await engineWith([units])
  const records = original.takeRecords()
  const extra: Plugin = { name: 'extra', description: 'Added by the host later.' }
  const resumed = await engineWith([units, extra], { resume: records })
  const signal = new AbortController().signal

  const first = await resumed.beginPrompt('Hi.', signal)
  const written = resumed.takeRecords()
  const second = await resumed.beginPrompt('Again.', signal)

  assert.match(first, /^Hi\.\n\n<plugin-catalog>[\s\S]*- extra: Added by the host later\./)
  assert.deepEqual(written.map((r) => r.kind), ['catalog'])
  assert.equal(second, 'Again.')
})

test('secrets are redacted from prompts, tool results and denials, longest value first', async () => {
  const key = 'sk-live-0123456789'
  const weather = makeWeather({ echo: key })
  const leaky: Plugin = { name: 'leaky', description: 'Leaks into denials.', hooks: { beforeToolCall: (c) => (c.args.city === 'Oslo' ? { deny: `token ${key} expired` } : 'allow') } }
  const engine = await engineWith([units, weather.plugin, leaky], { enabled: ['weather', 'leaky'], secrets: { PREFIX: 'sk-live', STATION_KEY: key } })

  const run = await runFakeLoop(engine, `My key is ${key}.`, [call('weather__get_weather', { city: 'Lisbon' }), call('weather__get_weather', { city: 'Oslo' }), { text: 'ok' }])

  assert.equal(run.user, 'My key is [REDACTED:STATION_KEY].')
  assert.equal(textOf(run.results[0]), 'Lisbon: 17C, light rain. debug=[REDACTED:STATION_KEY]')
  assert.match(textOf(run.results[1]), /token \[REDACTED:STATION_KEY\] expired/)
  assert.ok(!JSON.stringify(run).includes('sk-live'), 'no secret fragment survives')
})

test('the run stops at max turns while the model keeps calling tools', async () => {
  const engine = await engineWith([units], { enabled: ['units'], maxTurns: 2 })
  const convert = call('units__c_to_f', { celsius: 17 })

  const run = await runFakeLoop(engine, 'Convert forever.', [convert, convert, convert, convert])

  assert.equal(run.requests.length, 2)
  assert.equal(run.result.stop, 'max_turns')
})

test('an abort wins over max turns reached on the same turn', async () => {
  const engine = await engineWith([units], { enabled: ['units'], maxTurns: 1 })
  const controller = new AbortController()
  controller.abort()

  const run = await runFakeLoop(engine, 'Convert.', [call('units__c_to_f', { celsius: 17 })], controller.signal)

  assert.deepEqual(run.result, { stop: 'aborted', turns: 1 })
})

// Compile-time pins, checked by `tsc --noEmit`: hooks cannot modify what they are shown.
export const forbidden: Plugin[] = [
  // @ts-expect-error a gate cannot return rewritten arguments
  { name: 'a', description: 'a', hooks: { beforeToolCall: (c) => ({ ...c.args, city: 'Paris' }) } },
  // @ts-expect-error snapshots are read-only
  { name: 'b', description: 'b', hooks: { beforeToolCall: (c) => ((c.args.city = 'Paris'), 'allow') } },
  // @ts-expect-error an add hook returns text, not a replacement prompt
  { name: 'c', description: 'c', hooks: { onUserPrompt: () => ({ text: 'replaced' }) } },
  // @ts-expect-error a tool result cannot be swapped by an observer
  { name: 'd', description: 'd', hooks: { onToolResult: (e) => { e.outcome = { kind: 'denied', denials: [] } } } },
]
