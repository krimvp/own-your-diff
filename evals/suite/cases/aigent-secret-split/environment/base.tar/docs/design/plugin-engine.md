# Plugin engine v1

## Problem

aigent is a small agent engine whose only extension point is the plugin. A plugin has a name, a one-line description, tools, skills and hooks. Plugins are enabled mid-conversation by the model or the host, and are usable from the next model request. The engine must work with any model, including open-weight models on Ollama Cloud. The agent loop and model access come from pi (`@earendil-works/pi-agent-core` and `pi-ai` 1.3.0), but plugins and the engine core never import pi.

Two measured facts shape the design.

- Adding a tool to the request's tool list drops the Ollama Cloud prompt cache to 0-5% on gpt-oss:120b and glm-5.3. Appending the same tool schema as a message at the end keeps 98% cached. Editing the system prompt or inserting a message mid-history recomputes everything after the edit point. Probe: a 2.6k-token conversation, one change per request, two runs per model.
- pi records tool declarations as transcript system messages. When tools change in `prepareRequest`, that record lands one request late. `prepareNextTurnWithContext` runs before pi declares tool changes, so tool swaps go there.

## Settled decisions

1. TypeScript, Node >= 22.19, ESM, `node --test` with type stripping, `tsc --noEmit` strict, npm, minimal dependencies.
2. Only `src/pi.ts` imports `@earendil-works/*`. A test fails the build otherwise.
3. Tool parameters are plain JSON Schema. Tool results are our own `{ content, isError? }`.
4. Tools are exposed as `<plugin>__<tool>`. Plugin names match `[a-z0-9-]+`. `core` is reserved. Collisions fail.
5. Enable-only. Model and host can both enable. Plugins come from a trusted local directory or host objects.
6. `dependsOn` names only. Dependencies enable first. Cycles and unknown names fail at session creation.
7. Hooks observe, add, or gate. They never modify. Gates apply to every tool, including core tools. Any deny wins. A throw or timeout denies. Denials are recorded with the plugin.
8. Redaction and stop conditions are core-owned internal lists. Plugins cannot add to them in v1.

## Usage

```ts
// plugins/weather.ts
import type { Plugin } from 'aigent/plugin'

export default {
  name: 'weather',
  description: 'Current weather lookups for any city.',
  instructions: 'Report temperatures in Celsius.',
  tools: [{
    name: 'get_weather',
    description: 'Current weather for a city.',
    parameters: { type: 'object', properties: { city: { type: 'string' } }, required: ['city'], additionalProperties: false },
    async execute({ city }, signal) { return { content: [{ type: 'text', text: await lookup(city, signal) }] } },
  }],
  hooks: {
    beforeToolCall: (call) => call.name === 'shell__run' && String(call.args.cmd).includes('rm -rf') ? { deny: 'destructive command' } : 'allow',
  },
} satisfies Plugin
```

```ts
// host
import { createSession, loadPlugins } from 'aigent'

const options = {
  model: { kind: 'openai-compatible', baseUrl: 'https://ollama.com/v1', id: 'gpt-oss:120b', apiKeyEnv: 'OLLAMA_API_KEY' },
  plugins: await loadPlugins(new URL('./plugins/', import.meta.url)),
  enabled: ['files'],
  toolMode: 'dispatch',
  secrets: { GITHUB_TOKEN: process.env.GITHUB_TOKEN! },
} as const

const session = await createSession({ ...options, systemPrompt: 'You are a helpful agent.' })
session.subscribe((e) => { if (e.type === 'text') process.stdout.write(e.delta) })
await session.enable('weather')
const result = await session.prompt('Weather in Lisbon?', { signal: AbortSignal.timeout(60_000) })
await writeFile('session.json', JSON.stringify(session.transcript()))

const resumed = await createSession({ ...options, transcript: JSON.parse(await readFile('session.json', 'utf8')) })
```

The host surface is `createSession`, `loadPlugins`, and a `Session` with `prompt`, `enable`, `subscribe`, `transcript` and `close`.

## Shape

### Modules

| Path | Owns |
|---|---|
| `src/plugin.ts` | Plugin-author vocabulary, types only: `Plugin`, `Tool`, `ToolResult`, `Content`, `Skill`, `Hooks`, `GateVerdict`, snapshots, readonly JSON types. Published as `aigent/plugin`. |
| `src/session.ts` | Host vocabulary, types only: `SessionOptions`, `Session`, `SessionEvent`, `RunResult`, `ModelSpec`, `ToolMode`, `Transcript`. |
| `src/catalog.ts` | `parseCatalog` (the only plugin validation, dependency closures, cycles, collisions, brands) and `loadPlugins(dir)`. |
| `src/engine.ts` | `createEngine`: the record log, everything derived from it, the core plugin, enable, `callTool`, gates, redaction, stop conditions, run outcome, resume. The port any loop drives. |
| `src/pi.ts` | The only pi importer. `createSession` binds the engine port to pi's `Agent`, resolves models, maps records into pi's transcript. |
| `src/index.ts` | Host entry. The only module that imports `src/pi.ts`. |

A tool call traces through three files: `pi.ts` (execute), `engine.ts` (`callTool`), the plugin.

### State: one append-only record log

The engine's only state is `log: EngineRecord[]`. The enabled set, active plugins in enable order, the tool table, hook order, skill lookup, catalog text and enable text still owed to the model are derived from it on each call. Nothing else stores them. The log entries ride in pi's transcript as a custom message (`role: 'aigent'`) that `convertToLlm` filters out. Resume parses them back, so the transcript and the engine agree by construction.

```ts
type EngineRecord =
  | { kind: 'enabled'; plugin: PluginName; cause: 'initial' | 'host' | 'model' | { dependencyOf: PluginName } }
  | { kind: 'denied'; callId: string; tool: ToolName; plugin: PluginName; reason: string }
  | { kind: 'catalog'; fingerprint: string }  // what the model was last told; drives resume drift detection
  | { kind: 'pending'; text: string }  // redacted host-enable text for the next user message
  | { kind: 'delivered' }  // that user message carried every pending text before it
```

Enabling commits the `enabled` records synchronously before the first `await`, so racing enables see the plugin as enabled and do nothing. The hook phase (`onEnable`) runs through one promise chain, so added text lands in enable order. Keep the derived views cheap: index records by kind as they are appended rather than scanning the whole log per call.

### Tool modes

`toolMode: 'native' | 'dispatch'` on `SessionOptions`. The mode only changes what `tools()` declares and what enable text contains. Plugins, hooks, gates and redaction are identical in both modes, because `callTool` always resolves to the real `<plugin>__<tool>` name before gates run.

- **native**: active tools are declared with their real schemas. Each enable changes the declared tool list, which costs one full cache miss.
- **dispatch**: the declared list is fixed for the session: `core__enable_plugin`, `core__load_skill`, `core__call_tool { tool, args }`, plus the native tools of plugins enabled with cause `initial` (they are in the first request anyway). Plugins enabled later are reached through `core__call_tool`; their schemas arrive in the enable text. The engine unwraps `core__call_tool`, validates `args` against the target schema with a validator the loop injects (the adapter passes pi-ai's `validateToolArguments`, keeping the engine pi-free), and on failure returns an error result that includes the schema. Gates see the unwrapped call.

The default mode is decided by the live comparison (see Verification). Until then it is `native`.

### What the model sees: append-only

Model-facing text never edits earlier content, and never creates standalone context messages (no user message after a tool result, no consecutive user messages).

- **Initial system prompt**: host `systemPrompt`, then the catalog (one line per plugin not enabled at start), then the standing text of `initial` plugins. Built with pi's own initial-system-message construction so tool declarations serialize exactly as pi expects.
- **Model enable**: the `core__enable_plugin` tool result carries, for each newly enabled plugin in order: instructions, `onEnable` text, skill names and descriptions, and in dispatch mode the tool schemas. In native mode it lists the new tool names.
- **Host enable**: the same text is written as a `pending` record and attached to the next user message, after the prompt text, which writes `delivered`. A transcript saved in between still owes the text, so a resumed session delivers it without rerunning `onEnable`.
- **onUserPrompt**: added to the user message content after the prompt, in plugin enable order.
- **Catalog**: static in the system prompt. Enabling an enabled plugin returns "already enabled". On resume, if the derived catalog differs from the last `catalog` record (plugins added or removed by the host), the new catalog is attached to the next user message and a new `catalog` record is written.
- **Denials**: the model sees the error tool result with the reason. The `denied` record is for the host and resume, and maps to nothing in the LLM view.

Whether tool-result instructions are followed as well as system-prompt instructions is checked by the live test's Celsius probe. If they are not, the fallback is folding standing text into the system prompt in native mode only, where the enable already costs a full re-prefill.

### Hooks

Return types are the whole capability. `GateVerdict = 'allow' | { deny: string }`. Add hooks return `string | undefined`. Observers return `void`. Every hook gets a deep-frozen snapshot and an `AbortSignal` that fires on timeout or session close. A gate that throws, times out or returns a non-verdict denies. Other hooks that fail are logged and ignored. Results are collected in enable order regardless of settle order. `@ts-expect-error` cases in the tests pin that forbidden operations do not compile.

### Redaction

Known secret values (host `secrets` plus the model API key) become `[REDACTED:<NAME>]`, longest first. The engine redacts what enters the conversation: prompts, added text, instructions, skill bodies, tool results, tool errors, denial reasons, the system prompt. The adapter redacts what leaves the process: `transcript()`, events, logs, `RunResult` errors and pi's provider `errorMessage`. Export redaction touches text fields only, never opaque provider fields such as thinking signatures.

### Stop conditions and run outcome

An internal list `[aborted, maxTurns]`, abort first, checked after each turn and wired to pi's `finishTurn`. The run outcome is a pure engine function over a `Turn` sum type (`ok`, `error`, `aborted`). `RunResult` is a sum type: `done`, `max_turns`, `aborted`, `error`.

### Host contract

`SessionOptions` takes either `systemPrompt` (fresh) or `transcript` (resume), never both, because pi ignores the system prompt when the transcript already starts with one. `Transcript = { format: 'aigent-transcript/1', messages }`. A concurrent `prompt` rejects. `ModelSpec` covers pi's built-in providers and any OpenAI-compatible endpoint.

## Synthesis decision

Arena with two candidates and an independent cross-judge. Scores tied (25 each). Base: candidate 1, because its record log is the only state and everything else derives from it. Candidate 2 kept a live enabled array beside a record queue and froze derivable catalog text into records, which is structural and hard to remove later.

Grafted from candidate 2: the split between `plugin.ts` and `session.ts`, the host contract (transcript format tag, `systemPrompt`/`transcript` union, `Turn` and `RunResult` sum types with the outcome in the engine), the boundary test that parses import specifiers and asserts the adapter still imports pi and only `index.ts` imports the adapter, fixture counters that prove what ran, and hook-phase serialization through one promise chain.

Fixed from the judge's defect list: stale catalog on resume, out-of-order onEnable text, system prompt silently ignored on resume, a resume test that could not fail, a wrong cost claim, signals missing from non-gate hooks, over-broad export redaction, abort reported as max turns.

Decided against the judge: the judge preferred candidate 2's system-content projection for standing text, reasoning that enabling re-prefills anyway. That holds in native mode only. In dispatch mode tools never change, so folding text into the system prompt would be the only thing breaking the cache. The measured probe makes append-only the rule, carried in tool results and user messages so the judge's template concerns about standalone user messages do not apply.

Added after the arena: tool modes, from the user.

## Tradeoffs accepted

- We accept losing native schemas for late-enabled tools in dispatch mode in exchange for cache hits across enables. Accuracy is measured before a default is picked.
- We accept that a host enable mid-run delivers its text with the next prompt, while its tools are callable from the next request.
- We accept a static catalog that still lists enabled plugins, in exchange for never editing the system prompt.
- We accept a denied call appearing in pi as an executed tool, in exchange for one policy path that the fake loop exercises identically.
- We accept that changing the loop library would need a transcript migration.

## Alternatives considered

- A core `Loop` interface with pi as one implementation: an interface with one implementation, and a Session that forwards to it.
- Gates and redaction in pi's `beforeToolCall`/`afterToolCall`: splits one policy across pi callbacks, so the fake loop proves less.
- Catalog in the `enable_plugin` description: changes a declared tool on every enable.
- Plugin text folded into the system prompt: breaks the cache in dispatch mode.

## Verification

- `test/boundary.test.ts`: only `src/pi.ts` imports pi, the adapter does import it, only `src/index.ts` imports the adapter.
- `test/engine.test.ts`: plugins through a scripted fake loop with no pi. Covers dependency order, enable races, gate denial with attribution, gate timeout denies, resume without rerunning a fixture's `onEnable` (counted), catalog drift on resume, redaction, max turns, abort precedence, dispatch unwrapping and validation errors, `@ts-expect-error` pins.
- `test/pi.test.ts`: the adapter offline against pi's faux provider. The new tool's declaration and the enable text land before the request that uses them, in both modes, and the request prefix only grows in dispatch mode.
- `test/live.test.ts` (skipped without `OLLAMA_API_KEY`): the weather scenario in both modes on gpt-oss:120b, glm-5.3 and kimi-k2.6. Records whether the model called the tool correctly, whether it followed "Report temperatures in Celsius" against a prompt that invites Fahrenheit, cached-token ratios per request, redaction of a key the tool echoes, and resume without re-enabling.

## After v1: evaluation with multeval

[multeval](../../../multeval) evaluates whole agent systems (harness x model x config) against task suites. It runs each attempt in its own Docker container and reports pass rates, tokens, cached tokens and cost. aigent gets measured through a multeval harness adapter, not an aigent plugin. Plugin hooks deliberately see no token usage, and an eval inside the system under test would change what it measures. The transcript already carries per-message usage, including cached tokens.

The adapter lives in this repo, not in multeval. multeval discovers adapters through the Python entry point group `multeval.adapters` in any installed distribution. The adapter mostly depends on aigent's transcript format and CLI, so a format change and its adapter fix land in one commit, and aigent's own tests produce the golden transcripts the adapter converts.

```
integrations/multeval/
  pyproject.toml          # multeval-aigent; entry point aigent = "multeval_aigent.adapter:AigentAdapter"
  multeval_aigent/adapter.py
  CONFORMANCE.md          # what a step is, how skills, enable records and denials map
  tests/                  # golden-file tests over transcripts written by aigent's tests
```

Install beside multeval with `uv pip install -e <aigent>/integrations/multeval`. A multeval subject then names `"harness": "aigent"`.

The adapter implements multeval's `HarnessAdapter` contract:

- `resolve`: freeze the aigent commit, the model id and the tool mode, so a contrast catches drift.
- `image_layer`: Node plus aigent built from this repo at the resolved commit (`git archive` as build context). No npm publish needed.
- `run`: call `aigent run` in the container with `OLLAMA_API_KEY` and collect the transcript.
- `to_trace`: transcript to ATIF. One step per assistant turn with tokens and the cached-token split, tool calls as tool calls, `core__load_skill` marked with the skill mark (`<plugin>:<skill>`), enable and denial records in step `extra`. Subject plugin directories map to `loadPlugins` directories.

Risk: multeval's stored schemas and entry points are stable, but its Python API is not, and the adapter imports kernel modules (`multeval.atif`, `multeval.subjects`, `multeval.environments`, `multeval.cases`, `multeval.skills`). Pin `multeval-core` to a commit in the adapter's `pyproject.toml` and run the adapter tests in this repo's checks, so a bump fails here first. The repo becomes TypeScript plus Python, so done means both `npm run check` and the adapter's `uv` tests pass, and the AGENTS.md layout section names `integrations/`.

Sequence:

1. v1 lands.
2. `aigent run`: a headless CLI that runs one prompt to completion with a model, a plugin directory and a tool mode, and writes the redacted transcript.
3. The adapter with its conformance doc and golden tests.
4. A multeval contrast varying only the tool mode, over several models and trials. It decides the default tool mode, and the live test drops to a smoke check.

## Open questions

- Default tool mode, decided by the live comparison and then the multeval contrast.
- Whether tool-result instructions hold up, decided by the Celsius probe.
